package com.roaringmachine.client;

import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.util.math.MathHelper;

/**
 * Animated wrapper around the generated model (see ModelGen).
 *
 * Model units are 1/38 of a design block; the renderer scales by 0.5 (ModelPart itself divides by 16).
 * Front of the machine is -Z, left is +X, and the model origin is on the ground.
 * Three layers: solid (opaque metal), glass (translucent shield) and glow (full-bright: lamps, tail lights,
 * muzzle flashes, spinning-barrel glow).
 */
public class RoaringMachineModel {
    private static final float U = 38.0f;
    /** How far (model units) the shield sinks into the machine when retracted. */
    private static final float SHIELD_DROP = 1.05f * U;
    /** Side cannons move into firing position: up, outward, and pitch up. */
    private static final float RAISE_UP = 0.15f * U;
    private static final float RAISE_OUT = 0.06f * U;
    private static final float RAISE_PITCH = -0.11f;

    public final ModelPart solidRoot;
    public final ModelPart glassRoot;
    public final ModelPart glowRoot;

    private final ModelPart fork;
    private final ModelPart wheelF;
    private final ModelPart wheelRL;
    private final ModelPart wheelRR;
    private final ModelPart rotorMain;
    private final ModelPart rotorL;
    private final ModelPart rotorR;
    private final ModelPart handlebar;
    private final ModelPart shieldFrame;
    private final ModelPart glass;

    private final ModelPart flashMain;
    private final ModelPart flashL;
    private final ModelPart flashR;
    private final ModelPart glowStatic;
    private final ModelPart glowShield;
    private final ModelPart blurMain;
    private final ModelPart blurL;
    private final ModelPart blurR;

    private final float shieldFrameY0;
    private final float glassY0;
    private final float glowShieldY0;
    private final float rotorLX0;
    private final float rotorRX0;
    private final float rotorY0;
    private final float flashLX0;
    private final float flashRX0;
    private final float flashY0;
    private final float blurLX0;
    private final float blurRX0;
    private final float blurY0;

    private boolean shieldVisible;
    private boolean glowVisible;

    public RoaringMachineModel(ModelPart solidRoot, ModelPart glassRoot, ModelPart glowRoot) {
        this.solidRoot = solidRoot;
        this.glassRoot = glassRoot;
        this.glowRoot = glowRoot;
        this.fork = solidRoot.getChild("front_fork");
        this.wheelF = fork.getChild("wheel_f");
        this.wheelRL = solidRoot.getChild("wheel_rl");
        this.wheelRR = solidRoot.getChild("wheel_rr");
        this.rotorMain = solidRoot.getChild("rotor_main");
        this.rotorL = solidRoot.getChild("rotor_l");
        this.rotorR = solidRoot.getChild("rotor_r");
        this.handlebar = solidRoot.getChild("handlebar");
        this.shieldFrame = solidRoot.getChild("shield_frame");
        this.glass = glassRoot.getChild("glass");

        this.flashMain = glowRoot.getChild("flash_main");
        this.flashL = glowRoot.getChild("flash_l");
        this.flashR = glowRoot.getChild("flash_r");
        this.glowStatic = glowRoot.getChild("glow_static");
        this.glowShield = glowRoot.getChild("glow_shield");
        this.blurMain = glowRoot.getChild("blur_main");
        this.blurL = glowRoot.getChild("blur_l");
        this.blurR = glowRoot.getChild("blur_r");

        this.shieldFrameY0 = shieldFrame.pivotY;
        this.glassY0 = glass.pivotY;
        this.glowShieldY0 = glowShield.pivotY;
        this.rotorLX0 = rotorL.pivotX;
        this.rotorRX0 = rotorR.pivotX;
        this.rotorY0 = rotorL.pivotY;
        this.flashLX0 = flashL.pivotX;
        this.flashRX0 = flashR.pivotX;
        this.flashY0 = flashL.pivotY;
        this.blurLX0 = blurL.pivotX;
        this.blurRX0 = blurR.pivotX;
        this.blurY0 = blurL.pivotY;
    }

    public static TexturedModelData getSolidModelData() {
        ModelData data = new ModelData();
        ModelGen.buildSolid(data.getRoot());
        return TexturedModelData.of(data, ModelGen.TEX_W, ModelGen.TEX_H);
    }

    public static TexturedModelData getGlassModelData() {
        ModelData data = new ModelData();
        ModelGen.buildGlass(data.getRoot());
        return TexturedModelData.of(data, ModelGen.TEX_W, ModelGen.TEX_H);
    }

    public static TexturedModelData getGlowModelData() {
        ModelData data = new ModelData();
        ModelGen.buildFlash(data.getRoot());
        return TexturedModelData.of(data, ModelGen.TEX_W, ModelGen.TEX_H);
    }

    public boolean isShieldVisible() {
        return shieldVisible;
    }

    public boolean isGlowVisible() {
        return glowVisible;
    }

    public void setAngles(RoaringMachineEntity entity, float tickDelta) {
        float rad = MathHelper.RADIANS_PER_DEGREE;
        float wheel = MathHelper.lerp(tickDelta, entity.prevWheelAngle, entity.wheelAngle) * rad;
        wheelF.pitch = wheel;
        wheelRL.pitch = wheel;
        wheelRR.pitch = wheel;

        // Steer input +1 = left; model +yaw turns right, so negate. Max about 31 degrees.
        float steer = MathHelper.lerp(tickDelta, entity.prevSteerAngle, entity.steerAngle) * 0.55f;
        fork.yaw = -steer;
        handlebar.yaw = -steer;

        // Barrels spin together.
        float rotor = MathHelper.lerp(tickDelta, entity.prevRotorAngle, entity.rotorAngle) * rad;
        rotorMain.roll = rotor;
        rotorL.roll = rotor;
        rotorR.roll = rotor;
        blurMain.roll = rotor;
        blurL.roll = rotor;
        blurR.roll = rotor;

        // The two lower cannons move into firing position (eased).
        float rp = MathHelper.lerp(tickDelta, entity.prevRaiseProgress, entity.raiseProgress);
        float re = rp * rp * (3.0f - 2.0f * rp);
        rotorL.pivotY = rotorY0 - re * RAISE_UP;
        rotorR.pivotY = rotorY0 - re * RAISE_UP;
        rotorL.pivotX = rotorLX0 + re * RAISE_OUT;
        rotorR.pivotX = rotorRX0 - re * RAISE_OUT;
        rotorL.pitch = re * RAISE_PITCH;
        rotorR.pitch = re * RAISE_PITCH;
        float muzzleUp = re * (RAISE_UP + 0.10f * 0.95f * U);
        flashL.pivotY = flashY0 - muzzleUp;
        flashR.pivotY = flashY0 - muzzleUp;
        flashL.pivotX = flashLX0 + re * RAISE_OUT;
        flashR.pivotX = flashRX0 - re * RAISE_OUT;
        blurL.pivotY = blurY0 - muzzleUp;
        blurR.pivotY = blurY0 - muzzleUp;
        blurL.pivotX = blurLX0 + re * RAISE_OUT;
        blurR.pivotX = blurRX0 - re * RAISE_OUT;

        // Shield: rises smoothly out of the machine, sinks back when retracted.
        float p = MathHelper.lerp(tickDelta, entity.prevShieldProgress, entity.shieldProgress);
        float eased = p * p * (3.0f - 2.0f * p);
        float drop = (1.0f - eased) * SHIELD_DROP;
        shieldFrame.pivotY = shieldFrameY0 + drop;
        glass.pivotY = glassY0 + drop;
        glowShield.pivotY = glowShieldY0 + drop;
        shieldVisible = p > 0.02f;
        shieldFrame.visible = shieldVisible;
        glass.visible = shieldVisible;
        glowShield.visible = shieldVisible;

        // Glow layer: lamps and tail lights while someone is driving; flashes only at full power.
        glowVisible = true;
        glowStatic.visible = entity.hasPassengers() || entity.clientRotorState != RoaringMachineEntity.ROTOR_IDLE;
        boolean active = entity.clientRotorState == RoaringMachineEntity.ROTOR_ACTIVE;
        int t = entity.age;
        flashMain.visible = active && (t % 3 != 0);
        flashL.visible = active && (t % 2 == 0);
        flashR.visible = active && (t % 2 == 1);
        flashMain.roll = t * 1.9f;
        flashL.roll = t * 2.3f;
        flashR.roll = t * 1.3f;
        boolean fast = entity.rotorSpeedClient > RoaringMachineEntity.ROTOR_MAX_SPEED * 0.45f;
        blurMain.visible = fast;
        blurL.visible = fast;
        blurR.visible = fast;
    }
}
