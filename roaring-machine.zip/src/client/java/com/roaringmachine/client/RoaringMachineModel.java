package com.roaringmachine.client;

import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.util.math.MathHelper;

/**
 * Animated wrapper around the generated model (see ModelGen).
 *
 * Model units are 1/UNITS of a design block; the renderer scales by 0.5 (ModelPart itself divides by 16).
 * Front of the machine is -Z, left is +X, and the model origin is on the ground.
 * Layers: solid (opaque metal), glass (translucent shield) and glow (full bright: tail lights, muzzle flashes,
 * spinning-barrel glow discs, shield LED strips).
 *
 * The three barrel assemblies hinge at their rear end, so tilting them (cannons moving into position, or the
 * gun front raised with Space + mouse) never cuts through the mounts.
 */
public class RoaringMachineModel {
    private static final float U = ModelGen.UNITS;
    /** How far (model units) the shield sinks into the machine when retracted. */
    private static final float SHIELD_DROP = 1.25f * U;
    /** The two lower cannons tilt up by this much (radians) when they move into firing position. */
    private static final float RAISE_PITCH = 0.20f;
    /** Hinge-to-muzzle distances (model units) of the barrel assemblies. */
    private static final float MAIN_REACH = 1.72f * U;
    private static final float SIDE_REACH = 1.82f * U;

    public final ModelPart solidRoot;
    public final ModelPart glassRoot;
    public final ModelPart glowRoot;

    private final ModelPart fork;
    private final ModelPart wheelF;
    private final ModelPart wheelRL;
    private final ModelPart wheelRR;
    private final ModelPart rotorMain;
    private final ModelPart rotorL;
    private final ModelPart rotorR;
    private final ModelPart spinMain;
    private final ModelPart spinL;
    private final ModelPart spinR;
    private final ModelPart handlebar;
    private final ModelPart shieldFrame;
    private final ModelPart beltL;
    private final ModelPart beltR;
    private final ModelPart glass;

    private final ModelPart flashMain;
    private final ModelPart flashL;
    private final ModelPart flashR;
    private final ModelPart glowStatic;
    private final ModelPart glowShield;
    private final ModelPart[] blurMain = new ModelPart[5];
    private final ModelPart[] blurL = new ModelPart[5];
    private final ModelPart[] blurR = new ModelPart[5];

    private final float shieldFrameY0;
    private final float glassY0;
    private final float glowShieldY0;
    private final float flashMainY0;
    private final float flashMainZ0;
    private final float flashSideY0;
    private final float flashSideZ0;
    private final float blurMainY0;
    private final float blurMainZ0;
    private final float blurSideY0;
    private final float blurSideZ0;

    private boolean shieldVisible;

    public RoaringMachineModel(ModelPart solidRoot, ModelPart glassRoot, ModelPart glowRoot) {
        this.solidRoot = solidRoot;
        this.glassRoot = glassRoot;
        this.glowRoot = glowRoot;
        this.fork = solidRoot.getChild("front_fork");
        this.wheelF = fork.getChild("wheel_f");
        this.wheelRL = solidRoot.getChild("wheel_rl");
        this.wheelRR = solidRoot.getChild("wheel_rr");
        this.rotorMain = solidRoot.getChild("rotor_main");
        this.rotorL = solidRoot.getChild("rotor_l");
        this.rotorR = solidRoot.getChild("rotor_r");
        this.spinMain = rotorMain.getChild("spin");
        this.spinL = rotorL.getChild("spin");
        this.spinR = rotorR.getChild("spin");
        this.handlebar = solidRoot.getChild("handlebar");
        this.shieldFrame = solidRoot.getChild("shield_frame");
        this.beltL = solidRoot.getChild("belt_l");
        this.beltR = solidRoot.getChild("belt_r");
        this.glass = glassRoot.getChild("glass");

        this.flashMain = glowRoot.getChild("flash_main");
        this.flashL = glowRoot.getChild("flash_l");
        this.flashR = glowRoot.getChild("flash_r");
        this.glowStatic = glowRoot.getChild("glow_static");
        this.glowShield = glowRoot.getChild("glow_shield");
        for (int i = 0; i < 5; i++) {
            blurMain[i] = glowRoot.getChild("blur_main_" + i);
            blurL[i] = glowRoot.getChild("blur_l_" + i);
            blurR[i] = glowRoot.getChild("blur_r_" + i);
        }

        this.shieldFrameY0 = shieldFrame.pivotY;
        this.glassY0 = glass.pivotY;
        this.glowShieldY0 = glowShield.pivotY;
        this.flashMainY0 = flashMain.pivotY;
        this.flashMainZ0 = flashMain.pivotZ;
        this.flashSideY0 = flashL.pivotY;
        this.flashSideZ0 = flashL.pivotZ;
        this.blurMainY0 = blurMain[0].pivotY;
        this.blurMainZ0 = blurMain[0].pivotZ;
        this.blurSideY0 = blurL[0].pivotY;
        this.blurSideZ0 = blurL[0].pivotZ;
    }

    public static TexturedModelData getSolidModelData() {
        ModelData data = new ModelData();
        ModelGen.buildSolid(data.getRoot());
        return TexturedModelData.of(data, ModelGen.TEX_W, ModelGen.TEX_H);
    }

    public static TexturedModelData getGlassModelData() {
        ModelData data = new ModelData();
        ModelGen.buildGlass(data.getRoot());
        return TexturedModelData.of(data, ModelGen.TEX_W, ModelGen.TEX_H);
    }

    public static TexturedModelData getGlowModelData() {
        ModelData data = new ModelData();
        ModelGen.buildFlash(data.getRoot());
        return TexturedModelData.of(data, ModelGen.TEX_W, ModelGen.TEX_H);
    }

    public boolean isShieldVisible() {
        return shieldVisible;
    }

    /** Place a glow part (flash or disc) at the muzzle of a tilted barrel: it follows the hinge rotation. */
    private static void followMuzzle(ModelPart part, float y0, float z0, float reach, float up) {
        part.pivotY = y0 - reach * (float) Math.sin(up);
        part.pivotZ = z0 + reach * (1.0f - (float) Math.cos(up));
        part.pitch = -up;
    }

    public void setAngles(RoaringMachineEntity entity, float tickDelta) {
        float rad = MathHelper.RADIANS_PER_DEGREE;
        float wheel = MathHelper.lerp(tickDelta, entity.prevWheelAngle, entity.wheelAngle) * rad;
        wheelF.pitch = wheel;
        wheelRL.pitch = wheel;
        wheelRR.pitch = wheel;

        // Steer input +1 = left; model +yaw turns right, so negate. Max about 31 degrees.
        float steerValue = MathHelper.lerp(tickDelta, entity.prevSteerAngle, entity.steerAngle);
        fork.yaw = -steerValue * 0.55f;
        handlebar.yaw = -steerValue * RiderPose.BAR_YAW;

        // All barrels spin together around their own axes.
        float rotor = MathHelper.lerp(tickDelta, entity.prevRotorAngle, entity.rotorAngle) * rad;
        spinMain.roll = rotor;
        spinL.roll = rotor;
        spinR.roll = rotor;
        for (int i = 0; i < 5; i++) {
            blurMain[i].roll = rotor;
            blurL[i].roll = rotor;
            blurR[i].roll = rotor;
        }

        // Gun front raised with Space + mouse; the two lower cannons additionally tilt up into position (eased, small settle).
        float elev = MathHelper.lerp(tickDelta, entity.prevGunElevClient, entity.gunElevClient);
        float rp = MathHelper.lerp(tickDelta, entity.prevRaiseProgress, entity.raiseProgress);
        float t1 = rp - 1.0f;
        float re = 1.0f + 2.2f * t1 * t1 * t1 + 1.2f * t1 * t1;
        float sideUp = elev + re * RAISE_PITCH;
        rotorMain.pitch = -elev;
        rotorL.pitch = -sideUp;
        rotorR.pitch = -sideUp;
        followMuzzle(flashMain, flashMainY0, flashMainZ0, MAIN_REACH + 0.30f * U, elev);
        followMuzzle(flashL, flashSideY0, flashSideZ0, SIDE_REACH + 0.55f * U, sideUp);
        followMuzzle(flashR, flashSideY0, flashSideZ0, SIDE_REACH + 0.55f * U, sideUp);

        // Orange glow discs: only while spinning; five brightness steps so it fades in and out gradually.
        float spinRatio = entity.rotorSpeedClient / RoaringMachineEntity.ROTOR_MAX_SPEED;
        int level = spinRatio < 0.12f ? -1 : Math.min(4, (int) (spinRatio * 5.0f));
        for (int i = 0; i < 5; i++) {
            boolean show = i == level;
            blurMain[i].visible = show;
            blurL[i].visible = show;
            blurR[i].visible = show;
            followMuzzle(blurMain[i], blurMainY0, blurMainZ0, MAIN_REACH, elev);
            followMuzzle(blurL[i], blurSideY0, blurSideZ0, SIDE_REACH, sideUp);
            followMuzzle(blurR[i], blurSideY0, blurSideZ0, SIDE_REACH, sideUp);
        }

        // Hanging cartridge belts swing from the receiver.
        float bp = MathHelper.lerp(tickDelta, entity.prevBeltPitch, entity.beltPitch);
        float br = MathHelper.lerp(tickDelta, entity.prevBeltRoll, entity.beltRoll);
        beltL.pitch = bp;
        beltR.pitch = bp;
        beltL.roll = br;
        beltR.roll = br;

        // Shield: rises smoothly out of the machine, sinks back when retracted.
        float p = MathHelper.lerp(tickDelta, entity.prevShieldProgress, entity.shieldProgress);
        float eased = p * p * (3.0f - 2.0f * p);
        float drop = (1.0f - eased) * SHIELD_DROP;
        shieldFrame.pivotY = shieldFrameY0 + drop;
        glass.pivotY = glassY0 + drop;
        glowShield.pivotY = glowShieldY0 + drop;
        shieldVisible = p > 0.02f;
        shieldFrame.visible = shieldVisible;
        glass.visible = shieldVisible;
        glowShield.visible = shieldVisible;

        // Glow layer: tail lights while someone is driving; flashes only at full power.
        glowStatic.visible = entity.hasPassengers() || entity.clientRotorState != RoaringMachineEntity.ROTOR_IDLE;
        boolean active = entity.clientRotorState == RoaringMachineEntity.ROTOR_ACTIVE;
        int t = entity.age;
        flashMain.visible = active && (t % 3 != 0);
        flashL.visible = active && (t % 2 == 0);
        flashR.visible = active && (t % 2 == 1);
        flashMain.roll = t * 1.9f;
        flashL.roll = t * 2.3f;
        flashR.roll = t * 1.3f;
    }
}
