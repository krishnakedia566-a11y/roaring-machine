package com.roaringmachine.client;

import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.util.math.MathHelper;

/**
 * Animated wrapper around the generated model (see ModelGen).
 *
 * Model units are 1/32 block; the renderer scales by 0.5 (ModelPart itself divides by 16).
 * Front of the machine is -Z, left is +X, and the model origin is on the ground.
 */
public class RoaringMachineModel {
    /** How far (in model units) the shield sinks into the machine when retracted. */
    private static final float SHIELD_DROP = 34.0f;

    public final ModelPart solidRoot;
    public final ModelPart glassRoot;

    private final ModelPart fork;
    private final ModelPart wheelF;
    private final ModelPart wheelRL;
    private final ModelPart wheelRR;
    private final ModelPart rotorMain;
    private final ModelPart rotorL;
    private final ModelPart rotorR;
    private final ModelPart handlebar;
    private final ModelPart shieldFrame;
    private final ModelPart glass;
    private final float shieldFrameY0;
    private final float glassY0;

    private boolean shieldVisible;

    public RoaringMachineModel(ModelPart solidRoot, ModelPart glassRoot) {
        this.solidRoot = solidRoot;
        this.glassRoot = glassRoot;
        this.fork = solidRoot.getChild("front_fork");
        this.wheelF = fork.getChild("wheel_f");
        this.wheelRL = solidRoot.getChild("wheel_rl");
        this.wheelRR = solidRoot.getChild("wheel_rr");
        this.rotorMain = solidRoot.getChild("rotor_main");
        this.rotorL = solidRoot.getChild("rotor_l");
        this.rotorR = solidRoot.getChild("rotor_r");
        this.handlebar = solidRoot.getChild("handlebar");
        this.shieldFrame = solidRoot.getChild("shield_frame");
        this.glass = glassRoot.getChild("glass");
        this.shieldFrameY0 = shieldFrame.pivotY;
        this.glassY0 = glass.pivotY;
    }

    public static TexturedModelData getSolidModelData() {
        ModelData data = new ModelData();
        ModelGen.buildSolid(data.getRoot());
        return TexturedModelData.of(data, ModelGen.TEX_W, ModelGen.TEX_H);
    }

    public static TexturedModelData getGlassModelData() {
        ModelData data = new ModelData();
        ModelGen.buildGlass(data.getRoot());
        return TexturedModelData.of(data, ModelGen.TEX_W, ModelGen.TEX_H);
    }

    public boolean isShieldVisible() {
        return shieldVisible;
    }

    public void setAngles(RoaringMachineEntity entity, float tickDelta) {
        float wheel = MathHelper.lerp(tickDelta, entity.prevWheelAngle, entity.wheelAngle) * MathHelper.RADIANS_PER_DEGREE;
        wheelF.pitch = wheel;
        wheelRL.pitch = wheel;
        wheelRR.pitch = wheel;

        // Steer input +1 = left; model +yaw turns right, so negate. Max about 31 degrees.
        float steer = MathHelper.lerp(tickDelta, entity.prevSteerAngle, entity.steerAngle) * 0.55f;
        fork.yaw = -steer;
        handlebar.yaw = -steer;

        float rotor = MathHelper.lerp(tickDelta, entity.prevRotorAngle, entity.rotorAngle) * MathHelper.RADIANS_PER_DEGREE;
        rotorMain.roll = rotor;
        rotorL.roll = rotor;
        rotorR.roll = rotor;

        // Shield: rises smoothly out of the machine, sinks back when retracted.
        float p = MathHelper.lerp(tickDelta, entity.prevShieldProgress, entity.shieldProgress);
        float eased = p * p * (3.0f - 2.0f * p);
        float drop = (1.0f - eased) * SHIELD_DROP;
        shieldFrame.pivotY = shieldFrameY0 + drop;
        glass.pivotY = glassY0 + drop;
        shieldVisible = p > 0.02f;
        shieldFrame.visible = shieldVisible;
        glass.visible = shieldVisible;
    }
}
