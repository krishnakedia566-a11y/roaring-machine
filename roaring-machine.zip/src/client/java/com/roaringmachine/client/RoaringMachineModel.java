package com.roaringmachine.client;

import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.util.math.MathHelper;

/**
 * Step 1 "blockout" model: correct overall proportions, four wheels (front pair steers),
 * red seat + fenders, chrome engine bay and three separate rotary barrel assemblies.
 *
 * Units are model pixels (16 = 1 block). Front of the vehicle is -Z. Left side is +X.
 * All parts hang under "base", whose pivot sits on the ground.
 */
public class RoaringMachineModel {
    // Texture atlas rows (each material owns a 256x96 band)
    private static final int RED = 0;
    private static final int CHROME = 96;
    private static final int GUN = 192;
    private static final int TIRE = 288;
    private static final int GOLD = 384;
    public static final int TEX_W = 256;
    public static final int TEX_H = 480;

    private static final float WHEEL_CENTER_H = 8.5f;

    public final ModelPart root;
    private final ModelPart steerFL;
    private final ModelPart steerFR;
    private final ModelPart wheelFL;
    private final ModelPart wheelFR;
    private final ModelPart wheelRL;
    private final ModelPart wheelRR;
    private final ModelPart rotorMain;
    private final ModelPart rotorLeft;
    private final ModelPart rotorRight;

    public RoaringMachineModel(ModelPart root) {
        this.root = root;
        ModelPart base = root.getChild("base");
        this.steerFL = base.getChild("steer_fl");
        this.steerFR = base.getChild("steer_fr");
        this.wheelFL = steerFL.getChild("wheel");
        this.wheelFR = steerFR.getChild("wheel");
        this.wheelRL = base.getChild("wheel_rl");
        this.wheelRR = base.getChild("wheel_rr");
        this.rotorMain = base.getChild("rotor_main");
        this.rotorLeft = base.getChild("rotor_left");
        this.rotorRight = base.getChild("rotor_right");
    }

    // ---- Geometry helpers --------------------------------------------------------------

    /** Box with its min corner at (x, z) and bottom face h pixels above the parent's pivot. */
    private static void box(ModelPartData parent, String name, int mat,
                            float x, float h, float z, float dx, float dy, float dz) {
        parent.addChild(name,
                ModelPartBuilder.create().uv(0, mat).cuboid(x, -h - dy, z, dx, dy, dz),
                ModelTransform.NONE);
    }

    /** Same box on both sides (left = +X, right = mirrored). xMin is the inner edge on the left side. */
    private static void boxSym(ModelPartData parent, String name, int mat,
                               float xMin, float h, float z, float dx, float dy, float dz) {
        box(parent, name + "_l", mat, xMin, h, z, dx, dy, dz);
        box(parent, name + "_r", mat, -xMin - dx, h, z, dx, dy, dz);
    }

    private static void tireBoxes(ModelPartData wheel) {
        // Three squares rotated 30 degrees apart approximate a round tyre.
        for (int i = 0; i < 3; i++) {
            float ang = (float) Math.toRadians(30.0 * i);
            wheel.addChild("tire" + i,
                    ModelPartBuilder.create().uv(0, TIRE).cuboid(-3.5f, -6f, -6f, 7f, 12f, 12f),
                    ModelTransform.of(0f, 0f, 0f, ang, 0f, 0f));
        }
        wheel.addChild("hub",
                ModelPartBuilder.create().uv(0, CHROME).cuboid(-4.5f, -3.5f, -3.5f, 9f, 7f, 7f),
                ModelTransform.NONE);
        wheel.addChild("hub_bolt",
                ModelPartBuilder.create().uv(0, GOLD).cuboid(-5f, -1.5f, -1.5f, 10f, 3f, 3f),
                ModelTransform.NONE);
    }

    private static void steeredWheel(ModelPartData base, String name, float x, float z) {
        ModelPartData steer = base.addChild(name, ModelPartBuilder.create(),
                ModelTransform.pivot(x, -WHEEL_CENTER_H, z));
        ModelPartData wheel = steer.addChild("wheel", ModelPartBuilder.create(), ModelTransform.NONE);
        tireBoxes(wheel);
    }

    private static void fixedWheel(ModelPartData base, String name, float x, float z) {
        ModelPartData wheel = base.addChild(name, ModelPartBuilder.create(),
                ModelTransform.pivot(x, -WHEEL_CENTER_H, z));
        tireBoxes(wheel);
    }

    private static void plate(ModelPartData rotor, String name, float z, float size) {
        // Two squares 45 degrees apart = octagon-like ring plate.
        for (int k = 0; k < 2; k++) {
            rotor.addChild(name + k,
                    ModelPartBuilder.create().uv(0, GUN).cuboid(-size / 2f, -size / 2f, z, size, size, 2f),
                    ModelTransform.of(0f, 0f, 0f, 0f, 0f, (float) (k * Math.PI / 4.0)));
        }
    }

    private static void rotorAssembly(ModelPartData base, String name, float px, float h, float pz,
                                      int tubes, float ringRadius, float tubeSize, float length, float plateSize) {
        ModelPartData rotor = base.addChild(name, ModelPartBuilder.create(), ModelTransform.pivot(px, -h, pz));
        float half = length / 2f;
        float hubSize = tubeSize * 2f;
        box(rotor, "core", GUN, -hubSize / 2f, -hubSize / 2f, -half, hubSize, hubSize, length);
        for (int i = 0; i < tubes; i++) {
            double a = Math.PI * 2.0 * i / tubes;
            float cx = (float) (Math.cos(a) * ringRadius);
            float cy = (float) (Math.sin(a) * ringRadius);
            box(rotor, "tube" + i, CHROME, cx - tubeSize / 2f, cy - tubeSize / 2f, -half, tubeSize, tubeSize, length);
        }
        plate(rotor, "plate_front", -half, plateSize);
        plate(rotor, "plate_mid", -1f, plateSize * 0.9f);
        plate(rotor, "plate_rear", half - 6f, plateSize * 0.9f);
    }

    // ---- Model definition ----------------------------------------------------------------

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData base = root.addChild("base", ModelPartBuilder.create(), ModelTransform.pivot(0f, 24f, 0f));

        // Chassis, underside and axles
        box(base, "chassis", GUN, -13f, 7f, -22f, 26f, 9f, 54f);
        box(base, "underplate", GUN, -9f, 4f, -14f, 18f, 3f, 40f);
        box(base, "axle_f", GUN, -21f, 7.5f, -14f, 42f, 2f, 2f);
        box(base, "axle_r", GUN, -21f, 7.5f, 19f, 42f, 2f, 2f);

        // Wheels: front pair steers, rear pair fixed (left = +X)
        steeredWheel(base, "steer_fl", 20f, -13f);
        steeredWheel(base, "steer_fr", -20f, -13f);
        fixedWheel(base, "wheel_rl", 20f, 20f);
        fixedWheel(base, "wheel_rr", -20f, 20f);

        // Red glossy fenders and rear armoured side panels
        boxSym(base, "fender_front", RED, 15f, 17.5f, -21f, 10f, 3f, 16f);
        boxSym(base, "fender_rear", RED, 15f, 17.5f, 12f, 10f, 3f, 19f);
        boxSym(base, "panel", CHROME, 8f, 16f, 10f, 6f, 6f, 22f);
        box(base, "nose", RED, -7f, 10f, -28f, 14f, 12f, 6f);
        box(base, "rear_deck", GUN, -13f, 16f, 26f, 26f, 3f, 8f);

        // Red seat
        box(base, "seat_frame", GUN, -5f, 16f, 14f, 10f, 2f, 10f);
        box(base, "seat_cushion", RED, -6f, 18f, 13f, 12f, 4f, 12f);
        box(base, "seat_back", RED, -6f, 22f, 25f, 12f, 14f, 3f);
        box(base, "seat_head", RED, -4f, 36f, 25.5f, 8f, 4f, 2f);
        boxSym(base, "seat_post", GUN, 6f, 18f, 25f, 1.5f, 18f, 2f);

        // Steering column and handlebar
        box(base, "steer_col", GUN, -1f, 20f, 5f, 2f, 12f, 2f);
        box(base, "handlebar", RED, -9f, 31f, 4.5f, 18f, 2f, 3f);
        boxSym(base, "grip", GUN, 8f, 30f, 4.5f, 3f, 3f, 3f);

        // Engine bay, exhaust pipes
        box(base, "engine", CHROME, -8f, 16f, -20f, 16f, 12f, 18f);
        boxSym(base, "pipe_a", GOLD, 8.5f, 18f, -22f, 2f, 2f, 22f);
        boxSym(base, "pipe_b", CHROME, 8.5f, 22f, -22f, 2f, 2f, 22f);

        // Gun housings (static) and supports
        box(base, "housing_main", CHROME, -10f, 28f, -8f, 20f, 16f, 12f);
        box(base, "housing_band", GUN, -11f, 33f, -3f, 22f, 6f, 2f);
        boxSym(base, "housing_side", CHROME, 11f, 22f, -6f, 9f, 10f, 10f);
        boxSym(base, "strut", GUN, 13f, 16f, -4f, 4f, 6f, 6f);

        // Three rotary barrel assemblies (rotate together)
        rotorAssembly(base, "rotor_main", 0f, 36f, -20f, 8, 5.5f, 3f, 32f, 16f);
        rotorAssembly(base, "rotor_left", 15.5f, 27f, -21f, 6, 3.2f, 2f, 30f, 11f);
        rotorAssembly(base, "rotor_right", -15.5f, 27f, -21f, 6, 3.2f, 2f, 30f, 11f);

        return TexturedModelData.of(data, TEX_W, TEX_H);
    }

    // ---- Animation -------------------------------------------------------------------------

    public void setAngles(RoaringMachineEntity entity, float tickDelta) {
        float wheel = MathHelper.lerp(tickDelta, entity.prevWheelAngle, entity.wheelAngle) * MathHelper.RADIANS_PER_DEGREE;
        wheelFL.pitch = wheel;
        wheelFR.pitch = wheel;
        wheelRL.pitch = wheel;
        wheelRR.pitch = wheel;

        // Steer input +1 = left; model +yaw turns right, so negate. Max about 28 degrees.
        float steer = MathHelper.lerp(tickDelta, entity.prevSteerAngle, entity.steerAngle) * 0.5f;
        steerFL.yaw = -steer;
        steerFR.yaw = -steer;

        float rotor = MathHelper.lerp(tickDelta, entity.prevRotorAngle, entity.rotorAngle) * MathHelper.RADIANS_PER_DEGREE;
        rotorMain.roll = rotor;
        rotorLeft.roll = rotor;
        rotorRight.roll = rotor;
    }
}
