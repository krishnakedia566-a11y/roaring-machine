package com.roaringmachine.client;

import com.roaringmachine.VehicleSpec;

/**
 * Seated pose of the rider: torso leans forward and both arms are solved (inverse kinematics) every frame so the
 * hands stay on the handlebar grips, also while the handlebar turns with the steering.
 *
 * Frames: model space of the player/vehicle = x: left (+), y: DOWN, z: back (+). Distances are in real blocks.
 */
public final class RiderPose {
    /** Handlebar yaw at full steering (radians), shared with the model. */
    public static final float BAR_YAW = 0.27f;
    /** Torso lean (radians) around the hip. */
    public static final float LEAN = 0.45f;

    private static final double S = VehicleSpec.SCALE;
    private static final double PX = 0.9375 / 16.0;       // one player model pixel in blocks
    // Design-block constants of the handlebar (see the model generator).
    private static final double SEAT_TOP = 1.75;
    private static final double BAR_Z = 0.845;
    private static final double BAR_H = SEAT_TOP + 0.07;
    private static final double GRIP_X = 0.41;
    private static final double GRIP_H = 0.11;
    private static final double HIP_Y = SEAT_TOP * S;
    private static final double HIP_Z = 1.335 * S;

    private RiderPose() {
    }

    /** Returns {pitch, yaw} for an arm. side = +1 for the left arm, -1 for the right arm. */
    public static float[] arm(int side, float steer) {
        double sx = side * 5.0 * PX;
        double sy = HIP_Y + 10.0 * PX * Math.cos(LEAN);
        double sz = HIP_Z - 10.0 * PX * Math.sin(LEAN);

        double psi = -steer * BAR_YAW;                       // model +yaw turns right
        double lx = side * GRIP_X;
        double gx = lx * Math.cos(psi) * S;
        double gz = (BAR_Z - lx * Math.sin(psi)) * S;
        double gy = (BAR_H + GRIP_H) * S;

        double vx = gx - sx;
        double vy = -(gy - sy);                              // to model space (y down)
        double vz = gz - sz;
        double len = Math.sqrt(vx * vx + vy * vy + vz * vz);
        double dx = vx / len;
        double dy = vy / len;
        double dz = vz / len;

        double p = -Math.acos(Math.max(-1.0, Math.min(1.0, dy)));
        double sp = Math.sin(p);
        double yaw = Math.abs(sp) < 1.0e-4 ? 0.0 : Math.atan2(dx / sp, dz / sp);
        return new float[] {(float) p, (float) yaw};
    }

    /** Shoulder pivot (model pixels) for the leaned torso: {y, z}. */
    public static float[] shoulderPivot() {
        return new float[] {(float) (12.0 - 10.0 * Math.cos(LEAN)), (float) (-10.0 * Math.sin(LEAN))};
    }

    /** Neck pivot (model pixels) for the leaned torso: {y, z}. */
    public static float[] neckPivot() {
        return new float[] {(float) (12.0 - 12.0 * Math.cos(LEAN)), (float) (-12.0 * Math.sin(LEAN))};
    }
}
