package com.roaringmachine.client;

import com.roaringmachine.ModSounds;
import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;

/**
 * Client-side audio controller for one machine. Separate looping layers (engine, rolling, steering, rotary guns)
 * follow the real state of the machine; one-shot cues play only on state changes, so nothing restarts every tick.
 */
public final class VehicleSounds {
    private static final float MAX_SPEED = 0.32f;

    private final RoaringMachineEntity e;
    private boolean started;
    private boolean lastMounted;
    private int lastRotor;
    private boolean lastShield;
    private int shieldLockTimer = -1;
    private float lastSpeed;
    private double lastY;
    private double lastDy;
    private int brakeCooldown;

    private VehicleSounds(RoaringMachineEntity e) {
        this.e = e;
    }

    /** Called every client tick for each machine. */
    public static void tick(RoaringMachineEntity e) {
        VehicleSounds vs;
        if (e.clientSoundState instanceof VehicleSounds existing) {
            vs = existing;
        } else {
            vs = new VehicleSounds(e);
            e.clientSoundState = vs;
        }
        vs.update();
    }

    private void update() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) {
            return;
        }
        if (!started) {
            started = true;
            lastMounted = e.hasPassengers();
            lastRotor = e.clientRotorState;
            lastShield = e.isShieldUp();
            lastSpeed = e.speedClient;
            lastY = e.getY();
            mc.getSoundManager().play(new EngineLoop(e));
            mc.getSoundManager().play(new MoveLoop(e));
            mc.getSoundManager().play(new SteerLoop(e));
            mc.getSoundManager().play(new RotorLoop(e));
        }

        boolean mounted = e.hasPassengers();
        if (mounted != lastMounted) {
            one(mounted ? ModSounds.ENGINE_START : ModSounds.ENGINE_STOP, SoundCategory.NEUTRAL, 0.9f, 1.0f);
            lastMounted = mounted;
        }

        int rs = e.clientRotorState;
        if (rs != lastRotor) {
            if (rs == RoaringMachineEntity.ROTOR_STARTUP && lastRotor != RoaringMachineEntity.ROTOR_STARTUP) {
                one(ModSounds.ROTOR_STARTUP, SoundCategory.HOSTILE, 1.0f, 1.0f);
            } else if (rs == RoaringMachineEntity.ROTOR_SPINDOWN) {
                one(ModSounds.ROTOR_SPINDOWN, SoundCategory.HOSTILE, 1.0f, 1.0f);
            }
            lastRotor = rs;
        }

        boolean shield = e.isShieldUp();
        if (shield != lastShield) {
            one(shield ? ModSounds.SHIELD_DEPLOY : ModSounds.SHIELD_RETRACT, SoundCategory.NEUTRAL, 0.9f, 1.0f);
            shieldLockTimer = shield ? 22 : -1;
            lastShield = shield;
        }
        if (shieldLockTimer > 0 && --shieldLockTimer == 0) {
            one(ModSounds.SHIELD_LOCK, SoundCategory.NEUTRAL, 0.9f, 1.0f);
        }

        float sp = e.speedClient;
        if (lastSpeed > -0.004f && sp < -0.01f) {
            one(ModSounds.GEAR_CLUNK, SoundCategory.NEUTRAL, 0.7f, 0.9f);   // reverse engages
        }
        if (brakeCooldown > 0) {
            brakeCooldown--;
        }
        if (lastSpeed - sp > 0.010f && lastSpeed > 0.12f && brakeCooldown == 0) {
            one(ModSounds.BRAKE_HISS, SoundCategory.NEUTRAL, 0.55f, 1.0f);
            brakeCooldown = 40;
        }
        lastSpeed = sp;

        double dy = e.getY() - lastY;
        if (lastDy < -0.12 && dy > -0.04) {
            one(ModSounds.SUSPENSION_CLUNK, SoundCategory.NEUTRAL, MathHelper.clamp((float) -lastDy * 2.5f, 0.35f, 0.9f), 0.9f);
        }
        lastDy = dy;
        lastY = e.getY();
    }

    private void one(SoundEvent sound, SoundCategory category, float volume, float pitch) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            mc.world.playSound(e.getX(), e.getY() + 1.0, e.getZ(), sound, category, volume, pitch, false);
        }
    }

    // ---- Loop layers ----------------------------------------------------------------------------

    private abstract static class Loop extends MovingSoundInstance {
        protected final RoaringMachineEntity e;

        Loop(SoundEvent sound, SoundCategory category, RoaringMachineEntity e) {
            super(sound, category, Random.create());
            this.e = e;
            this.repeat = true;
            this.repeatDelay = 0;
            this.volume = 0.01f;   // never exactly 0, or the sound system drops the instance
            this.pitch = 1.0f;
            this.x = e.getX();
            this.y = e.getY() + 1.0;
            this.z = e.getZ();
        }

        @Override
        public void tick() {
            if (e.isRemoved()) {
                this.setDone();
                return;
            }
            this.x = e.getX();
            this.y = e.getY() + 1.0;
            this.z = e.getZ();
            update();
        }

        abstract void update();

        protected void approach(float target, float step) {
            this.volume = Math.max(0.001f, this.volume + MathHelper.clamp(target - this.volume, -step, step));
        }
    }

    private static final class EngineLoop extends Loop {
        EngineLoop(RoaringMachineEntity e) {
            super(ModSounds.ENGINE_LOOP, SoundCategory.NEUTRAL, e);
        }

        @Override
        void update() {
            float ratio = MathHelper.clamp(Math.abs(e.speedClient) / MAX_SPEED, 0.0f, 1.0f);
            approach(e.hasPassengers() ? 0.55f + 0.30f * ratio : 0.0f, 0.03f);
            float target = 0.82f + ratio * 0.95f;
            this.pitch += (target - this.pitch) * 0.08f;
        }
    }

    private static final class MoveLoop extends Loop {
        MoveLoop(RoaringMachineEntity e) {
            super(ModSounds.MOVE_LOOP, SoundCategory.NEUTRAL, e);
        }

        @Override
        void update() {
            float ratio = MathHelper.clamp(Math.abs(e.speedClient) / MAX_SPEED, 0.0f, 1.0f);
            approach(ratio * 0.85f, 0.04f);
            float target = (e.speedClient < -0.002f ? 0.62f : 0.72f) + ratio * 0.55f;   // reverse sounds lower and different
            this.pitch += (target - this.pitch) * 0.10f;
        }
    }

    private static final class SteerLoop extends Loop {
        SteerLoop(RoaringMachineEntity e) {
            super(ModSounds.STEER_LOOP, SoundCategory.NEUTRAL, e);
        }

        @Override
        void update() {
            float steer = Math.abs(e.steerAngle);
            float moving = MathHelper.clamp(Math.abs(e.speedClient) / 0.10f, 0.0f, 1.0f);
            approach(steer * (0.25f + 0.2f * moving), 0.03f);
            this.pitch = 0.9f + steer * 0.35f;
        }
    }

    private static final class RotorLoop extends Loop {
        RotorLoop(RoaringMachineEntity e) {
            super(ModSounds.ROTOR_LOOP, SoundCategory.HOSTILE, e);
        }

        @Override
        void update() {
            boolean active = e.clientRotorState == RoaringMachineEntity.ROTOR_ACTIVE;
            approach(active ? 0.95f : 0.0f, active ? 0.25f : 0.35f);
            this.pitch = 1.0f;
        }
    }
}
