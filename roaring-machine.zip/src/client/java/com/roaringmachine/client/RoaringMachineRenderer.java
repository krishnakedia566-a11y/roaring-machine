package com.roaringmachine.client;

import com.roaringmachine.RoaringMachineMod;
import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public class RoaringMachineRenderer extends EntityRenderer<RoaringMachineEntity> {
    private static final Identifier TEXTURE =
            Identifier.of(RoaringMachineMod.MOD_ID, "textures/entity/roaring_machine.png");
    private static final Identifier DECALS =
            Identifier.of(RoaringMachineMod.MOD_ID, "textures/entity/decals.png");

    /** Model units per design block (matches the generator) divided by the 1/16 ModelPart unit. */
    private static final float K = 38.0f / 16.0f;

    private final RoaringMachineModel model;

    public RoaringMachineRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.model = new RoaringMachineModel(
                context.getPart(ModModelLayers.ROARING_MACHINE),
                context.getPart(ModModelLayers.ROARING_MACHINE_GLASS),
                context.getPart(ModModelLayers.ROARING_MACHINE_GLOW));
        this.shadowRadius = 2.0f;
    }

    @Override
    public Identifier getTexture(RoaringMachineEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(RoaringMachineEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();

        float bodyYaw = MathHelper.lerpAngleDegrees(tickDelta, entity.prevYaw, entity.getYaw());
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - bodyYaw));

        // Suspension feel: slight nose up/down and body roll (local frame).
        float pitch = MathHelper.lerp(tickDelta, entity.prevTiltPitch, entity.tiltPitch);
        float roll = MathHelper.lerp(tickDelta, entity.prevTiltRoll, entity.tiltRoll);
        // Very small recoil while firing at full power.
        if (entity.clientRotorState == RoaringMachineEntity.ROTOR_ACTIVE) {
            float t = entity.age + tickDelta;
            pitch += MathHelper.sin(t * 2.3f) * 0.12f;
            matrices.translate(0.0f, 0.0f, MathHelper.sin(t * 2.9f) * 0.008f);
        }
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(roll));

        // Model is built in 1/38 design-block units with its origin on the ground.
        matrices.scale(-1.0f, -1.0f, 1.0f);
        matrices.scale(0.5f, 0.5f, 0.5f);

        this.model.setAngles(entity, tickDelta);

        VertexConsumer solid = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        this.model.solidRoot.render(matrices, solid, light, OverlayTexture.DEFAULT_UV);

        // High-resolution plates on the rear (MADE IN INDIA panel and the two label plates).
        VertexConsumer decals = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(DECALS));
        MatrixStack.Entry entry = matrices.peek();
        // Panel: x from +0.50 (viewer's left) to -0.50, height 0.52..1.06, just behind the rear face (z = 2.345)
        decal(entry, decals, light, 0.50, -0.50, 1.06, 0.52, 2.345, 0.0f, 0.0f, 640.0f / 1024.0f, 346.0f / 384.0f);
        // Label plates on the rear faces of the two side boxes
        decal(entry, decals, light, 0.78, 0.54, 1.344, 1.20, 2.307, 660.0f / 1024.0f, 0.0f, 960.0f / 1024.0f, 180.0f / 384.0f);
        decal(entry, decals, light, -0.54, -0.78, 1.344, 1.20, 2.307, 660.0f / 1024.0f, 190.0f / 384.0f, 960.0f / 1024.0f, 370.0f / 384.0f);

        if (this.model.isShieldVisible()) {
            VertexConsumer glass = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(TEXTURE));
            this.model.glassRoot.render(matrices, glass, light, OverlayTexture.DEFAULT_UV);
        }

        // Emissive parts are always drawn at full brightness.
        VertexConsumer glow = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(TEXTURE));
        this.model.glowRoot.render(matrices, glow, LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV);

        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    /** Textured quad on the rear (+Z) side, positions in design blocks (x: +left, h: up). */
    private static void decal(MatrixStack.Entry entry, VertexConsumer vc, int light,
                              double xLeft, double xRight, double hTop, double hBottom, double z,
                              float u0, float v0, float u1, float v1) {
        float zz = (float) (z * K);
        float yt = (float) (-hTop * K);
        float yb = (float) (-hBottom * K);
        float xl = (float) (xLeft * K);
        float xr = (float) (xRight * K);
        vertex(entry, vc, light, xl, yt, zz, u0, v0);
        vertex(entry, vc, light, xr, yt, zz, u1, v0);
        vertex(entry, vc, light, xr, yb, zz, u1, v1);
        vertex(entry, vc, light, xl, yb, zz, u0, v1);
    }

    private static void vertex(MatrixStack.Entry entry, VertexConsumer vc, int light,
                               float x, float y, float z, float u, float v) {
        vc.vertex(entry, x, y, z)
                .color(255, 255, 255, 255)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(entry, 0.0f, 0.0f, 1.0f);
    }
}
