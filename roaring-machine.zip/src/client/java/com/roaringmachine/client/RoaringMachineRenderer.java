package com.roaringmachine.client;

import com.roaringmachine.RoaringMachineMod;
import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

public class RoaringMachineRenderer extends EntityRenderer<RoaringMachineEntity> {
    private static final Identifier TEXTURE =
            Identifier.of(RoaringMachineMod.MOD_ID, "textures/entity/roaring_machine.png");
    private static final Identifier DECALS =
            Identifier.of(RoaringMachineMod.MOD_ID, "textures/entity/decals.png");

    /** Model units per design block (matches the generator) divided by the 1/16 ModelPart unit. */
    private static final float K = 38.0f / 16.0f;

    private final RoaringMachineModel model;

    public RoaringMachineRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.model = new RoaringMachineModel(
                context.getPart(ModModelLayers.ROARING_MACHINE),
                context.getPart(ModModelLayers.ROARING_MACHINE_GLASS),
                context.getPart(ModModelLayers.ROARING_MACHINE_GLOW));
        this.shadowRadius = 2.0f;
    }

    @Override
    public Identifier getTexture(RoaringMachineEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(RoaringMachineEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();

        renderTracers(entity, tickDelta, matrices, vertexConsumers);

        float bodyYaw = MathHelper.lerpAngleDegrees(tickDelta, entity.prevYaw, entity.getYaw());
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - bodyYaw));

        // Suspension feel: slight nose up/down and body roll (local frame).
        float pitch = MathHelper.lerp(tickDelta, entity.prevTiltPitch, entity.tiltPitch);
        float roll = MathHelper.lerp(tickDelta, entity.prevTiltRoll, entity.tiltRoll);
        // Very small recoil while firing at full power.
        if (entity.clientRotorState == RoaringMachineEntity.ROTOR_ACTIVE) {
            float t = entity.age + tickDelta;
            pitch += MathHelper.sin(t * 2.3f) * 0.45f + MathHelper.sin(t * 5.1f) * 0.25f;
            roll += MathHelper.sin(t * 3.1f) * 0.35f + MathHelper.sin(t * 6.7f) * 0.15f;
            matrices.translate(MathHelper.sin(t * 4.3f) * 0.012f, MathHelper.sin(t * 3.7f) * 0.014f, MathHelper.sin(t * 2.9f) * 0.03f);
        }
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(roll));

        // Model is built in 1/38 design-block units with its origin on the ground.
        matrices.scale(-1.0f, -1.0f, 1.0f);
        matrices.scale(0.5f, 0.5f, 0.5f);

        this.model.setAngles(entity, tickDelta);

        VertexConsumer solid = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        this.model.solidRoot.render(matrices, solid, light, OverlayTexture.DEFAULT_UV);

        // High-resolution plates on the rear (MADE IN INDIA panel and the two label plates).
        VertexConsumer decals = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(DECALS));
        MatrixStack.Entry entry = matrices.peek();
        // Panel: x from +0.50 (viewer's left) to -0.50, height 0.52..1.06, just behind the rear face (z = 2.345)
        decal(entry, decals, light, 0.50, -0.50, 1.06, 0.52, 2.345, 0.0f, 0.0f, 640.0f / 1024.0f, 346.0f / 384.0f);
        // Label plates on the rear faces of the two side boxes
        decal(entry, decals, light, 0.78, 0.54, 1.344, 1.20, 2.307, 660.0f / 1024.0f, 0.0f, 960.0f / 1024.0f, 180.0f / 384.0f);
        decal(entry, decals, light, -0.54, -0.78, 1.344, 1.20, 2.307, 660.0f / 1024.0f, 190.0f / 384.0f, 960.0f / 1024.0f, 370.0f / 384.0f);

        if (this.model.isShieldVisible()) {
            VertexConsumer glass = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(TEXTURE));
            this.model.glassRoot.render(matrices, glass, light, OverlayTexture.DEFAULT_UV);
        }

        // Emissive parts are always drawn at full brightness.
        VertexConsumer glow = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(TEXTURE));
        this.model.glowRoot.render(matrices, glow, LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV);

        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    /** Bright bullet streaks flying out of the three barrels (world orientation, full bright). */
    private void renderTracers(RoaringMachineEntity entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers) {
        if (entity.tracers.isEmpty()) {
            return;
        }
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(DECALS));
        MatrixStack.Entry entry = matrices.peek();
        Vec3d origin = entity.getLerpedPos(tickDelta);
        final float u0 = 0.0f;
        final float u1 = 128.0f / 1024.0f;
        final float v0 = 350.0f / 384.0f;
        final float v1 = 382.0f / 384.0f;
        for (float[] t : entity.tracers) {
            float hx = t[0] + t[3] * tickDelta - (float) origin.x;
            float hy = t[1] + t[4] * tickDelta - (float) origin.y;
            float hz = t[2] + t[5] * tickDelta - (float) origin.z;
            float speed = (float) Math.sqrt(t[3] * t[3] + t[4] * t[4] + t[5] * t[5]);
            float dx = t[3] / speed;
            float dy = t[4] / speed;
            float dz = t[5] / speed;
            float len = 2.8f;
            float tx = hx - dx * len;
            float ty = hy - dy * len;
            float tz = hz - dz * len;
            // two perpendicular width vectors
            float ax = dz;
            float ay = 0.0f;
            float az = -dx;
            float al = (float) Math.sqrt(ax * ax + az * az);
            if (al < 1.0e-4f) {
                ax = 1.0f;
                az = 0.0f;
                al = 1.0f;
            }
            ax /= al;
            az /= al;
            float bx = dy * az - dz * ay;
            float by = dz * ax - dx * az;
            float bz = dx * ay - dy * ax;
            float w = 0.07f;
            tracerQuad(entry, vc, tx, ty, tz, hx, hy, hz, ax * w, ay * w, az * w, u0, v0, u1, v1);
            tracerQuad(entry, vc, tx, ty, tz, hx, hy, hz, bx * w, by * w, bz * w, u0, v0, u1, v1);
        }
    }

    private static void tracerQuad(MatrixStack.Entry entry, VertexConsumer vc, float tx, float ty, float tz,
                                   float hx, float hy, float hz, float wx, float wy, float wz,
                                   float u0, float v0, float u1, float v1) {
        int full = LightmapTextureManager.MAX_LIGHT_COORDINATE;
        tracerVertex(entry, vc, full, tx - wx, ty - wy, tz - wz, u0, v0);
        tracerVertex(entry, vc, full, tx + wx, ty + wy, tz + wz, u0, v1);
        tracerVertex(entry, vc, full, hx + wx, hy + wy, hz + wz, u1, v1);
        tracerVertex(entry, vc, full, hx - wx, hy - wy, hz - wz, u1, v0);
    }

    private static void tracerVertex(MatrixStack.Entry entry, VertexConsumer vc, int light,
                                     float x, float y, float z, float u, float v) {
        vc.vertex(entry, x, y, z)
                .color(255, 255, 255, 255)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(entry, 0.0f, 1.0f, 0.0f);
    }

    /** Textured quad on the rear (+Z) side, positions in design blocks (x: +left, h: up). */
    private static void decal(MatrixStack.Entry entry, VertexConsumer vc, int light,
                              double xLeft, double xRight, double hTop, double hBottom, double z,
                              float u0, float v0, float u1, float v1) {
        float zz = (float) (z * K);
        float yt = (float) (-hTop * K);
        float yb = (float) (-hBottom * K);
        float xl = (float) (xLeft * K);
        float xr = (float) (xRight * K);
        vertex(entry, vc, light, xl, yt, zz, u0, v0);
        vertex(entry, vc, light, xr, yt, zz, u1, v0);
        vertex(entry, vc, light, xr, yb, zz, u1, v1);
        vertex(entry, vc, light, xl, yb, zz, u0, v1);
    }

    private static void vertex(MatrixStack.Entry entry, VertexConsumer vc, int light,
                               float x, float y, float z, float u, float v) {
        vc.vertex(entry, x, y, z)
                .color(255, 255, 255, 255)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(entry, 0.0f, 0.0f, 1.0f);
    }
}
