package com.roaringmachine.client;

import com.roaringmachine.RoaringMachineMod;
import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public class RoaringMachineRenderer extends EntityRenderer<RoaringMachineEntity> {
    private static final Identifier TEXTURE =
            Identifier.of(RoaringMachineMod.MOD_ID, "textures/entity/roaring_machine.png");

    private final RoaringMachineModel model;

    public RoaringMachineRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.model = new RoaringMachineModel(
                context.getPart(ModModelLayers.ROARING_MACHINE),
                context.getPart(ModModelLayers.ROARING_MACHINE_GLASS));
        this.shadowRadius = 1.8f;
    }

    @Override
    public Identifier getTexture(RoaringMachineEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(RoaringMachineEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();

        float bodyYaw = MathHelper.lerpAngleDegrees(tickDelta, entity.prevYaw, entity.getYaw());
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - bodyYaw));

        // Suspension feel: slight nose up/down and body roll (local frame).
        float pitch = MathHelper.lerp(tickDelta, entity.prevTiltPitch, entity.tiltPitch);
        float roll = MathHelper.lerp(tickDelta, entity.prevTiltRoll, entity.tiltRoll);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(roll));

        // Model is built in 1/32 block units with its origin on the ground.
        matrices.scale(-1.0f, -1.0f, 1.0f);
        matrices.scale(0.5f, 0.5f, 0.5f);

        this.model.setAngles(entity, tickDelta);

        VertexConsumer solid = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        this.model.solidRoot.render(matrices, solid, light, OverlayTexture.DEFAULT_UV);

        if (this.model.isShieldVisible()) {
            VertexConsumer glass = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(TEXTURE));
            this.model.glassRoot.render(matrices, glass, light, OverlayTexture.DEFAULT_UV);
        }

        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }
}
