package com.roaringmachine.client;

import com.roaringmachine.RoaringMachineMod;
import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

public class RoaringMachineRenderer extends EntityRenderer<RoaringMachineEntity> {
    private static final Identifier TEXTURE =
            Identifier.of(RoaringMachineMod.MOD_ID, "textures/entity/roaring_machine.png");
    private static final Identifier DECALS =
            Identifier.of(RoaringMachineMod.MOD_ID, "textures/entity/decals.png");

    /** Model units per design block divided by the 1/16 ModelPart unit. */
    private static final float K = ModelGen.UNITS / 16.0f;

    // sprite rectangles in the decal atlas (1024 x 384)
    private static final float TRACER_U0 = 0.0f;
    private static final float TRACER_U1 = 128.0f / 1024.0f;
    private static final float TRACER_V0 = 350.0f / 384.0f;
    private static final float TRACER_V1 = 382.0f / 384.0f;
    private static final float BRASS_U0 = 144.0f / 1024.0f;
    private static final float BRASS_U1 = 168.0f / 1024.0f;
    private static final float BRASS_V0 = 354.0f / 384.0f;
    private static final float BRASS_V1 = 378.0f / 384.0f;

    private final RoaringMachineModel model;

    public RoaringMachineRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.model = new RoaringMachineModel(
                context.getPart(ModModelLayers.ROARING_MACHINE),
                context.getPart(ModModelLayers.ROARING_MACHINE_GLASS),
                context.getPart(ModModelLayers.ROARING_MACHINE_GLOW));
        this.shadowRadius = 2.2f;
    }

    @Override
    public Identifier getTexture(RoaringMachineEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(RoaringMachineEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();

        renderBullets(entity, tickDelta, matrices, vertexConsumers, light);

        float bodyYaw = MathHelper.lerpAngleDegrees(tickDelta, entity.prevYaw, entity.getYaw());
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - bodyYaw));

        // Suspension feel: slight nose up/down and body roll (local frame).
        float pitch = MathHelper.lerp(tickDelta, entity.prevTiltPitch, entity.tiltPitch);
        float roll = MathHelper.lerp(tickDelta, entity.prevTiltRoll, entity.tiltRoll);
        // Strong vibration only while firing at full power.
        if (entity.clientRotorState == RoaringMachineEntity.ROTOR_ACTIVE) {
            float t = entity.age + tickDelta;
            pitch += MathHelper.sin(t * 2.3f) * 0.55f + MathHelper.sin(t * 5.1f) * 0.30f;
            roll += MathHelper.sin(t * 3.1f) * 0.45f + MathHelper.sin(t * 6.7f) * 0.20f;
            matrices.translate(MathHelper.sin(t * 4.3f) * 0.014f, MathHelper.sin(t * 3.7f) * 0.018f, MathHelper.sin(t * 2.9f) * 0.035f);
        }
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(roll));

        // Model origin is on the ground; units are 1/UNITS design blocks.
        matrices.scale(-1.0f, -1.0f, 1.0f);
        matrices.scale(0.5f, 0.5f, 0.5f);

        this.model.setAngles(entity, tickDelta);

        VertexConsumer solid = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        this.model.solidRoot.render(matrices, solid, light, OverlayTexture.DEFAULT_UV);

        // High-resolution plates on the rear (MADE IN INDIA panel and the two label plates).
        VertexConsumer decals = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(DECALS));
        MatrixStack.Entry entry = matrices.peek();
        decal(entry, decals, light, 0.50, -0.50, 1.10, 0.48, 2.368, 0.0f, 0.0f, 640.0f / 1024.0f, 346.0f / 384.0f);
        decal(entry, decals, light, 0.78, 0.54, 1.344, 1.20, 2.307, 660.0f / 1024.0f, 0.0f, 960.0f / 1024.0f, 180.0f / 384.0f);
        decal(entry, decals, light, -0.54, -0.78, 1.344, 1.20, 2.307, 660.0f / 1024.0f, 190.0f / 384.0f, 960.0f / 1024.0f, 370.0f / 384.0f);

        if (this.model.isShieldVisible()) {
            VertexConsumer glass = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucentEmissive(TEXTURE));
            this.model.glassRoot.render(matrices, glass, light, OverlayTexture.DEFAULT_UV);
        }

        // Emissive parts are always drawn at full brightness.
        VertexConsumer glow = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucentEmissive(TEXTURE));
        this.model.glowRoot.render(matrices, glow, LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV);

        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    /** Bullet streaks (one per barrel tube) and brass casings, drawn in world orientation, full bright. */
    private void renderBullets(RoaringMachineEntity entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int worldLight) {
        if (entity.tracers.isEmpty() && entity.casings.isEmpty()) {
            return;
        }
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucentEmissive(DECALS));
        MatrixStack.Entry entry = matrices.peek();
        Vec3d origin = entity.getLerpedPos(tickDelta);
        final int full = LightmapTextureManager.MAX_LIGHT_COORDINATE;
        for (float[] t : entity.tracers) {
            float hx = t[0] + t[3] * tickDelta - (float) origin.x;
            float hy = t[1] + t[4] * tickDelta - (float) origin.y;
            float hz = t[2] + t[5] * tickDelta - (float) origin.z;
            float speed = (float) Math.sqrt(t[3] * t[3] + t[4] * t[4] + t[5] * t[5]);
            float ux = t[3] / speed;
            float uy = t[4] / speed;
            float uz = t[5] / speed;
            // the streak starts at the muzzle: never longer than the distance already flown from the rod tip
            float ox = t[9] - (float) origin.x;
            float oy = t[10] - (float) origin.y;
            float oz = t[11] - (float) origin.z;
            float flown = (float) Math.sqrt((hx - ox) * (hx - ox) + (hy - oy) * (hy - oy) + (hz - oz) * (hz - oz));
            float length = Math.min(2.6f, flown);
            if (length > 0.05f) {
                streak(entry, vc, hx, hy, hz, ux, uy, uz, length, 0.06f,
                        TRACER_U0, TRACER_V0, TRACER_U1, TRACER_V1, full, 255);
            }
            // muzzle flash on that rod: a short bright burst at the tip during the bullet's first tick
            if (t[6] < 1.5f) {
                float k = 1.0f - Math.min(1.0f, (t[6] + tickDelta) / 1.5f);
                streak(entry, vc, ox + ux * 0.55f, oy + uy * 0.55f, oz + uz * 0.55f, ux, uy, uz, 0.55f + 0.3f * k, 0.07f + 0.07f * k,
                        TRACER_U0, TRACER_V0, TRACER_U1, TRACER_V1, full, 255);
            }
        }
        // casings: normal lit layer (no glow), so under shaders they look like matte silver brass instead of shining
        VertexConsumer cvc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(DECALS));
        for (float[] c : entity.casings) {
            float hx = c[0] + c[3] * tickDelta - (float) origin.x;
            float hy = c[1] + c[4] * tickDelta - (float) origin.y;
            float hz = c[2] + c[5] * tickDelta - (float) origin.z;
            // tumbling casing: its direction rotates with its spin
            float a = c[7] + c[6] * 0.9f + tickDelta * 0.9f;
            float dx = (float) Math.cos(a) * 0.8f + c[3] * 2.0f;
            float dy = (float) Math.sin(a * 1.3f) * 0.6f + c[4];
            float dz = (float) Math.sin(a) * 0.8f + c[5] * 2.0f;
            float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz) + 1.0e-4f;
            streak(entry, cvc, hx, hy, hz, dx / len, dy / len, dz / len, 0.16f, 0.028f,
                    BRASS_U0, BRASS_V0, BRASS_U1, BRASS_V1, worldLight, 215);
        }
    }

    /** Two crossed quads along a direction: head at (hx,hy,hz), tail `length` behind it. */
    private static void streak(MatrixStack.Entry entry, VertexConsumer vc, float hx, float hy, float hz,
                               float dx, float dy, float dz, float length, float width,
                               float u0, float v0, float u1, float v1, int light, int c) {
        float tx = hx - dx * length;
        float ty = hy - dy * length;
        float tz = hz - dz * length;
        // first width vector: horizontal, perpendicular to the direction
        float ax = dz;
        float az = -dx;
        float al = (float) Math.sqrt(ax * ax + az * az);
        if (al < 1.0e-4f) {
            ax = 1.0f;
            az = 0.0f;
            al = 1.0f;
        }
        ax /= al;
        az /= al;
        // second width vector: direction x first vector
        float bx = dy * az;
        float by = dz * ax - dx * az;
        float bz = -dy * ax;
        float bl = (float) Math.sqrt(bx * bx + by * by + bz * bz);
        if (bl < 1.0e-4f) {
            bx = 0.0f;
            by = 1.0f;
            bz = 0.0f;
            bl = 1.0f;
        }
        bx /= bl;
        by /= bl;
        bz /= bl;
        quad(entry, vc, tx, ty, tz, hx, hy, hz, ax * width, 0.0f, az * width, u0, v0, u1, v1, light, c);
        quad(entry, vc, tx, ty, tz, hx, hy, hz, bx * width, by * width, bz * width, u0, v0, u1, v1, light, c);
    }

    private static void quad(MatrixStack.Entry entry, VertexConsumer vc, float tx, float ty, float tz,
                             float hx, float hy, float hz, float wx, float wy, float wz,
                             float u0, float v0, float u1, float v1, int light, int c) {
        vertexFull(entry, vc, light, c, tx - wx, ty - wy, tz - wz, u0, v0);
        vertexFull(entry, vc, light, c, tx + wx, ty + wy, tz + wz, u0, v1);
        vertexFull(entry, vc, light, c, hx + wx, hy + wy, hz + wz, u1, v1);
        vertexFull(entry, vc, light, c, hx - wx, hy - wy, hz - wz, u1, v0);
    }

    private static void vertexFull(MatrixStack.Entry entry, VertexConsumer vc, int light, int c,
                                   float x, float y, float z, float u, float v) {
        vc.vertex(entry, x, y, z)
                .color(c, c, c, 255)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(entry, 0.0f, 1.0f, 0.0f);
    }

    /** Textured quad on the rear (+Z) side, positions in design blocks (x: +left, h: up). */
    private static void decal(MatrixStack.Entry entry, VertexConsumer vc, int light,
                              double xLeft, double xRight, double hTop, double hBottom, double z,
                              float u0, float v0, float u1, float v1) {
        float zz = (float) (z * K);
        float yt = (float) (-hTop * K);
        float yb = (float) (-hBottom * K);
        float xl = (float) (xLeft * K);
        float xr = (float) (xRight * K);
        vertex(entry, vc, light, xl, yt, zz, u0, v0);
        vertex(entry, vc, light, xr, yt, zz, u1, v0);
        vertex(entry, vc, light, xr, yb, zz, u1, v1);
        vertex(entry, vc, light, xl, yb, zz, u0, v1);
    }

    private static void vertex(MatrixStack.Entry entry, VertexConsumer vc, int light,
                               float x, float y, float z, float u, float v) {
        vc.vertex(entry, x, y, z)
                .color(255, 255, 255, 255)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(entry, 0.0f, 0.0f, 1.0f);
    }
}
