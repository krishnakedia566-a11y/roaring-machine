package com.roaringmachine.client;

import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Gun-sight HUD shown only while riding the Roaring Machine Gun (the vanilla crosshair is hidden by InGameHudMixin).
 * The main reticle sits where the guns really point (machine heading + gun elevation projected onto the screen), a faint
 * dot marks the camera centre. Outer ring dashes turn with the barrels, the inner cross opens up while firing, brackets
 * frame the target area, side bars show the shield, the bar underneath is the barrel spin-up meter.
 */
public final class CrosshairHud {
    private static float smX;
    private static float smY;
    private static float spin;
    private static boolean initialised;
    private static long lastNs;

    private CrosshairHud() {
    }

    public static boolean riding() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null && mc.player.getVehicle() instanceof RoaringMachineEntity;
    }

    private static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return (Math.round(ar + (br - ar) * t) << 16) | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }

    private static void bar(DrawContext ctx, int x0, int y0, int x1, int y1, int rgb, int alpha) {
        ctx.fill(x0 - 1, y0 - 1, x1 + 1, y1 + 1, (alpha / 2 << 24));          // dark outline so it reads on any background
        ctx.fill(x0, y0, x1, y1, (alpha << 24) | rgb);
    }

    /**
     * The mod ships a transparent replacement for the vanilla crosshair sprite (that is the only way to remove it without
     * depending on Minecraft internals), so when you are NOT on the machine a plain crosshair is drawn here instead.
     */
    private static void drawPlainCrosshair(DrawContext ctx, MinecraftClient mc) {
        if (!mc.options.getPerspective().isFirstPerson()
                || (mc.interactionManager != null && mc.interactionManager.getCurrentGameMode() == net.minecraft.world.GameMode.SPECTATOR)) {
            return;
        }
        int x = ctx.getScaledWindowWidth() / 2;
        int y = ctx.getScaledWindowHeight() / 2;
        ctx.fill(x - 8, y - 1, x + 8, y + 2, 0x66000000);
        ctx.fill(x - 1, y - 8, x + 2, y + 8, 0x66000000);
        ctx.fill(x - 7, y, x + 8, y + 1, 0xE6FFFFFF);
        ctx.fill(x, y - 7, x + 1, y + 8, 0xE6FFFFFF);
    }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.currentScreen != null) {
            return;
        }
        if (!(mc.player.getVehicle() instanceof RoaringMachineEntity e)) {
            initialised = false;
            drawPlainCrosshair(ctx, mc);
            return;
        }
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        float cx = w / 2.0f;
        float cy = h / 2.0f;

        long now = System.nanoTime();
        float dt = initialised ? Math.min(0.1f, (now - lastNs) / 1.0e9f) : 0.0f;
        lastNs = now;

        // where the guns point, relative to where the camera looks
        float camYaw = mc.gameRenderer.getCamera().getYaw();
        float camPitch = mc.gameRenderer.getCamera().getPitch();
        float dyaw = MathHelper.clamp(MathHelper.wrapDegrees(e.getYaw() - camYaw), -60.0f, 60.0f);
        float gunPitch = -(float) Math.toDegrees(e.gunElevClient);
        float dpitch = MathHelper.clamp(gunPitch - camPitch, -60.0f, 60.0f);
        double vfov = Math.toRadians(mc.options.getFov().getValue());
        double tanHalf = Math.tan(vfov / 2.0);
        float aspect = w / (float) h;
        float tx = cx + (float) (Math.tan(Math.toRadians(dyaw)) / (tanHalf * aspect)) * (w / 2.0f);
        float ty = cy + (float) (Math.tan(Math.toRadians(dpitch)) / tanHalf) * (h / 2.0f);
        tx = MathHelper.clamp(tx, cx - w * 0.30f, cx + w * 0.30f);
        ty = MathHelper.clamp(ty, cy - h * 0.30f, cy + h * 0.30f);
        if (!initialised) {
            smX = tx;
            smY = ty;
            initialised = true;
        } else {
            float a = 1.0f - (float) Math.exp(-dt * 20.0f);
            smX += (tx - smX) * a;
            smY += (ty - smY) * a;
        }
        int x = Math.round(smX);
        int y = Math.round(smY);

        float sp = MathHelper.clamp(e.rotorSpeedClient / 15.0f, 0.0f, 1.0f);       // 0 idle .. 1 full spin
        boolean firing = e.clientRotorState == RoaringMachineEntity.ROTOR_ACTIVE;
        spin += dt * (40.0f + 520.0f * sp);
        int base = mix(0x7FE9FF, 0xFF9A2A, sp);                                      // ice blue -> hot orange
        int alpha = 235;
        int gap = 5 + Math.round(5.0f * sp);

        // faint camera-centre dot (only when the guns point somewhere else)
        if (Math.abs(smX - cx) + Math.abs(smY - cy) > 7.0f) {
            ctx.fill(Math.round(cx) - 1, Math.round(cy) - 1, Math.round(cx) + 2, Math.round(cy) + 2, 0x70FFFFFF);
        }
        // centre dot
        bar(ctx, x - 1, y - 1, x + 2, y + 2, firing ? 0xFFE08A : 0xFFFFFF, alpha);
        // inner cross that opens up while the barrels spin
        bar(ctx, x - gap - 8, y, x - gap, y + 2, base, alpha);
        bar(ctx, x + gap + 1, y, x + gap + 9, y + 2, base, alpha);
        bar(ctx, x, y - gap - 8, x + 2, y - gap, base, alpha);
        bar(ctx, x, y + gap + 1, x + 2, y + gap + 9, base, alpha);
        // outer ring: 12 dashes that rotate with the barrels
        int radius = 21 + Math.round(3.0f * sp);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x + 0.5f, y + 0.5f, 0.0f);
        for (int k = 0; k < 12; k++) {
            ctx.getMatrices().push();
            ctx.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(spin + k * 30.0f));
            ctx.fill(radius, -1, radius + 5, 1, ((k % 3 == 0 ? 235 : 150) << 24) | base);
            ctx.getMatrices().pop();
        }
        ctx.getMatrices().pop();
        // corner brackets (static lock frame)
        int f = 32;
        int l = 9;
        int bracket = (150 << 24) | 0xE6F6FF;
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sy = -1; sy <= 1; sy += 2) {
                int px = x + sx * f;
                int py = y + sy * f;
                ctx.fill(Math.min(px, px - sx * l), py, Math.max(px, px - sx * l) + 1, py + 1, bracket);
                ctx.fill(px, Math.min(py, py - sy * l), px + 1, Math.max(py, py - sy * l) + 1, bracket);
            }
        }
        // shield bars on both sides: bright blue when the shield is up, dark when it is down
        boolean shield = e.shieldProgress > 0.5f;
        int shieldRgb = shield ? 0x58B8FF : 0x40505C;
        for (int sx = -1; sx <= 1; sx += 2) {
            int px = x + sx * 45;
            ctx.fill(px - 1, y - 8, px + 2, y + 9, 0x80000000);
            ctx.fill(px, y - 7, px + 1, y + 8, ((shield ? 255 : 130) << 24) | shieldRgb);
        }
        // barrel spin-up meter under the sight
        int mw = 40;
        int my = y + f + 8;
        ctx.fill(x - mw / 2 - 1, my - 1, x + mw / 2 + 1, my + 4, 0x90000000);
        ctx.fill(x - mw / 2, my, x - mw / 2 + Math.round(mw * sp), my + 3, (230 << 24) | mix(0x7FE9FF, 0xFF7A1A, sp));
        if (firing) {
            ctx.drawCenteredTextWithShadow(mc.textRenderer, "FIRING", x, my + 7, 0xFFB050);
        } else if (e.clientRotorState == RoaringMachineEntity.ROTOR_STARTUP) {
            ctx.drawCenteredTextWithShadow(mc.textRenderer, "SPIN-UP", x, my + 7, 0xBFEFFF);
        }
    }
}
