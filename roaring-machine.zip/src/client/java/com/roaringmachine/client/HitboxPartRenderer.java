package com.roaringmachine.client;

import com.roaringmachine.RoaringMachineMod;
import com.roaringmachine.entity.HitboxPartEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Collision parts are invisible. */
public class HitboxPartRenderer extends EntityRenderer<HitboxPartEntity> {
    private static final Identifier TEXTURE =
            Identifier.of(RoaringMachineMod.MOD_ID, "textures/entity/roaring_machine.png");

    public HitboxPartRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public Identifier getTexture(HitboxPartEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(HitboxPartEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        // nothing to draw
    }
}
