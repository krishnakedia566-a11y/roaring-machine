package com.roaringmachine.client;

import com.roaringmachine.ModEntities;
import com.roaringmachine.entity.RoaringMachineEntity;
import com.roaringmachine.network.DriveInputPayload;
import com.roaringmachine.network.ExitPayload;
import com.roaringmachine.network.ShieldTogglePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class RoaringMachineClient implements ClientModInitializer {
    private static KeyBinding shieldKey;
    private static KeyBinding exitKey;
    private static float shakePitch;
    private static float shakeYaw;
    /** Gun front raise (radians): hold Space and pull the mouse back. Only up, never down. */
    private static float elevation;
    private static float lastPitch;

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ROARING_MACHINE, RoaringMachineModel::getSolidModelData);
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ROARING_MACHINE_GLASS, RoaringMachineModel::getGlassModelData);
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ROARING_MACHINE_GLOW, RoaringMachineModel::getGlowModelData);
        EntityRendererRegistry.register(ModEntities.ROARING_MACHINE, RoaringMachineRenderer::new);
        EntityRendererRegistry.register(ModEntities.HITBOX_PART, HitboxPartRenderer::new);

        // Default: the "+" / "=" key. Configurable in Options > Controls.
        shieldKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.roaringmachine.shield", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_EQUAL, "category.roaringmachine"));
        // Dedicated, configurable exit key (Shift also still works like vanilla).
        exitKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.roaringmachine.exit", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, "category.roaringmachine"));

        RoaringMachineEntity.clientTickHook = VehicleSounds::tick;
        ClientTickEvents.END_CLIENT_TICK.register(RoaringMachineClient::onClientTick);
        // Runs every frame: while Space is held the mouse moves the gun instead of the camera pitch.
        WorldRenderEvents.START.register(context -> onFrame());
        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register((drawContext, unused) -> CrosshairHud.render(drawContext));
    }

    /** Space held + mouse pulled back (looking down) lifts the gun front; the camera pitch stays frozen meanwhile. */
    private static void onFrame() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            return;
        }
        boolean riding = player.getVehicle() instanceof RoaringMachineEntity;
        if (!riding) {
            elevation = 0.0f;
            lastPitch = player.getPitch();
            return;
        }
        boolean hold = client.currentScreen == null && client.options.jumpKey.isPressed();
        if (hold) {
            float delta = player.getPitch() - lastPitch;       // positive = mouse pulled back
            elevation = MathHelper.clamp(elevation + delta * MathHelper.RADIANS_PER_DEGREE * 0.9f, 0.0f, RoaringMachineEntity.MAX_ELEVATION);
            player.setPitch(lastPitch);
            player.prevPitch = lastPitch;
        } else {
            lastPitch = player.getPitch();
        }
    }

    /** Strong vibration of the view while the guns fire (and none while just driving). */
    private static void applyCameraShake(ClientPlayerEntity player, boolean riding) {
        if (player == null) {
            shakePitch = 0.0f;
            shakeYaw = 0.0f;
            return;
        }
        boolean firing = riding && player.getVehicle() instanceof RoaringMachineEntity m
                && m.clientRotorState == RoaringMachineEntity.ROTOR_ACTIVE;
        float newPitch = 0.0f;
        float newYaw = 0.0f;
        if (firing) {
            newPitch = (player.getRandom().nextFloat() - 0.5f) * 1.0f;
            newYaw = (player.getRandom().nextFloat() - 0.5f) * 0.7f;
        }
        player.setPitch(player.getPitch() - shakePitch + newPitch);
        player.setYaw(player.getYaw() - shakeYaw + newYaw);
        lastPitch += newPitch - shakePitch;
        shakePitch = newPitch;
        shakeYaw = newYaw;
    }

    /** While riding the machine, send W/S/A/D, left-click (fire), gun elevation and shield presses to the server. */
    private static void onClientTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        boolean riding = player != null && player.getVehicle() instanceof RoaringMachineEntity;

        while (shieldKey.wasPressed()) {
            if (riding) {
                ClientPlayNetworking.send(new ShieldTogglePayload());
            }
        }
        while (exitKey.wasPressed()) {
            if (riding) {
                ClientPlayNetworking.send(new ExitPayload());
            }
        }

        applyCameraShake(player, riding);
        if (!riding) {
            return;
        }

        // A/D turning carries the camera along with the machine (like a boat); the machine's own swing toward
        // the look direction (mouse) is not carried, so it can catch up with the camera.
        RoaringMachineEntity machine = (RoaringMachineEntity) player.getVehicle();
        float carry = RoaringMachineEntity.steerYawDelta(machine.steerAngle, machine.speedClient);
        player.setYaw(player.getYaw() + carry);
        player.prevYaw += carry;

        GameOptions o = client.options;
        boolean free = client.currentScreen == null;
        float forward = free ? (o.forwardKey.isPressed() ? 1.0f : 0.0f) - (o.backKey.isPressed() ? 1.0f : 0.0f) : 0.0f;
        float steer = free ? (o.leftKey.isPressed() ? 1.0f : 0.0f) - (o.rightKey.isPressed() ? 1.0f : 0.0f) : 0.0f;
        boolean fire = free && o.attackKey.isPressed();
        ClientPlayNetworking.send(new DriveInputPayload(forward, steer, fire, elevation));
    }
}
