package com.roaringmachine.client;

import com.roaringmachine.ModEntities;
import com.roaringmachine.entity.RoaringMachineEntity;
import com.roaringmachine.network.DriveInputPayload;
import com.roaringmachine.network.ShieldTogglePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class RoaringMachineClient implements ClientModInitializer {
    private static KeyBinding shieldKey;

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ROARING_MACHINE, RoaringMachineModel::getSolidModelData);
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ROARING_MACHINE_GLASS, RoaringMachineModel::getGlassModelData);
        EntityRendererRegistry.register(ModEntities.ROARING_MACHINE, RoaringMachineRenderer::new);

        // Default: the "+" / "=" key. Configurable in Options > Controls.
        shieldKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.roaringmachine.shield", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_EQUAL, "category.roaringmachine"));

        ClientTickEvents.END_CLIENT_TICK.register(RoaringMachineClient::onClientTick);
    }

    /** While riding the machine, send W/S/A/D (and shield presses) to the server. */
    private static void onClientTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        boolean riding = player != null && player.getVehicle() instanceof RoaringMachineEntity;

        while (shieldKey.wasPressed()) {
            if (riding) {
                ClientPlayNetworking.send(new ShieldTogglePayload());
            }
        }

        if (!riding) {
            return;
        }
        GameOptions o = client.options;
        float forward = (o.forwardKey.isPressed() ? 1.0f : 0.0f) - (o.backKey.isPressed() ? 1.0f : 0.0f);
        float steer = (o.leftKey.isPressed() ? 1.0f : 0.0f) - (o.rightKey.isPressed() ? 1.0f : 0.0f);
        ClientPlayNetworking.send(new DriveInputPayload(forward, steer));
    }
}
