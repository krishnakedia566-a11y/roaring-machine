package com.roaringmachine.client;

import com.roaringmachine.ModEntities;
import com.roaringmachine.entity.RoaringMachineEntity;
import com.roaringmachine.network.DriveInputPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;

public class RoaringMachineClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ROARING_MACHINE, RoaringMachineModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.ROARING_MACHINE, RoaringMachineRenderer::new);
        ClientTickEvents.END_CLIENT_TICK.register(RoaringMachineClient::onClientTick);
    }

    /** While riding the machine, send W/S/A/D to the server every tick. */
    private static void onClientTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || !(player.getVehicle() instanceof RoaringMachineEntity)) {
            return;
        }
        GameOptions o = client.options;
        float forward = (o.forwardKey.isPressed() ? 1.0f : 0.0f) - (o.backKey.isPressed() ? 1.0f : 0.0f);
        float steer = (o.leftKey.isPressed() ? 1.0f : 0.0f) - (o.rightKey.isPressed() ? 1.0f : 0.0f);
        ClientPlayNetworking.send(new DriveInputPayload(forward, steer));
    }
}
