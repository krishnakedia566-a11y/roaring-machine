package com.roaringmachine.client;

import com.roaringmachine.RoaringMachineMod;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class ModModelLayers {
    public static final EntityModelLayer ROARING_MACHINE =
            new EntityModelLayer(Identifier.of(RoaringMachineMod.MOD_ID, "roaring_machine"), "main");
    public static final EntityModelLayer ROARING_MACHINE_GLASS =
            new EntityModelLayer(Identifier.of(RoaringMachineMod.MOD_ID, "roaring_machine"), "glass");
    public static final EntityModelLayer ROARING_MACHINE_GLOW =
            new EntityModelLayer(Identifier.of(RoaringMachineMod.MOD_ID, "roaring_machine"), "glow");
}
