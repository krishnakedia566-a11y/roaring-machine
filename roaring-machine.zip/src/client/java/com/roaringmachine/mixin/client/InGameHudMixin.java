package com.roaringmachine.mixin.client;

import com.roaringmachine.client.CrosshairHud;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla crosshair while riding the Roaring Machine Gun (its own sight is drawn by CrosshairHud). */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void roaringmachine$hideVanillaCrosshair(CallbackInfo ci) {
        if (CrosshairHud.riding()) {
            ci.cancel();
        }
    }
}
