package com.roaringmachine.mixin.client;

import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While riding the Roaring Machine Gun the vanilla first-person arm (a big sleeve floating at the bottom right of the
 * screen, not on the handlebar) is not drawn: it blocked the view and was never on the grips. The hands are the gloved
 * hands built into the handlebar model.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void roaringmachine$noFloatingHand(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                               float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                                               VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (player.getVehicle() instanceof RoaringMachineEntity) {
            ci.cancel();
        }
    }
}
