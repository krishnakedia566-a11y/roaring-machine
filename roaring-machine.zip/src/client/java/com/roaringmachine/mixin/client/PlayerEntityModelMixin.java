package com.roaringmachine.mixin.client;

import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Custom seated pose while riding the Roaring Machine Gun: sitting upright facing forward,
 * both hands out to the handlebar grips, legs resting forward.
 */
@Mixin(PlayerEntityModel.class)
public abstract class PlayerEntityModelMixin<T extends LivingEntity> extends BipedEntityModel<T> {
    @Shadow @Final public ModelPart leftSleeve;
    @Shadow @Final public ModelPart rightSleeve;
    @Shadow @Final public ModelPart leftPants;
    @Shadow @Final public ModelPart rightPants;
    @Shadow @Final public ModelPart jacket;

    protected PlayerEntityModelMixin(ModelPart root) {
        super(root);
    }

    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"), require = 0)
    private void roaringmachine$ridePose(T entity, float limbAngle, float limbDistance, float animationProgress,
                                         float headYaw, float headPitch, CallbackInfo ci) {
        if (!(entity.getVehicle() instanceof RoaringMachineEntity)) {
            return;
        }
        // Upright body.
        this.body.pitch = 0.0f;
        this.body.yaw = 0.0f;
        this.body.roll = 0.0f;

        // Arms reach forward-down to the grips, slightly outward.
        this.rightArm.pitch = -0.92f;
        this.rightArm.yaw = 0.34f;
        this.rightArm.roll = 0.05f;
        this.leftArm.pitch = -0.92f;
        this.leftArm.yaw = -0.34f;
        this.leftArm.roll = -0.05f;

        // Legs rest forward (thighs level, slightly apart).
        this.rightLeg.pitch = -1.22f;
        this.rightLeg.yaw = 0.14f;
        this.rightLeg.roll = 0.04f;
        this.leftLeg.pitch = -1.22f;
        this.leftLeg.yaw = -0.14f;
        this.leftLeg.roll = -0.04f;

        this.leftSleeve.copyTransform(this.leftArm);
        this.rightSleeve.copyTransform(this.rightArm);
        this.leftPants.copyTransform(this.leftLeg);
        this.rightPants.copyTransform(this.rightLeg);
        this.jacket.copyTransform(this.body);
    }
}
