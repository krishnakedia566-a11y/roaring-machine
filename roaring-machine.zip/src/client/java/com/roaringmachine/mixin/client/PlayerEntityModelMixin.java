package com.roaringmachine.mixin.client;

import com.roaringmachine.client.RiderPose;
import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Seated pose while riding the Roaring Machine Gun: the torso leans forward, both hands are solved onto the
 * handlebar grips (they follow the steering), the legs rest forward.
 */
@Mixin(PlayerEntityModel.class)
public abstract class PlayerEntityModelMixin<T extends LivingEntity> extends BipedEntityModel<T> {
    @Shadow @Final public ModelPart leftSleeve;
    @Shadow @Final public ModelPart rightSleeve;
    @Shadow @Final public ModelPart leftPants;
    @Shadow @Final public ModelPart rightPants;
    @Shadow @Final public ModelPart jacket;

    protected PlayerEntityModelMixin(ModelPart root) {
        super(root);
    }

    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"), require = 0)
    private void roaringmachine$ridePose(T entity, float limbAngle, float limbDistance, float animationProgress,
                                         float headYaw, float headPitch, CallbackInfo ci) {
        if (!(entity.getVehicle() instanceof RoaringMachineEntity machine)) {
            return;
        }
        float partial = animationProgress - (float) Math.floor(animationProgress);
        float steer = MathHelper.lerp(partial, machine.prevSteerAngle, machine.steerAngle);

        // Torso leans forward around the hip: move the neck/shoulder pivots accordingly.
        float lean = RiderPose.LEAN;
        float[] neck = RiderPose.neckPivot();
        float[] shoulder = RiderPose.shoulderPivot();
        this.body.pitch = lean;
        this.body.yaw = 0.0f;
        this.body.roll = 0.0f;
        this.body.pivotY = neck[0];
        this.body.pivotZ = neck[1];
        this.head.pivotY = neck[0];
        this.head.pivotZ = neck[1];
        this.hat.copyTransform(this.head);

        // Arms: solved so the hands sit on the grips.
        float[] left = RiderPose.arm(1, steer);
        float[] right = RiderPose.arm(-1, steer);
        this.leftArm.pivotX = 5.0f;
        this.leftArm.pivotY = shoulder[0];
        this.leftArm.pivotZ = shoulder[1];
        this.leftArm.pitch = left[0];
        this.leftArm.yaw = left[1];
        this.leftArm.roll = 0.0f;
        this.rightArm.pivotX = -5.0f;
        this.rightArm.pivotY = shoulder[0];
        this.rightArm.pivotZ = shoulder[1];
        this.rightArm.pitch = right[0];
        this.rightArm.yaw = right[1];
        this.rightArm.roll = 0.0f;

        // Legs rest forward, knees apart.
        this.rightLeg.pitch = -1.15f;
        this.rightLeg.yaw = 0.28f;
        this.rightLeg.roll = 0.04f;
        this.leftLeg.pitch = -1.15f;
        this.leftLeg.yaw = -0.28f;
        this.leftLeg.roll = -0.04f;

        this.leftSleeve.copyTransform(this.leftArm);
        this.rightSleeve.copyTransform(this.rightArm);
        this.leftPants.copyTransform(this.leftLeg);
        this.rightPants.copyTransform(this.rightLeg);
        this.jacket.copyTransform(this.body);
    }
}
