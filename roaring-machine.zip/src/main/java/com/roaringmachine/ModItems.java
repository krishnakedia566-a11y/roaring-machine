package com.roaringmachine;

import com.roaringmachine.item.VehicleSpawnItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item SPAWNER = Registry.register(
            Registries.ITEM,
            Identifier.of(RoaringMachineMod.MOD_ID, "roaring_machine_spawner"),
            new VehicleSpawnItem(new Item.Settings().maxCount(1)));

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> entries.add(SPAWNER));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> entries.add(SPAWNER));
    }
}
