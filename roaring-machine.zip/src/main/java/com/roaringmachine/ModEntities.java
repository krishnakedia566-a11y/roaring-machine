package com.roaringmachine;

import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<RoaringMachineEntity> ROARING_MACHINE = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(RoaringMachineMod.MOD_ID, "roaring_machine"),
            EntityType.Builder.<RoaringMachineEntity>create(RoaringMachineEntity::new, SpawnGroup.MISC)
                    .dimensions(3.6f, 2.8f)
                    .maxTrackingRange(10)
                    .trackingTickInterval(1)
                    .makeFireImmune()
                    .build("roaring_machine"));

    public static void register() {
        // Loading this class registers the entity type.
    }
}
