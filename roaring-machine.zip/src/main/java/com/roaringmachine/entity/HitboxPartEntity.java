package com.roaringmachine.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/**
 * Invisible, solid collision block that follows the Roaring Machine Gun. Several of these cover the
 * long barrels, wheels and the rear box so players and mobs cannot walk through the machine.
 * They are never saved: the machine re-creates them.
 */
public class HitboxPartEntity extends Entity {
    public static final TrackedData<Float> PART_WIDTH = DataTracker.registerData(HitboxPartEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final TrackedData<Float> PART_HEIGHT = DataTracker.registerData(HitboxPartEntity.class, TrackedDataHandlerRegistry.FLOAT);

    private RoaringMachineEntity owner;

    public HitboxPartEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    public void init(RoaringMachineEntity owner, float width, float height) {
        this.owner = owner;
        this.dataTracker.set(PART_WIDTH, width);
        this.dataTracker.set(PART_HEIGHT, height);
        this.calculateDimensions();
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(PART_WIDTH, 1.0f);
        builder.add(PART_HEIGHT, 1.0f);
    }

    @Override
    public EntityDimensions getDimensions(EntityPose pose) {
        return EntityDimensions.fixed(this.dataTracker.get(PART_WIDTH), this.dataTracker.get(PART_HEIGHT));
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        if (PART_WIDTH.equals(data) || PART_HEIGHT.equals(data)) {
            this.calculateDimensions();
        }
        super.onTrackedDataSet(data);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient && (owner == null || owner.isRemoved())) {
            this.discard();
        }
    }

    @Override
    public boolean isCollidable() {
        return true;
    }

    @Override
    public boolean collidesWith(Entity other) {
        return false;
    }

    @Override
    public boolean canHit() {
        return !this.isRemoved();
    }

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (owner != null && !this.getWorld().isClient) {
            return owner.interact(player, hand);
        }
        return ActionResult.SUCCESS;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource damageSource) {
        return true;
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
    }
}
