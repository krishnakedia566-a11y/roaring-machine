package com.roaringmachine.entity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.roaringmachine.ModEntities;
import com.roaringmachine.ModItems;
import com.roaringmachine.VehicleSpec;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * The Roaring Machine Gun vehicle (a heavy tricycle).
 *
 * Physics, firing and damage run on the server only. The mounted player's input arrives through
 * DriveInputPayload. Speed, steering, shield and rotor state are synced to clients through the data
 * tracker; clients smooth the received positions so driving does not shake.
 */
public class RoaringMachineEntity extends Entity {
    public static final TrackedData<Float> SPEED = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final TrackedData<Float> STEER = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final TrackedData<Boolean> SHIELD = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    public static final TrackedData<Integer> ROTOR_STATE = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.INTEGER);
    public static final TrackedData<Float> ROTOR_SPEED = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);

    public static final int ROTOR_IDLE = 0;
    public static final int ROTOR_STARTUP = 1;
    public static final int ROTOR_ACTIVE = 2;
    public static final int ROTOR_SPINDOWN = 3;

    private static final float S = VehicleSpec.SCALE;

    // ---- Driving tuning (blocks per tick) ----------------------------------------------
    private static final double MAX_FORWARD = 0.32;      // about 6.4 blocks/second
    private static final double MAX_REVERSE = 0.11;
    private static final double ACCEL = 0.0055;          // heavy: ~3 seconds to full speed
    private static final double REVERSE_ACCEL = 0.004;
    private static final double BRAKE = 0.016;           // opposite key = firm braking first
    private static final double COAST = 0.0030;          // slow roll-out when no key is pressed
    private static final float MAX_TURN_DEG = 2.4f;      // degrees per tick at full steer and speed
    private static final double GRAVITY = 0.08;

    // ---- Firing tuning ---------------------------------------------------------------------
    public static final int STARTUP_TICKS = 26;          // 1.3 seconds
    public static final float ROTOR_MAX_SPEED = 20.0f;   // degrees per tick (readable at 60 fps)
    private static final double FIRE_RANGE = 40.0;
    private static final int FIRE_INTERVAL = 3;          // damage pulse every 3 ticks
    private static final float HOSTILE_DAMAGE = 1024.0f; // ordinary hostile mobs die in one hit
    private static final float BOSS_DAMAGE = 12.0f;      // bosses (max health >= 100): configurable here
    private static final int MAX_TARGETS_PER_PULSE = 20;

    // ---- Seat (local, relative to vehicle origin) ------------------------------------
    private static final double SEAT_FORWARD = -1.335 * S;   // negative = behind the centre
    private static final double SEAT_HEIGHT = 1.60 * S - 0.70;

    private static final float WHEEL_RADIUS = 0.45f * S;

    /** Collision parts: {design z (front negative), design x (left +), design y0, design width, design height}. */
    private static final double[][] PARTS = {
            {-2.25, 0.0, 1.30, 0.95, 1.00}, {-1.45, 0.0, 1.30, 0.95, 1.00},           // main rotor
            {-0.75, 0.0, 1.22, 0.92, 1.08},                                           // receiver
            {-2.05, 0.66, 1.14, 0.60, 0.50}, {-1.45, 0.66, 1.14, 0.60, 0.50}, {-0.85, 0.66, 1.14, 0.60, 0.50},     // left cannon
            {-2.05, -0.66, 1.14, 0.60, 0.50}, {-1.45, -0.66, 1.14, 0.60, 0.50}, {-0.85, -0.66, 1.14, 0.60, 0.50},  // right cannon
            {-1.40, 0.0, 0.0, 1.00, 1.00},                                            // front wheel + fender
            {1.50, 0.0, 0.30, 1.60, 0.90},                                            // rear box
            {1.30, 0.0, 1.20, 0.80, 1.10},                                            // seat + shield
            {1.62, 1.10, 0.0, 0.95, 1.00}, {1.62, -1.10, 0.0, 0.95, 1.00}            // rear wheels
    };

    // Server state
    private float inputForward;
    private float inputSteer;
    private boolean inputFire;
    private int inputAge = 100;
    private double speed;
    private float steer;
    private int stuckTicks;
    private int lastShieldToggle = -100;
    private int rotorState;
    private int rotorTimer;
    private float rotorSpeed;
    private HitboxPartEntity[] parts;

    // Client animation state (read by the renderer)
    public float wheelAngle;
    public float prevWheelAngle;
    public float steerAngle;
    public float prevSteerAngle;
    public float rotorAngle;
    public float prevRotorAngle;
    public float shieldProgress;
    public float prevShieldProgress;
    public float raiseProgress;
    public float prevRaiseProgress;
    public float tiltPitch;
    public float prevTiltPitch;
    public float tiltRoll;
    public float prevTiltRoll;
    public int clientRotorState;
    public float rotorSpeedClient;
    public float speedClient;
    /** Client sound controller (set by the client hook; kept as Object so common code stays client-free). */
    public Object clientSoundState;
    /** Hook called every client tick (set by the client mod initializer). */
    public static java.util.function.Consumer<RoaringMachineEntity> clientTickHook;
    private float lastClientSpeed;

    // Client position smoothing
    private double lerpX;
    private double lerpY;
    private double lerpZ;
    private float lerpYaw;
    private int lerpSteps;

    public RoaringMachineEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(SPEED, 0.0f);
        builder.add(STEER, 0.0f);
        builder.add(SHIELD, Boolean.FALSE);
        builder.add(ROTOR_STATE, ROTOR_IDLE);
        builder.add(ROTOR_SPEED, 0.0f);
    }

    public void setDriveInput(float forward, float steerInput, boolean fire) {
        this.inputForward = MathHelper.clamp(forward, -1.0f, 1.0f);
        this.inputSteer = MathHelper.clamp(steerInput, -1.0f, 1.0f);
        this.inputFire = fire;
        this.inputAge = 0;
    }

    public boolean isShieldUp() {
        return this.dataTracker.get(SHIELD);
    }

    public int getRotorState() {
        return this.dataTracker.get(ROTOR_STATE);
    }

    /** Server side: toggle the protective shield (rate limited so repeated presses cannot spam it). */
    public void toggleShield() {
        if (this.age - lastShieldToggle < 12) {
            return;
        }
        lastShieldToggle = this.age;
        this.dataTracker.set(SHIELD, !this.dataTracker.get(SHIELD));
    }

    // ---- Tick ---------------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) {
            clientTick();
        } else {
            serverTick();
        }
    }

    /** Smooth the 20 Hz server position updates over a few client ticks (removes the vibration). */
    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps) {
        double ox = this.getX();
        double oy = this.getY();
        double oz = this.getZ();
        float oyaw = this.getYaw();
        float opitch = this.getPitch();
        super.updateTrackedPositionAndAngles(x, y, z, yaw, pitch, interpolationSteps);
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYaw = yaw;
        this.lerpSteps = 3;
        this.setPosition(ox, oy, oz);
        this.setYaw(oyaw);
        this.setPitch(opitch);
    }

    private void clientTick() {
        if (lerpSteps > 0) {
            double f = 1.0 / lerpSteps;
            this.setPosition(this.getX() + (lerpX - this.getX()) * f,
                    this.getY() + (lerpY - this.getY()) * f,
                    this.getZ() + (lerpZ - this.getZ()) * f);
            this.setYaw(this.getYaw() + MathHelper.wrapDegrees(lerpYaw - this.getYaw()) * (float) f);
            lerpSteps--;
        }

        prevWheelAngle = wheelAngle;
        prevSteerAngle = steerAngle;
        prevRotorAngle = rotorAngle;
        prevShieldProgress = shieldProgress;
        prevRaiseProgress = raiseProgress;
        prevTiltPitch = tiltPitch;
        prevTiltRoll = tiltRoll;

        float s = this.dataTracker.get(SPEED);
        float st = this.dataTracker.get(STEER);
        speedClient = s;
        wheelAngle += (float) (s / WHEEL_RADIUS * 57.29578f);
        steerAngle = st;

        clientRotorState = this.dataTracker.get(ROTOR_STATE);
        rotorSpeedClient = this.dataTracker.get(ROTOR_SPEED);
        rotorAngle += rotorSpeedClient;
        float raiseTarget = (clientRotorState == ROTOR_STARTUP || clientRotorState == ROTOR_ACTIVE) ? 1.0f : 0.0f;
        raiseProgress += MathHelper.clamp(raiseTarget - raiseProgress, -0.05f, 0.05f);

        // Gentle suspension feel: squat when accelerating, dip when braking, lean in turns.
        float accel = s - lastClientSpeed;
        lastClientSpeed = s;
        float pitchTarget = MathHelper.clamp(accel * 120.0f, -2.2f, 2.2f);
        float rollTarget = -st * (s / (float) MAX_FORWARD) * 2.2f;
        tiltPitch += (pitchTarget - tiltPitch) * 0.10f;
        tiltRoll += (rollTarget - tiltRoll) * 0.10f;

        float target = this.dataTracker.get(SHIELD) ? 1.0f : 0.0f;
        shieldProgress += MathHelper.clamp(target - shieldProgress, -0.04f, 0.04f);

        // Muzzle smoke while the barrels are spinning at full power.
        if (clientRotorState == ROTOR_ACTIVE) {
            clientFireEffects();
        }

        if (clientTickHook != null) {
            clientTickHook.accept(this);
        }
    }

    private void clientFireEffects() {
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double fx = -MathHelper.sin(yawRad);
        double fz = MathHelper.cos(yawRad);
        double lx = MathHelper.cos(yawRad);
        double lz = MathHelper.sin(yawRad);
        double[][] muzzles = {{0.0, 1.78, -2.95}, {0.66, 1.38, -2.40}, {-0.66, 1.38, -2.40}};
        for (double[] mz : muzzles) {
            double f = -mz[2] * S;
            double l = mz[0] * S;
            double x = this.getX() + fx * f + lx * l;
            double y = this.getY() + mz[1] * S;
            double z = this.getZ() + fz * f + lz * l;
            if (this.age % 2 == 0) {
                this.getWorld().addParticle(ParticleTypes.LARGE_SMOKE, x, y, z, fx * 0.10, 0.02, fz * 0.10);
            }
            if (this.age % 3 == 0) {
                this.getWorld().addParticle(ParticleTypes.FLAME, x + fx * 0.3, y, z + fz * 0.3, fx * 0.18, 0.0, fz * 0.18);
            }
        }
    }

    private void serverTick() {
        PlayerEntity driver = this.getFirstPassenger() instanceof PlayerEntity p ? p : null;
        inputAge++;
        if (driver == null || inputAge > 6) {
            inputForward = 0.0f;
            inputSteer = 0.0f;
            inputFire = false;
        }

        // --- Speed: gradual acceleration, firm braking, slow roll-out ---
        if (inputForward > 0.5f) {
            speed += (speed < 0.0) ? BRAKE : ACCEL;
        } else if (inputForward < -0.5f) {
            speed -= (speed > 0.0) ? BRAKE : REVERSE_ACCEL;
        } else {
            double coast = (driver == null) ? COAST * 2.0 : COAST;
            if (speed > 0.0) {
                speed = Math.max(0.0, speed - coast);
            } else if (speed < 0.0) {
                speed = Math.min(0.0, speed + coast);
            }
        }
        speed = MathHelper.clamp(speed, -MAX_REVERSE, MAX_FORWARD);

        // --- Steering: smoothed, speed-dependent, no pivoting in place ---
        steer = MathHelper.lerp(0.10f, steer, inputSteer);
        float turnFactor = (float) MathHelper.clamp(speed / 0.10, -1.0, 1.0);
        turnFactor *= (float) (1.0 - 0.35 * Math.min(1.0, Math.abs(speed / MAX_FORWARD)));
        // A (left) = positive steer; in Minecraft a left turn decreases yaw.
        this.setYaw(this.getYaw() - steer * MAX_TURN_DEG * turnFactor);

        // --- Movement ---
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double dirX = -MathHelper.sin(yawRad);
        double dirZ = MathHelper.cos(yawRad);
        double vy = this.isOnGround() ? -0.1 : (this.getVelocity().y - GRAVITY) * 0.98;

        double oldX = this.getX();
        double oldZ = this.getZ();
        this.move(MovementType.SELF, new Vec3d(dirX * speed, vy, dirZ * speed));
        this.setVelocity(dirX * speed, vy, dirZ * speed);

        if (this.horizontalCollision) {
            speed *= 0.6;
        }

        // --- Never get stuck: if the driver pushes but we do not move, hop up over the obstacle/pit rim ---
        double moved = Math.hypot(this.getX() - oldX, this.getZ() - oldZ);
        if (Math.abs(inputForward) > 0.5f && moved < 0.015) {
            stuckTicks++;
            if (stuckTicks >= 25) {
                double sign = inputForward > 0 ? 1.0 : -1.0;
                tryEscape(dirX * sign, dirZ * sign);
                stuckTicks = 0;
            }
        } else {
            stuckTicks = 0;
        }

        // --- Solid collision parts ---
        ensureParts();
        updateParts();
        if (Math.abs(speed) > 0.02) {
            pushNearbyMobs();
        }

        // --- Rotor / firing ---
        rotorTick();
        if (rotorState == ROTOR_ACTIVE && this.age % FIRE_INTERVAL == 0) {
            firePulse(driver);
        }

        // --- Keep the rider facing forward ---
        if (driver != null) {
            driver.setBodyYaw(this.getYaw());
        }

        // --- Sync animation state to clients ---
        this.dataTracker.set(SPEED, (float) speed);
        this.dataTracker.set(STEER, steer);
        this.dataTracker.set(ROTOR_STATE, rotorState);
        this.dataTracker.set(ROTOR_SPEED, rotorSpeed);
    }

    // ---- Rotor state machine --------------------------------------------------------------

    private void rotorTick() {
        boolean fire = inputFire;
        switch (rotorState) {
            case ROTOR_IDLE -> {
                if (fire) {
                    rotorState = ROTOR_STARTUP;
                    rotorTimer = 0;
                }
            }
            case ROTOR_STARTUP -> {
                if (!fire) {
                    rotorState = ROTOR_SPINDOWN;
                } else {
                    rotorTimer++;
                    float t = Math.min(1.0f, rotorTimer / (float) STARTUP_TICKS);
                    rotorSpeed = ROTOR_MAX_SPEED * t * t;
                    if (rotorTimer >= STARTUP_TICKS) {
                        rotorState = ROTOR_ACTIVE;
                        rotorSpeed = ROTOR_MAX_SPEED;
                    }
                }
            }
            case ROTOR_ACTIVE -> {
                rotorSpeed = ROTOR_MAX_SPEED;
                if (!fire) {
                    rotorState = ROTOR_SPINDOWN;
                }
            }
            default -> {
                // Spin-down. Re-pressing only restarts the ramp once the barrels have slowed down.
                if (fire && rotorSpeed < ROTOR_MAX_SPEED * 0.4f) {
                    rotorState = ROTOR_STARTUP;
                    rotorTimer = (int) (Math.sqrt(rotorSpeed / ROTOR_MAX_SPEED) * STARTUP_TICKS);
                } else {
                    rotorSpeed *= 0.94f;
                    if (rotorSpeed < 0.4f) {
                        rotorSpeed = 0.0f;
                        rotorState = ROTOR_IDLE;
                    }
                }
            }
        }
    }

    // ---- Game-only damage (server authoritative, one pulse for all three barrels) ------------

    private void firePulse(PlayerEntity driver) {
        if (!(this.getWorld() instanceof ServerWorld serverWorld)) {
            return;
        }
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        Vec3d fwd = new Vec3d(-MathHelper.sin(yawRad), 0.0, MathHelper.cos(yawRad));
        Vec3d muzzle = this.getPos().add(fwd.multiply(2.95 * S)).add(0.0, 1.78 * S, 0.0);

        Box area = new Box(muzzle, muzzle.add(fwd.multiply(FIRE_RANGE))).expand(7.0, 5.0, 7.0);
        List<LivingEntity> candidates = serverWorld.getEntitiesByClass(LivingEntity.class, area, this::isValidTarget);
        candidates.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(muzzle)));

        DamageSource source = driver != null
                ? serverWorld.getDamageSources().playerAttack(driver)
                : serverWorld.getDamageSources().generic();

        int hits = 0;
        for (LivingEntity target : candidates) {
            if (hits >= MAX_TARGETS_PER_PULSE) {
                break;
            }
            Vec3d to = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0).subtract(muzzle);
            double along = to.x * fwd.x + to.z * fwd.z;
            if (along < 0.5 || along > FIRE_RANGE) {
                continue;
            }
            double lateral = Math.abs(to.x * fwd.z - to.z * fwd.x);
            double widthAllowed = 1.8 + along * 0.18;
            double vertical = Math.abs(to.y);
            double heightAllowed = 2.6 + along * 0.22;
            if (lateral > widthAllowed || vertical > heightAllowed) {
                continue;
            }
            // Blocks stop the beam (no shooting through hills and walls).
            Vec3d eye = target.getEyePos();
            if (serverWorld.raycast(new RaycastContext(muzzle, eye, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, this)).getType() != HitResult.Type.MISS) {
                continue;
            }
            float damage = target.getMaxHealth() >= 100.0f ? BOSS_DAMAGE : HOSTILE_DAMAGE;
            target.damage(source, damage);
            serverWorld.spawnParticles(ParticleTypes.CRIT, target.getX(), target.getY() + target.getHeight() * 0.5, target.getZ(),
                    5, 0.25, 0.35, 0.25, 0.25);
            hits++;
        }

        // A short tracer of sparks along the firing line.
        for (int i = 1; i <= 3; i++) {
            Vec3d p = muzzle.add(fwd.multiply(i * 5.0));
            serverWorld.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 2, 0.2, 0.2, 0.2, 0.02);
        }
    }

    private boolean isValidTarget(LivingEntity e) {
        if (!e.isAlive() || e instanceof PlayerEntity || this.hasPassenger(e)) {
            return false;
        }
        return e instanceof Monster || e.getMaxHealth() >= 100.0f && !e.isTeammate(this);
    }

    // ---- Collision parts ------------------------------------------------------------------

    private void ensureParts() {
        if (parts == null) {
            parts = new HitboxPartEntity[PARTS.length];
        }
        for (int i = 0; i < PARTS.length; i++) {
            if (parts[i] == null || parts[i].isRemoved()) {
                HitboxPartEntity part = ModEntities.HITBOX_PART.create(this.getWorld());
                if (part == null) {
                    continue;
                }
                part.init(this, (float) (PARTS[i][3] * S), (float) (PARTS[i][4] * S));
                placePart(part, PARTS[i]);
                this.getWorld().spawnEntity(part);
                parts[i] = part;
            }
        }
    }

    private void updateParts() {
        if (parts == null) {
            return;
        }
        for (int i = 0; i < PARTS.length; i++) {
            if (parts[i] != null && !parts[i].isRemoved()) {
                placePart(parts[i], PARTS[i]);
            }
        }
    }

    private void placePart(HitboxPartEntity part, double[] spec) {
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double fx = -MathHelper.sin(yawRad);
        double fz = MathHelper.cos(yawRad);
        double lx = MathHelper.cos(yawRad);
        double lz = MathHelper.sin(yawRad);
        double f = -spec[0] * S;
        double l = spec[1] * S;
        part.setPosition(this.getX() + fx * f + lx * l, this.getY() + spec[2] * S, this.getZ() + fz * f + lz * l);
    }

    private void tryEscape(double dirX, double dirZ) {
        for (int up = 1; up <= 6; up++) {
            Box box = this.getBoundingBox().offset(dirX * 0.8, up, dirZ * 0.8);
            if (this.getWorld().isSpaceEmpty(this, box)) {
                this.setPosition(this.getX() + dirX * 0.8, this.getY() + up, this.getZ() + dirZ * 0.8);
                this.setVelocity(Vec3d.ZERO);
                speed = 0.0;
                return;
            }
        }
    }

    private void pushNearbyMobs() {
        List<Box> boxes = new ArrayList<>();
        boxes.add(this.getBoundingBox());
        if (parts != null) {
            for (HitboxPartEntity part : parts) {
                if (part != null && !part.isRemoved()) {
                    boxes.add(part.getBoundingBox());
                }
            }
        }
        for (Box box : boxes) {
            List<Entity> list = this.getWorld().getOtherEntities(this, box,
                    e -> e instanceof LivingEntity && !this.hasPassenger(e));
            for (Entity e : list) {
                double dx = e.getX() - this.getX();
                double dz = e.getZ() - this.getZ();
                double len = Math.hypot(dx, dz);
                if (len < 0.001) {
                    continue;
                }
                e.addVelocity(dx / len * 0.35, 0.05, dz / len * 0.35);
                e.velocityModified = true;
            }
        }
    }

    // ---- Seat / riding --------------------------------------------------------------------

    @Override
    protected void updatePassengerPosition(Entity passenger, Entity.PositionUpdater positionUpdater) {
        if (!this.hasPassenger(passenger)) {
            return;
        }
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double x = this.getX() + (-MathHelper.sin(yawRad)) * SEAT_FORWARD;
        double z = this.getZ() + MathHelper.cos(yawRad) * SEAT_FORWARD;
        double y = this.getY() + SEAT_HEIGHT;
        positionUpdater.accept(passenger, x, y, z);
        passenger.setBodyYaw(this.getYaw());
    }

    /** The rider's body always faces the front of the machine; only the head follows the mouse. */
    @Override
    public void onPassengerLookAround(Entity passenger) {
        passenger.setBodyYaw(this.getYaw());
        float f = MathHelper.wrapDegrees(passenger.getYaw() - this.getYaw());
        float g = MathHelper.clamp(f, -110.0f, 110.0f);
        passenger.prevYaw += g - f;
        passenger.setYaw(passenger.getYaw() + g - f);
        passenger.setHeadYaw(passenger.getYaw());
    }

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (player.shouldCancelInteraction()) {
            // Creative mode: sneak + right click picks the machine up as an item.
            if (player.isCreative()) {
                if (!this.getWorld().isClient) {
                    ItemStack stack = new ItemStack(ModItems.SPAWNER);
                    if (!player.getInventory().insertStack(stack)) {
                        player.dropItem(stack, false);
                    }
                    this.discard();
                }
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        }
        if (!this.getWorld().isClient) {
            return player.startRiding(this) ? ActionResult.CONSUME : ActionResult.PASS;
        }
        return ActionResult.SUCCESS;
    }

    /** Dismount to the side of the machine (outside the hitboxes), not on top of it. */
    @Override
    public Vec3d updatePassengerForDismount(LivingEntity passenger) {
        float r = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double leftX = MathHelper.cos(r);
        double leftZ = MathHelper.sin(r);
        for (double side : new double[] {2.5 * S, -2.5 * S}) {
            Vec3d candidate = new Vec3d(this.getX() + leftX * side, this.getY(), this.getZ() + leftZ * side);
            Box box = passenger.getDimensions(passenger.getPose()).getBoxAt(candidate);
            if (this.getWorld().isSpaceEmpty(passenger, box)) {
                return candidate;
            }
        }
        return new Vec3d(this.getX(), this.getBoundingBox().maxY + 0.1, this.getZ());
    }

    // ---- Targetable, indestructible (solid shapes come from the collision parts) --------------

    @Override
    public boolean collidesWith(Entity other) {
        return false;
    }

    @Override
    public boolean canHit() {
        return !this.isRemoved();
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource damageSource) {
        return true;
    }

    @Override
    public boolean isFireImmune() {
        return true;
    }

    // Deliberately without @Override: kept tolerant of small mapping differences.
    public boolean isImmuneToExplosion(net.minecraft.world.explosion.Explosion explosion) {
        return true;
    }

    /** Climb 1-2 block steps (vanilla step logic). */
    public float getStepHeight() {
        return 2.0f;
    }

    /** The model is much larger than the main box (long barrels), so do not cull it too early. */
    public Box getVisibilityBoundingBox() {
        return this.getBoundingBox().expand(3.5, 1.5, 3.5);
    }

    // ---- Persistence -----------------------------------------------------------------------

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
    }
}
