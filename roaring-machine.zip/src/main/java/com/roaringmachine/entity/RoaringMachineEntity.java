package com.roaringmachine.entity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.roaringmachine.ModEntities;
import com.roaringmachine.ModItems;
import com.roaringmachine.VehicleSpec;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * The Roaring Machine Gun vehicle (a heavy tricycle).
 *
 * Physics, firing and damage run on the server only. The mounted player's input arrives through
 * DriveInputPayload. Speed, steering, shield, rotor state and gun elevation are synced to clients through the
 * data tracker; clients smooth the received positions so driving does not shake.
 */
public class RoaringMachineEntity extends Entity {
    public static final TrackedData<Float> SPEED = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final TrackedData<Float> STEER = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final TrackedData<Boolean> SHIELD = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    public static final TrackedData<Integer> ROTOR_STATE = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.INTEGER);
    public static final TrackedData<Float> ROTOR_SPEED = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final TrackedData<Float> GUN_ELEV = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);

    public static final int ROTOR_IDLE = 0;
    public static final int ROTOR_STARTUP = 1;
    public static final int ROTOR_ACTIVE = 2;
    public static final int ROTOR_SPINDOWN = 3;

    private static final float S = VehicleSpec.SCALE;

    // ---- Driving tuning (blocks per tick) ----------------------------------------------
    private static final double MAX_FORWARD = 0.15;      // about 3 blocks/second (heavy machine)
    private static final double MAX_REVERSE = 0.05;
    private static final double ACCEL = 0.0022;          // heavy: ~3.5 seconds to full speed
    private static final double REVERSE_ACCEL = 0.0025;
    private static final double BRAKE = 0.010;           // opposite key = firm braking first
    private static final double COAST = 0.0020;          // slow roll-out when no key is pressed
    public static final float MAX_TURN_DEG = 1.5f;       // degrees per tick at full steer and speed
    private static final float AIM_TURN_MAX = 1.5f;      // the machine turns toward where the rider looks, this fast at most
    private static final double GRAVITY = 0.08;
    /** Highest the gun front can be raised (radians, about 28 degrees). */
    public static final float MAX_ELEVATION = 0.50f;

    // ---- Firing tuning ---------------------------------------------------------------------
    public static final int STARTUP_TICKS = 26;          // 1.3 seconds
    public static final float ROTOR_MAX_SPEED = 15.0f;   // degrees per tick
    private static final double FIRE_RANGE = 40.0;
    private static final int FIRE_INTERVAL = 2;          // damage pulse every 2 ticks (10 per second)
    private static final float HOSTILE_DAMAGE = 1024.0f; // ordinary hostile mobs die in one hit
    private static final float BOSS_DAMAGE = 12.0f;      // bosses (max health >= 100): configurable here
    private static final int MAX_TARGETS_PER_PULSE = 40;

    // ---- Seat (local, relative to vehicle origin) ------------------------------------
    private static final double SEAT_FORWARD = -1.335 * S;   // negative = behind the centre
    private static final double SEAT_HEIGHT = 1.75 * S - 0.70;

    private static final float WHEEL_RADIUS = 0.45f * S;

    /** Barrel tubes (design blocks): {count, ring radius, phase}; each tube shoots its own tracer. */
    private static final double[][] MAIN_TIPS = tips(new double[][] {{20, 0.4176, 0.0}, {12, 0.276, 0.2}, {6, 0.15, 0.1}, {1, 0.0, 0.0}});
    private static final double[][] SIDE_TIPS = tips(new double[][] {{8, 0.155, 0.0}, {5, 0.069, 0.3}});

    /** Collision parts: {design z (front negative), design x (left +), design y0, design width, design height}.
     *  Generated from the model (see tools/coverage.py): together they cover 97-99% of the solid geometry at every heading. */
    private static final double[][] PARTS = {
            {-0.85, 0.0, 0.0, 1.7, 2.4},
            {0.25, 0.0, 0.0, 1.5, 2.4},
            {-0.10, 1.0, 0.0, 0.8, 1.7},
            {-0.10, -1.0, 0.0, 0.8, 1.7},
            {0.70, 1.05, 0.0, 0.8, 1.7},
            {0.70, -1.05, 0.0, 0.8, 1.7},
            {-1.75, 0.0, 0.0, 1.3, 2.7},
            {-2.35, 0.0, 1.40, 1.2, 1.30},
            {-3.05, 0.0, 1.45, 1.0, 1.20},
            {-2.15, 0.98, 1.30, 0.7, 0.6},
            {-1.60, 0.98, 1.30, 0.7, 0.6},
            {-1.05, 0.98, 1.30, 0.7, 0.6},
            {-0.60, 1.00, 1.30, 0.7, 0.6},
            {-2.15, -0.98, 1.30, 0.7, 0.6},
            {-1.60, -0.98, 1.30, 0.7, 0.6},
            {-1.05, -0.98, 1.30, 0.7, 0.6},
            {-0.60, -1.00, 1.30, 0.7, 0.6},
            {1.05, 0.0, 0.0, 1.45, 1.5},
            {1.62, 0.0, 0.0, 1.9, 1.5},
            {2.05, 0.0, 0.0, 1.5, 1.5},
            {1.50, 0.0, 1.4, 1.1, 1.7},
            {0.65, 0.0, 1.4, 1.3, 1.6},
            {1.62, 1.19, 0.0, 0.95, 1.05},
            {1.62, -1.19, 0.0, 0.95, 1.05}
    };

    // Server state
    private float inputForward;
    private float inputSteer;
    private boolean inputFire;
    private float inputElevation;
    private int inputAge = 100;
    private double speed;
    private float steer;
    private float aimYawVel;
    private float gunElev;
    private int stuckTicks;
    private int lastShieldToggle = -100;
    private int lastShieldHit = -100;
    private int rotorState;
    private int rotorTimer;
    private float rotorSpeed;
    private HitboxPartEntity[] parts;

    // Client animation state (read by the renderer)
    public float wheelAngle;
    public float prevWheelAngle;
    public float steerAngle;
    public float prevSteerAngle;
    public float rotorAngle;
    public float prevRotorAngle;
    public float shieldProgress;
    public float prevShieldProgress;
    public float raiseProgress;
    public float prevRaiseProgress;
    public float tiltPitch;
    public float prevTiltPitch;
    public float tiltRoll;
    public float prevTiltRoll;
    public float gunElevClient;
    public float prevGunElevClient;
    public float beltPitch;
    public float prevBeltPitch;
    public float beltRoll;
    public float prevBeltRoll;
    private float beltPitchVel;
    private float beltRollVel;
    private float lastBeltYaw;
    public int clientRotorState;
    public float rotorSpeedClient;
    public float speedClient;
    /** Client sound controller (set by the client hook; kept as Object so common code stays client-free). */
    public Object clientSoundState;
    /** Hook called every client tick (set by the client mod initializer). */
    public static java.util.function.Consumer<RoaringMachineEntity> clientTickHook;
    /** Client-only bullet tracers: {x, y, z, vx, vy, vz, age, maxAge, hit(0/1)} in world coordinates. */
    public final ArrayList<float[]> tracers = new ArrayList<>();
    /** Client-only ejected brass casings: {x, y, z, vx, vy, vz, age, spin} in world coordinates. */
    public final ArrayList<float[]> casings = new ArrayList<>();
    private int fireCursor;

    // Client position smoothing
    private double lerpX;
    private double lerpY;
    private double lerpZ;
    private float lerpYaw;
    private int lerpSteps;

    public RoaringMachineEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    private static double[][] tips(double[][] rings) {
        int n = 0;
        for (double[] r : rings) {
            n += (int) r[0];
        }
        double[][] out = new double[n][2];
        int i = 0;
        for (double[] r : rings) {
            for (int k = 0; k < (int) r[0]; k++) {
                double a = r[2] + 2.0 * Math.PI * k / r[0];
                out[i][0] = r[1] * Math.cos(a);
                out[i][1] = r[1] * Math.sin(a);
                i++;
            }
        }
        return out;
    }

    /** Yaw change (degrees) caused by A/D steering at the given steering value and speed. */
    public static float steerYawDelta(float steerValue, float speedValue) {
        float turnFactor = (float) MathHelper.clamp(speedValue / 0.10, -1.0, 1.0);
        turnFactor *= (float) (1.0 - 0.35 * Math.min(1.0, Math.abs(speedValue / MAX_FORWARD)));
        return -steerValue * MAX_TURN_DEG * turnFactor;
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(SPEED, 0.0f);
        builder.add(STEER, 0.0f);
        builder.add(SHIELD, Boolean.FALSE);
        builder.add(ROTOR_STATE, ROTOR_IDLE);
        builder.add(ROTOR_SPEED, 0.0f);
        builder.add(GUN_ELEV, 0.0f);
    }

    public void setDriveInput(float forward, float steerInput, boolean fire, float elevation) {
        this.inputForward = MathHelper.clamp(forward, -1.0f, 1.0f);
        this.inputSteer = MathHelper.clamp(steerInput, -1.0f, 1.0f);
        this.inputFire = fire;
        this.inputElevation = MathHelper.clamp(elevation, 0.0f, MAX_ELEVATION);
        this.inputAge = 0;
    }

    public boolean isShieldUp() {
        return this.dataTracker.get(SHIELD);
    }

    public int getRotorState() {
        return this.dataTracker.get(ROTOR_STATE);
    }

    /** Server side: called when the shield absorbed damage (rate limited sparks and sound). */
    public void onShieldBlocked(PlayerEntity rider) {
        if (!(this.getWorld() instanceof ServerWorld serverWorld) || this.age - lastShieldHit < 6) {
            return;
        }
        lastShieldHit = this.age;
        serverWorld.spawnParticles(ParticleTypes.ELECTRIC_SPARK, rider.getX(), rider.getY() + 1.2, rider.getZ(), 12, 0.5, 0.6, 0.5, 0.15);
        serverWorld.playSound(null, rider.getX(), rider.getY() + 1.0, rider.getZ(), com.roaringmachine.ModSounds.SHIELD_HIT,
                net.minecraft.sound.SoundCategory.PLAYERS, 1.0f, 0.95f + this.random.nextFloat() * 0.1f);
    }

    /** Server side: toggle the protective shield (rate limited so repeated presses cannot spam it). */
    public void toggleShield() {
        if (this.age - lastShieldToggle < 12) {
            return;
        }
        lastShieldToggle = this.age;
        this.dataTracker.set(SHIELD, !this.dataTracker.get(SHIELD));
    }

    // ---- Tick ---------------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) {
            clientTick();
        } else {
            serverTick();
        }
    }

    /** Smooth the 20 Hz server position updates over a few client ticks (removes the vibration). */
    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps) {
        double ox = this.getX();
        double oy = this.getY();
        double oz = this.getZ();
        float oyaw = this.getYaw();
        float opitch = this.getPitch();
        super.updateTrackedPositionAndAngles(x, y, z, yaw, pitch, interpolationSteps);
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYaw = yaw;
        this.lerpSteps = 3;
        this.setPosition(ox, oy, oz);
        this.setYaw(oyaw);
        this.setPitch(opitch);
    }

    private void clientTick() {
        if (lerpSteps > 0) {
            double f = 1.0 / lerpSteps;
            this.setPosition(this.getX() + (lerpX - this.getX()) * f,
                    this.getY() + (lerpY - this.getY()) * f,
                    this.getZ() + (lerpZ - this.getZ()) * f);
            this.setYaw(this.getYaw() + MathHelper.wrapDegrees(lerpYaw - this.getYaw()) * (float) f);
            lerpSteps--;
        }

        prevWheelAngle = wheelAngle;
        prevSteerAngle = steerAngle;
        prevRotorAngle = rotorAngle;
        prevShieldProgress = shieldProgress;
        prevRaiseProgress = raiseProgress;
        prevTiltPitch = tiltPitch;
        prevTiltRoll = tiltRoll;
        prevGunElevClient = gunElevClient;
        prevBeltPitch = beltPitch;
        prevBeltRoll = beltRoll;

        float s = this.dataTracker.get(SPEED);
        float st = this.dataTracker.get(STEER);
        float accel = s - speedClient;
        speedClient = s;
        wheelAngle += (float) (s / WHEEL_RADIUS * 57.29578f);
        steerAngle = st;

        clientRotorState = this.dataTracker.get(ROTOR_STATE);
        rotorSpeedClient = this.dataTracker.get(ROTOR_SPEED);
        rotorAngle += rotorSpeedClient;
        float raiseTarget = (clientRotorState == ROTOR_STARTUP || clientRotorState == ROTOR_ACTIVE) ? 1.0f : 0.0f;
        raiseProgress += MathHelper.clamp(raiseTarget - raiseProgress, -0.05f, 0.05f);
        gunElevClient += (this.dataTracker.get(GUN_ELEV) - gunElevClient) * 0.5f;

        // Gentle suspension feel: squat when accelerating, dip when braking, lean in turns.
        float pitchTarget = MathHelper.clamp(accel * 120.0f, -2.2f, 2.2f);
        float rollTarget = -st * (s / (float) MAX_FORWARD) * 2.2f;
        tiltPitch += (pitchTarget - tiltPitch) * 0.10f;
        tiltRoll += (rollTarget - tiltRoll) * 0.10f;

        // Hanging cartridge belts swing like pendulums (acceleration, braking, turning, firing).
        float yawRate = MathHelper.wrapDegrees(this.getYaw() - lastBeltYaw);
        lastBeltYaw = this.getYaw();
        float shake = clientRotorState == ROTOR_ACTIVE ? (this.random.nextFloat() - 0.5f) * 0.05f : 0.0f;
        beltPitchVel += -0.09f * beltPitch - 0.10f * beltPitchVel + accel * 3.2f + shake;
        beltRollVel += -0.09f * beltRoll - 0.10f * beltRollVel - yawRate * (0.004f + 0.012f * Math.abs(s) / (float) MAX_FORWARD) + shake;
        beltPitch = MathHelper.clamp(beltPitch + beltPitchVel, -0.45f, 0.45f);
        beltRoll = MathHelper.clamp(beltRoll + beltRollVel, -0.45f, 0.45f);

        float target = this.dataTracker.get(SHIELD) ? 1.0f : 0.0f;
        shieldProgress += MathHelper.clamp(target - shieldProgress, -0.04f, 0.04f);

        if (clientRotorState == ROTOR_ACTIVE) {
            clientFireEffects();
        }
        tickTracers();
        tickCasings();

        if (clientTickHook != null) {
            clientTickHook.accept(this);
        }
    }

    // ---- Client fire visuals: every barrel shoots its own tracer, brass casings fly out -----------------

    private void clientFireEffects() {
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double fx = -MathHelper.sin(yawRad);
        double fz = MathHelper.cos(yawRad);
        double lx = MathHelper.cos(yawRad);
        double lz = MathHelper.sin(yawRad);
        float phi = rotorAngle * MathHelper.RADIANS_PER_DEGREE;
        float rt = raiseProgress - 1.0f;
        float sideTilt = (1.0f + 2.2f * rt * rt * rt + 1.2f * rt * rt - 1.0f) * 0.14f;   // same curve and stow angle as the model
        float elev = gunElevClient;
        Random rnd = this.getWorld().getRandom();

        // Things a tracer can hit: living entities in the forward cone (the rider and the machine excluded).
        Vec3d here = this.getPos();
        List<LivingEntity> hitCandidates = this.getWorld().getEntitiesByClass(LivingEntity.class,
                new Box(here.x - 48, here.y - 8, here.z - 48, here.x + 48, here.y + 12, here.z + 48),
                e -> e.isAlive() && !this.hasPassenger(e) && (e.getX() - here.x) * fx + (e.getZ() - here.z) * fz > -2.0);

        // every rod fires: 20 of the 39 main rods and 7 of the 13 rods of each side cannon per pulse, alternating, so all
        // rods show bullets within a fraction of a second
        for (int i = 0; i < 20; i++) {
            int idx = (fireCursor + i * 2) % MAIN_TIPS.length;
            spawnTracer(0.0, 2.06, -1.0, 1.95, MAIN_TIPS[idx], phi, elev, yawRad, fx, fz, lx, lz, rnd, hitCandidates);
        }
        for (int i = 0; i < 7; i++) {
            int idx = (fireCursor + i * 2) % SIDE_TIPS.length;
            spawnTracer(0.98, 1.60, -0.55, 2.0, SIDE_TIPS[idx], phi, elev + sideTilt, yawRad, fx, fz, lx, lz, rnd, hitCandidates);
            spawnTracer(-0.98, 1.60, -0.55, 2.0, SIDE_TIPS[(idx + 6) % SIDE_TIPS.length], phi, elev + sideTilt, yawRad, fx, fz, lx, lz, rnd, hitCandidates);
        }
        fireCursor++;

        // ejected brass casings fly out to the right side and fall
        for (int i = 0; i < 2; i++) {
            double lf = 0.45 * S;
            double l = -0.46 * S;
            double ox = here.x + fx * lf + lx * l;
            double oy = here.y + 1.70 * S;
            double oz = here.z + fz * lf + lz * l;
            float side = 0.22f + rnd.nextFloat() * 0.14f;
            float up = 0.12f + rnd.nextFloat() * 0.12f;
            float back = rnd.nextFloat() * 0.06f - 0.03f;
            casings.add(new float[] {(float) ox, (float) oy, (float) oz,
                    (float) (-lx * side - fx * back + (rnd.nextFloat() - 0.5f) * 0.04f), up,
                    (float) (-lz * side - fz * back + (rnd.nextFloat() - 0.5f) * 0.04f), 0.0f, rnd.nextFloat() * 6.28f});
        }
    }

    private void spawnTracer(double pivotX, double pivotH, double pivotZ, double reach, double[] tip, float phi, float up,
                             float yawRad, double fx, double fz, double lx, double lz, Random rnd, List<LivingEntity> hitCandidates) {
        // rotate the tube with the barrels (model roll): x' = x cos + h sin, h' = -x sin + h cos
        double x = tip[0] * Math.cos(phi) + tip[1] * Math.sin(phi);
        double h = -tip[0] * Math.sin(phi) + tip[1] * Math.cos(phi);
        double cu = Math.cos(up);
        double su = Math.sin(up);
        double f = reach * cu - h * su;       // forward distance from the hinge after tilting the gun up
        double h2 = h * cu + reach * su;
        Vec3d here = this.getPos();
        double wx = here.x + fx * (-pivotZ + f) * S + lx * (pivotX + x) * S;
        double wy = here.y + (pivotH + h2) * S;
        double wz = here.z + fz * (-pivotZ + f) * S + lz * (pivotX + x) * S;
        double spread = 0.012;
        double dx = fx * cu + (rnd.nextFloat() - 0.5) * spread * 2.0 * lx;
        double dy = su + (rnd.nextFloat() - 0.5) * spread * 2.0;
        double dz = fz * cu + (rnd.nextFloat() - 0.5) * spread * 2.0 * lz;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= len;
        dy /= len;
        dz /= len;

        double dist = 46.0;
        int hit = 0;
        Vec3d from = new Vec3d(wx, wy, wz);
        Vec3d to = from.add(dx * dist, dy * dist, dz * dist);
        BlockHitResult result = this.getWorld().raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, this));
        if (result.getType() != HitResult.Type.MISS) {
            dist = result.getPos().distanceTo(from);
            hit = 1;
        }
        // the bullet stops at the first mob it meets
        for (LivingEntity e : hitCandidates) {
            java.util.Optional<Vec3d> p = e.getBoundingBox().expand(0.05).raycast(from, from.add(dx * dist, dy * dist, dz * dist));
            if (p.isPresent()) {
                double d = p.get().distanceTo(from);
                if (d < dist) {
                    dist = d;
                    hit = 2;
                }
            }
        }
        float speedPerTick = 4.5f;
        int maxAge = Math.max(1, (int) Math.ceil(dist / speedPerTick));
        tracers.add(new float[] {(float) wx, (float) wy, (float) wz, (float) (dx * speedPerTick), (float) (dy * speedPerTick),
                (float) (dz * speedPerTick), 0.0f, maxAge, hit, (float) wx, (float) wy, (float) wz});
    }

    private int impactSoundCooldown;

    private void tickTracers() {
        if (impactSoundCooldown > 0) {
            impactSoundCooldown--;
        }
        for (int i = tracers.size() - 1; i >= 0; i--) {
            float[] t = tracers.get(i);
            t[0] += t[3];
            t[1] += t[4];
            t[2] += t[5];
            t[6] += 1.0f;
            if (t[6] >= t[7]) {
                // bullets hitting the ground / a mob: thud, thinned out so a long burst does not become noise
                if (t[8] > 0.5f && impactSoundCooldown <= 0 && this.random.nextInt(3) == 0) {
                    this.getWorld().playSound(t[0], t[1], t[2], t[8] > 1.5f ? com.roaringmachine.ModSounds.MOB_HIT : com.roaringmachine.ModSounds.BULLET_IMPACT,
                            net.minecraft.sound.SoundCategory.HOSTILE, 0.9f, 0.85f + this.random.nextFloat() * 0.35f, false);
                    impactSoundCooldown = 2;
                }
                if (t[8] > 0.5f && t[8] < 1.5f) {
                    BlockState state = this.getWorld().getBlockState(BlockPos.ofFloored(t[0] + t[3] * 0.1, t[1] + t[4] * 0.1, t[2] + t[5] * 0.1));
                    if (!state.isAir()) {
                        this.getWorld().addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, state), t[0], t[1], t[2], 0.0, 0.0, 0.0);
                    }
                }
                tracers.remove(i);
            }
        }
    }

    private int casingSoundCooldown;

    private void tickCasings() {
        if (casingSoundCooldown > 0) {
            casingSoundCooldown--;
        }
        for (int i = casings.size() - 1; i >= 0; i--) {
            float[] c = casings.get(i);
            c[0] += c[3];
            c[1] += c[4];
            c[2] += c[5];
            c[4] -= 0.045f;
            c[3] *= 0.985f;
            c[5] *= 0.985f;
            c[6] += 1.0f;
            if (c[4] < 0.0f) {
                BlockPos bp = BlockPos.ofFloored(c[0], c[1] - 0.04, c[2]);
                BlockState state = this.getWorld().getBlockState(bp);
                if (!state.getCollisionShape(this.getWorld(), bp).isEmpty()) {
                    c[1] = bp.getY() + 1.0f;
                    c[4] = -c[4] * 0.38f;
                    c[3] *= 0.6f;
                    c[5] *= 0.6f;
                    c[7] += 1.3f;
                    if (casingSoundCooldown <= 0 && this.random.nextInt(4) == 0 && Math.abs(c[4]) > 0.06f) {
                        this.getWorld().playSound(c[0], c[1], c[2], com.roaringmachine.ModSounds.CASING_DROP,
                                net.minecraft.sound.SoundCategory.HOSTILE, 0.55f, 0.9f + this.random.nextFloat() * 0.3f, false);
                        casingSoundCooldown = 3;
                    }
                    if (Math.abs(c[4]) < 0.04f) {
                        c[4] = 0.0f;
                    }
                }
            }
            if (c[6] > 60.0f) {
                casings.remove(i);
            }
        }
    }

    // ---- Server tick ------------------------------------------------------------------------

    private void serverTick() {
        PlayerEntity driver = this.getFirstPassenger() instanceof PlayerEntity p ? p : null;
        inputAge++;
        if (driver == null || inputAge > 6) {
            inputForward = 0.0f;
            inputSteer = 0.0f;
            inputFire = false;
            inputElevation = 0.0f;
        }

        // --- Speed: gradual acceleration, firm braking, slow roll-out ---
        if (inputForward > 0.5f) {
            speed += (speed < 0.0) ? BRAKE : ACCEL;
        } else if (inputForward < -0.5f) {
            speed -= (speed > 0.0) ? BRAKE : REVERSE_ACCEL;
        } else {
            double coast = (driver == null) ? COAST * 2.0 : COAST;
            if (speed > 0.0) {
                speed = Math.max(0.0, speed - coast);
            } else if (speed < 0.0) {
                speed = Math.min(0.0, speed + coast);
            }
        }
        speed = MathHelper.clamp(speed, -MAX_REVERSE, MAX_FORWARD);

        // --- Steering: A/D turns while moving; the machine also swings toward where the rider looks, with heavy inertia ---
        steer = MathHelper.lerp(0.10f, steer, inputSteer);
        float yaw = this.getYaw() + steerYawDelta(steer, (float) speed);
        if (driver != null) {
            float diff = MathHelper.wrapDegrees(driver.getYaw() - yaw);
            float desired = 0.0f;
            if (Math.abs(diff) > 3.0f) {
                desired = MathHelper.clamp((diff - Math.signum(diff) * 3.0f) * 0.07f, -AIM_TURN_MAX, AIM_TURN_MAX);
            }
            aimYawVel += (desired - aimYawVel) * 0.10f;
        } else {
            aimYawVel *= 0.8f;
        }
        this.setYaw(yaw + aimYawVel);

        // --- Gun elevation (rider holds Space and pulls the mouse back) ---
        gunElev += MathHelper.clamp(inputElevation - gunElev, -0.03f, 0.03f);

        // --- Movement ---
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double dirX = -MathHelper.sin(yawRad);
        double dirZ = MathHelper.cos(yawRad);
        double vy = this.isOnGround() ? -0.1 : (this.getVelocity().y - GRAVITY) * 0.98;

        double oldX = this.getX();
        double oldZ = this.getZ();
        this.move(MovementType.SELF, new Vec3d(dirX * speed, vy, dirZ * speed));
        this.setVelocity(dirX * speed, vy, dirZ * speed);

        if (this.horizontalCollision) {
            speed *= 0.6;
        }

        // --- Never get stuck: if the driver pushes but we do not move, hop up over the obstacle/pit rim ---
        double moved = Math.hypot(this.getX() - oldX, this.getZ() - oldZ);
        if (Math.abs(inputForward) > 0.5f && moved < 0.015) {
            stuckTicks++;
            if (stuckTicks >= 25) {
                double sign = inputForward > 0 ? 1.0 : -1.0;
                tryEscape(dirX * sign, dirZ * sign);
                stuckTicks = 0;
            }
        } else {
            stuckTicks = 0;
        }

        // --- Solid collision parts; anything overlapping them is shoved out ---
        ensureParts();
        updateParts();
        pushOverlappingEntities();

        // --- Rotor / firing ---
        rotorTick();
        if (rotorState == ROTOR_ACTIVE && this.age % FIRE_INTERVAL == 0) {
            firePulse(driver);
        }

        // --- Keep the rider facing forward ---
        if (driver != null) {
            driver.setBodyYaw(this.getYaw());
            if (this.isShieldUp()) {
                driver.extinguish();
                driver.setAir(driver.getMaxAir());
            }
        }

        // --- Sync animation state to clients ---
        this.dataTracker.set(SPEED, (float) speed);
        this.dataTracker.set(STEER, steer);
        this.dataTracker.set(ROTOR_STATE, rotorState);
        this.dataTracker.set(ROTOR_SPEED, rotorSpeed);
        this.dataTracker.set(GUN_ELEV, gunElev);
    }

    // ---- Rotor state machine --------------------------------------------------------------

    private void rotorTick() {
        boolean fire = inputFire;
        switch (rotorState) {
            case ROTOR_IDLE -> {
                if (fire) {
                    rotorState = ROTOR_STARTUP;
                    rotorTimer = 0;
                }
            }
            case ROTOR_STARTUP -> {
                if (!fire) {
                    rotorState = ROTOR_SPINDOWN;
                } else {
                    rotorTimer++;
                    float t = Math.min(1.0f, rotorTimer / (float) STARTUP_TICKS);
                    rotorSpeed = ROTOR_MAX_SPEED * t * t;
                    if (rotorTimer >= STARTUP_TICKS) {
                        rotorState = ROTOR_ACTIVE;
                        rotorSpeed = ROTOR_MAX_SPEED;
                    }
                }
            }
            case ROTOR_ACTIVE -> {
                rotorSpeed = ROTOR_MAX_SPEED;
                if (!fire) {
                    rotorState = ROTOR_SPINDOWN;
                }
            }
            default -> {
                // Spin-down. Re-pressing only restarts the ramp once the barrels have slowed down.
                if (fire && rotorSpeed < ROTOR_MAX_SPEED * 0.4f) {
                    rotorState = ROTOR_STARTUP;
                    rotorTimer = (int) (Math.sqrt(rotorSpeed / ROTOR_MAX_SPEED) * STARTUP_TICKS);
                } else {
                    rotorSpeed *= 0.94f;
                    if (rotorSpeed < 0.4f) {
                        rotorSpeed = 0.0f;
                        rotorState = ROTOR_IDLE;
                    }
                }
            }
        }
    }

    // ---- Game-only damage (server authoritative, one pulse for all barrels) ---------------------------

    private void firePulse(PlayerEntity driver) {
        if (!(this.getWorld() instanceof ServerWorld serverWorld)) {
            return;
        }
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double fx = -MathHelper.sin(yawRad);
        double fz = MathHelper.cos(yawRad);
        double ce = Math.cos(gunElev);
        double se = Math.sin(gunElev);
        Vec3d dir = new Vec3d(fx * ce, se, fz * ce);
        // beam starts at the receiver, so mobs standing right next to the machine are hit too
        Vec3d origin = this.getPos().add(fx * 0.4 * S, 1.78 * S, fz * 0.4 * S);

        Box area = new Box(origin, origin.add(dir.multiply(FIRE_RANGE))).expand(8.0, 6.0, 8.0);
        List<LivingEntity> candidates = serverWorld.getEntitiesByClass(LivingEntity.class, area, this::isValidTarget);
        candidates.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(origin)));

        DamageSource source = driver != null
                ? serverWorld.getDamageSources().playerAttack(driver)
                : serverWorld.getDamageSources().generic();

        int hits = 0;
        for (LivingEntity target : candidates) {
            if (hits >= MAX_TARGETS_PER_PULSE) {
                break;
            }
            Vec3d to = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0).subtract(origin);
            double along = to.dotProduct(dir);
            double hd = Math.hypot(to.x, to.z);
            boolean closeRange = hd <= 5.5 && (to.x * fx + to.z * fz) >= -2.0;
            boolean inBeam = false;
            if (along >= -1.5 && along <= FIRE_RANGE) {
                Vec3d lateralVec = to.subtract(dir.multiply(along));
                inBeam = lateralVec.length() <= 2.2 + Math.max(along, 0.0) * 0.22;
            }
            if (!inBeam && !closeRange) {
                continue;
            }
            // Blocks stop the beam (no shooting through hills and walls), except for point-blank targets.
            if (hd > 6.0) {
                Vec3d eye = target.getEyePos();
                if (serverWorld.raycast(new RaycastContext(origin, eye, RaycastContext.ShapeType.COLLIDER,
                        RaycastContext.FluidHandling.NONE, this)).getType() != HitResult.Type.MISS) {
                    continue;
                }
            }
            float damage = target.getMaxHealth() >= 100.0f ? BOSS_DAMAGE : HOSTILE_DAMAGE;
            target.damage(source, damage);
            hits++;
        }
    }

    private boolean isValidTarget(LivingEntity e) {
        if (!e.isAlive() || e instanceof PlayerEntity || this.hasPassenger(e)
                || e instanceof net.minecraft.entity.decoration.ArmorStandEntity) {
            return false;
        }
        // tamed pets are spared; everything else that lives (monsters, villagers, animals, bosses) is a target
        if (e instanceof net.minecraft.entity.passive.TameableEntity pet && pet.isTamed()) {
            return false;
        }
        return true;
    }

    // ---- Collision parts ------------------------------------------------------------------

    private void ensureParts() {
        if (parts == null) {
            parts = new HitboxPartEntity[PARTS.length];
        }
        for (int i = 0; i < PARTS.length; i++) {
            if (parts[i] == null || parts[i].isRemoved()) {
                HitboxPartEntity part = ModEntities.HITBOX_PART.create(this.getWorld());
                if (part == null) {
                    continue;
                }
                part.init(this, (float) (PARTS[i][3] * S), (float) (PARTS[i][4] * S));
                placePart(part, PARTS[i]);
                this.getWorld().spawnEntity(part);
                parts[i] = part;
            }
        }
    }

    private void updateParts() {
        if (parts == null) {
            return;
        }
        for (int i = 0; i < PARTS.length; i++) {
            if (parts[i] != null && !parts[i].isRemoved()) {
                placePart(parts[i], PARTS[i]);
            }
        }
    }

    private void placePart(HitboxPartEntity part, double[] spec) {
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double fx = -MathHelper.sin(yawRad);
        double fz = MathHelper.cos(yawRad);
        double lx = MathHelper.cos(yawRad);
        double lz = MathHelper.sin(yawRad);
        double f = -spec[0] * S;
        double l = spec[1] * S;
        part.setPosition(this.getX() + fx * f + lx * l, this.getY() + spec[2] * S, this.getZ() + fz * f + lz * l);
    }

    private void tryEscape(double dirX, double dirZ) {
        for (int up = 1; up <= 6; up++) {
            Box box = this.getBoundingBox().offset(dirX * 0.8, up, dirZ * 0.8);
            if (this.getWorld().isSpaceEmpty(this, box)) {
                this.setPosition(this.getX() + dirX * 0.8, this.getY() + up, this.getZ() + dirZ * 0.8);
                this.setVelocity(Vec3d.ZERO);
                speed = 0.0;
                return;
            }
        }
    }

    /** Anything (mobs and players) that ends up inside a collision part is shoved out, harder while the machine moves. */
    private void pushOverlappingEntities() {
        if (parts == null) {
            return;
        }
        double strength = 0.12 + 0.6 * Math.abs(speed) / MAX_FORWARD;
        for (HitboxPartEntity part : parts) {
            if (part == null || part.isRemoved()) {
                continue;
            }
            Box box = part.getBoundingBox();
            List<Entity> list = this.getWorld().getOtherEntities(this, box,
                    e -> e instanceof LivingEntity && !this.hasPassenger(e) && !(e instanceof HitboxPartEntity));
            for (Entity e : list) {
                double dx = e.getX() - (box.minX + box.maxX) * 0.5;
                double dz = e.getZ() - (box.minZ + box.maxZ) * 0.5;
                double len = Math.hypot(dx, dz);
                if (len < 0.001) {
                    float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
                    dx = -MathHelper.sin(yawRad);
                    dz = MathHelper.cos(yawRad);
                    len = 1.0;
                }
                e.addVelocity(dx / len * strength, 0.04, dz / len * strength);
                e.velocityModified = true;
            }
        }
    }

    // ---- Seat / riding --------------------------------------------------------------------

    @Override
    protected void updatePassengerPosition(Entity passenger, Entity.PositionUpdater positionUpdater) {
        if (!this.hasPassenger(passenger)) {
            return;
        }
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double x = this.getX() + (-MathHelper.sin(yawRad)) * SEAT_FORWARD;
        double z = this.getZ() + MathHelper.cos(yawRad) * SEAT_FORWARD;
        double y = this.getY() + SEAT_HEIGHT;
        positionUpdater.accept(passenger, x, y, z);
        passenger.setBodyYaw(this.getYaw());
    }

    /** The rider's body always faces the front of the machine; only the head follows the mouse. */
    @Override
    public void onPassengerLookAround(Entity passenger) {
        passenger.setBodyYaw(this.getYaw());
        float f = MathHelper.wrapDegrees(passenger.getYaw() - this.getYaw());
        float g = MathHelper.clamp(f, -75.0f, 75.0f);
        passenger.prevYaw += g - f;
        passenger.setYaw(passenger.getYaw() + g - f);
        passenger.setHeadYaw(passenger.getYaw());
    }

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (player.shouldCancelInteraction()) {
            // Creative mode: sneak + right click picks the machine up as an item.
            if (player.isCreative()) {
                if (!this.getWorld().isClient) {
                    ItemStack stack = new ItemStack(ModItems.SPAWNER);
                    if (!player.getInventory().insertStack(stack)) {
                        player.dropItem(stack, false);
                    }
                    this.discard();
                }
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        }
        if (!this.getWorld().isClient) {
            return player.startRiding(this) ? ActionResult.CONSUME : ActionResult.PASS;
        }
        return ActionResult.SUCCESS;
    }

    /** Dismount to the side of the machine (outside the hitboxes), not on top of it. */
    @Override
    public Vec3d updatePassengerForDismount(LivingEntity passenger) {
        float r = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double leftX = MathHelper.cos(r);
        double leftZ = MathHelper.sin(r);
        for (double side : new double[] {2.5 * S, -2.5 * S}) {
            Vec3d candidate = new Vec3d(this.getX() + leftX * side, this.getY(), this.getZ() + leftZ * side);
            Box box = passenger.getDimensions(passenger.getPose()).getBoxAt(candidate);
            if (this.getWorld().isSpaceEmpty(passenger, box)) {
                return candidate;
            }
        }
        return new Vec3d(this.getX(), this.getBoundingBox().maxY + 0.1, this.getZ());
    }

    // ---- Targetable, indestructible (solid shapes come from the collision parts) --------------

    @Override
    public boolean collidesWith(Entity other) {
        return false;
    }

    @Override
    public boolean canHit() {
        return !this.isRemoved();
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource damageSource) {
        return true;
    }

    @Override
    public boolean isFireImmune() {
        return true;
    }

    // Deliberately without @Override: kept tolerant of small mapping differences.
    public boolean isImmuneToExplosion(net.minecraft.world.explosion.Explosion explosion) {
        return true;
    }

    /** Climb 1-2 block steps (vanilla step logic). */
    public float getStepHeight() {
        return 2.0f;
    }

    /** The model is much larger than the main box (long barrels), so do not cull it too early. */
    public Box getVisibilityBoundingBox() {
        return this.getBoundingBox().expand(3.5, 1.5, 3.5);
    }

    // ---- Persistence -----------------------------------------------------------------------

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
    }
}
