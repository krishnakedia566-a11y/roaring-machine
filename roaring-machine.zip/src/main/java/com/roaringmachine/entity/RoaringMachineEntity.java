package com.roaringmachine.entity;

import java.util.List;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * The Roaring Machine Gun vehicle (a heavy tricycle).
 *
 * Physics run on the server only. The mounted player's W/S/A/D input arrives through
 * DriveInputPayload. Speed, steering and shield state are synced to clients through the data
 * tracker; clients smooth the received positions so driving does not shake.
 */
public class RoaringMachineEntity extends Entity {
    public static final TrackedData<Float> SPEED = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final TrackedData<Float> STEER = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final TrackedData<Boolean> SHIELD = DataTracker.registerData(RoaringMachineEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    // ---- Tuning (blocks per tick) -------------------------------------------------------
    private static final double MAX_FORWARD = 0.32;      // about 6.4 blocks/second
    private static final double MAX_REVERSE = 0.11;
    private static final double ACCEL = 0.0055;          // heavy: ~3 seconds to full speed
    private static final double REVERSE_ACCEL = 0.004;
    private static final double BRAKE = 0.016;           // opposite key = firm braking first
    private static final double COAST = 0.0030;          // slow roll-out when no key is pressed
    private static final float MAX_TURN_DEG = 2.6f;      // degrees per tick at full steer and speed
    private static final double GRAVITY = 0.08;

    // ---- Seat (local, relative to vehicle origin) ------------------------------------
    private static final double SEAT_FORWARD = -1.335;   // negative = behind the centre
    private static final double SEAT_HEIGHT = 0.77;      // player's feet offset above vehicle origin

    private static final float WHEEL_RADIUS = 0.40f;

    // Server state
    private float inputForward;
    private float inputSteer;
    private int inputAge = 100;
    private double speed;
    private float steer;
    private int stuckTicks;
    private int lastShieldToggle = -100;

    // Client animation state (read by the renderer)
    public float wheelAngle;
    public float prevWheelAngle;
    public float steerAngle;
    public float prevSteerAngle;
    public float rotorAngle;
    public float prevRotorAngle;
    public float shieldProgress;
    public float prevShieldProgress;
    public float tiltPitch;
    public float prevTiltPitch;
    public float tiltRoll;
    public float prevTiltRoll;
    private float lastClientSpeed;

    // Client position smoothing
    private double lerpX;
    private double lerpY;
    private double lerpZ;
    private float lerpYaw;
    private int lerpSteps;

    public RoaringMachineEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(SPEED, 0.0f);
        builder.add(STEER, 0.0f);
        builder.add(SHIELD, Boolean.FALSE);
    }

    public void setDriveInput(float forward, float steerInput) {
        this.inputForward = MathHelper.clamp(forward, -1.0f, 1.0f);
        this.inputSteer = MathHelper.clamp(steerInput, -1.0f, 1.0f);
        this.inputAge = 0;
    }

    public boolean isShieldUp() {
        return this.dataTracker.get(SHIELD);
    }

    /** Server side: toggle the protective shield (rate limited so repeated presses cannot spam it). */
    public void toggleShield() {
        if (this.age - lastShieldToggle < 12) {
            return;
        }
        lastShieldToggle = this.age;
        this.dataTracker.set(SHIELD, !this.dataTracker.get(SHIELD));
    }

    // ---- Tick ---------------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) {
            clientTick();
        } else {
            serverTick();
        }
    }

    /** Smooth the 20 Hz server position updates over a few client ticks (removes the vibration). */
    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps) {
        double ox = this.getX();
        double oy = this.getY();
        double oz = this.getZ();
        float oyaw = this.getYaw();
        float opitch = this.getPitch();
        super.updateTrackedPositionAndAngles(x, y, z, yaw, pitch, interpolationSteps);
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYaw = yaw;
        this.lerpSteps = 3;
        this.setPosition(ox, oy, oz);
        this.setYaw(oyaw);
        this.setPitch(opitch);
    }

    private void clientTick() {
        if (lerpSteps > 0) {
            double f = 1.0 / lerpSteps;
            this.setPosition(this.getX() + (lerpX - this.getX()) * f,
                    this.getY() + (lerpY - this.getY()) * f,
                    this.getZ() + (lerpZ - this.getZ()) * f);
            this.setYaw(this.getYaw() + MathHelper.wrapDegrees(lerpYaw - this.getYaw()) * (float) f);
            lerpSteps--;
        }

        prevWheelAngle = wheelAngle;
        prevSteerAngle = steerAngle;
        prevRotorAngle = rotorAngle;
        prevShieldProgress = shieldProgress;
        prevTiltPitch = tiltPitch;
        prevTiltRoll = tiltRoll;

        float s = this.dataTracker.get(SPEED);
        float st = this.dataTracker.get(STEER);
        wheelAngle += (float) (s / WHEEL_RADIUS * 57.29578f);
        steerAngle = st;

        // Gentle suspension feel: squat when accelerating, dip when braking, lean in turns.
        float accel = s - lastClientSpeed;
        lastClientSpeed = s;
        float pitchTarget = MathHelper.clamp(accel * 120.0f, -2.2f, 2.2f);
        float rollTarget = -st * (s / (float) MAX_FORWARD) * 2.2f;
        tiltPitch += (pitchTarget - tiltPitch) * 0.10f;
        tiltRoll += (rollTarget - tiltRoll) * 0.10f;

        float target = this.dataTracker.get(SHIELD) ? 1.0f : 0.0f;
        shieldProgress += MathHelper.clamp(target - shieldProgress, -0.04f, 0.04f);
    }

    private void serverTick() {
        PlayerEntity driver = this.getFirstPassenger() instanceof PlayerEntity p ? p : null;
        inputAge++;
        if (driver == null || inputAge > 6) {
            inputForward = 0.0f;
            inputSteer = 0.0f;
        }

        // --- Speed: gradual acceleration, firm braking, slow roll-out ---
        if (inputForward > 0.5f) {
            speed += (speed < 0.0) ? BRAKE : ACCEL;
        } else if (inputForward < -0.5f) {
            speed -= (speed > 0.0) ? BRAKE : REVERSE_ACCEL;
        } else {
            double coast = (driver == null) ? COAST * 2.0 : COAST;
            if (speed > 0.0) {
                speed = Math.max(0.0, speed - coast);
            } else if (speed < 0.0) {
                speed = Math.min(0.0, speed + coast);
            }
        }
        speed = MathHelper.clamp(speed, -MAX_REVERSE, MAX_FORWARD);

        // --- Steering: smoothed, speed-dependent, no pivoting in place ---
        steer = MathHelper.lerp(0.10f, steer, inputSteer);
        float turnFactor = (float) MathHelper.clamp(speed / 0.10, -1.0, 1.0);
        turnFactor *= (float) (1.0 - 0.35 * Math.min(1.0, Math.abs(speed / MAX_FORWARD)));
        // A (left) = positive steer; in Minecraft a left turn decreases yaw.
        this.setYaw(this.getYaw() - steer * MAX_TURN_DEG * turnFactor);

        // --- Movement ---
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double dirX = -MathHelper.sin(yawRad);
        double dirZ = MathHelper.cos(yawRad);
        double vy = this.isOnGround() ? -0.1 : (this.getVelocity().y - GRAVITY) * 0.98;

        double oldX = this.getX();
        double oldZ = this.getZ();
        this.move(MovementType.SELF, new Vec3d(dirX * speed, vy, dirZ * speed));
        this.setVelocity(dirX * speed, vy, dirZ * speed);

        if (this.horizontalCollision) {
            speed *= 0.6;
        }

        // --- Never get stuck: if the driver pushes but we do not move, hop up over the obstacle/pit rim ---
        double moved = Math.hypot(this.getX() - oldX, this.getZ() - oldZ);
        if (Math.abs(inputForward) > 0.5f && moved < 0.015) {
            stuckTicks++;
            if (stuckTicks >= 25) {
                double sign = inputForward > 0 ? 1.0 : -1.0;
                tryEscape(dirX * sign, dirZ * sign);
                stuckTicks = 0;
            }
        } else {
            stuckTicks = 0;
        }

        // --- Solid: shove ordinary mobs out of our box when we roll into them ---
        if (Math.abs(speed) > 0.02) {
            pushNearbyMobs();
        }

        // --- Sync animation state to clients ---
        this.dataTracker.set(SPEED, (float) speed);
        this.dataTracker.set(STEER, steer);
    }

    private void tryEscape(double dirX, double dirZ) {
        for (int up = 1; up <= 6; up++) {
            Box box = this.getBoundingBox().offset(dirX * 0.8, up, dirZ * 0.8);
            if (this.getWorld().isSpaceEmpty(this, box)) {
                this.setPosition(this.getX() + dirX * 0.8, this.getY() + up, this.getZ() + dirZ * 0.8);
                this.setVelocity(Vec3d.ZERO);
                speed = 0.0;
                return;
            }
        }
    }

    private void pushNearbyMobs() {
        List<Entity> list = this.getWorld().getOtherEntities(this, this.getBoundingBox(),
                e -> e instanceof LivingEntity && !(e instanceof PlayerEntity) && !this.hasPassenger(e));
        for (Entity e : list) {
            double dx = e.getX() - this.getX();
            double dz = e.getZ() - this.getZ();
            double len = Math.hypot(dx, dz);
            if (len < 0.001) {
                continue;
            }
            e.addVelocity(dx / len * 0.3, 0.05, dz / len * 0.3);
            e.velocityModified = true;
        }
    }

    // ---- Seat / riding --------------------------------------------------------------------

    @Override
    protected void updatePassengerPosition(Entity passenger, Entity.PositionUpdater positionUpdater) {
        if (!this.hasPassenger(passenger)) {
            return;
        }
        float yawRad = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double x = this.getX() + (-MathHelper.sin(yawRad)) * SEAT_FORWARD;
        double z = this.getZ() + MathHelper.cos(yawRad) * SEAT_FORWARD;
        double y = this.getY() + SEAT_HEIGHT;
        positionUpdater.accept(passenger, x, y, z);
    }

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (player.shouldCancelInteraction()) {
            return ActionResult.PASS;
        }
        if (!this.getWorld().isClient) {
            return player.startRiding(this) ? ActionResult.CONSUME : ActionResult.PASS;
        }
        return ActionResult.SUCCESS;
    }

    /** Dismount to the side of the machine (outside the hitbox), not on top of it. */
    @Override
    public Vec3d updatePassengerForDismount(LivingEntity passenger) {
        float r = this.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double leftX = MathHelper.cos(r);
        double leftZ = MathHelper.sin(r);
        for (double side : new double[] {2.5, -2.5}) {
            Vec3d candidate = new Vec3d(this.getX() + leftX * side, this.getY(), this.getZ() + leftZ * side);
            Box box = passenger.getDimensions(passenger.getPose()).getBoxAt(candidate);
            if (this.getWorld().isSpaceEmpty(passenger, box)) {
                return candidate;
            }
        }
        return new Vec3d(this.getX(), this.getBoundingBox().maxY + 0.1, this.getZ());
    }

    // ---- Solid, targetable, indestructible -------------------------------------------------

    @Override
    public boolean isCollidable() {
        return true;
    }

    @Override
    public boolean canHit() {
        return !this.isRemoved();
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource damageSource) {
        return true;
    }

    @Override
    public boolean isFireImmune() {
        return true;
    }

    // Deliberately without @Override: kept tolerant of small mapping differences.
    public boolean isImmuneToExplosion(net.minecraft.world.explosion.Explosion explosion) {
        return true;
    }

    /** Climb 1-2 block steps (vanilla step logic). */
    public float getStepHeight() {
        return 2.0f;
    }

    /** The model is much larger than the hitbox (long barrels), so do not cull it too early. */
    public Box getVisibilityBoundingBox() {
        return this.getBoundingBox().expand(2.5, 1.5, 2.5);
    }

    // ---- Persistence -----------------------------------------------------------------------

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
    }
}
