package com.roaringmachine;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** All sound events of the machine (the OGG files are original, synthesized for this mod). */
public class ModSounds {
    public static final SoundEvent ENGINE_LOOP = reg("engine_loop");
    public static final SoundEvent MOVE_LOOP = reg("move_loop");
    public static final SoundEvent STEER_LOOP = reg("steer_loop");
    public static final SoundEvent ROTOR_LOOP = reg("rotor_loop");
    public static final SoundEvent ROTOR_STARTUP = reg("rotor_startup");
    public static final SoundEvent ROTOR_SPINDOWN = reg("rotor_spindown");
    public static final SoundEvent SHIELD_DEPLOY = reg("shield_deploy");
    public static final SoundEvent SHIELD_LOCK = reg("shield_lock");
    public static final SoundEvent SHIELD_RETRACT = reg("shield_retract");
    public static final SoundEvent ENGINE_START = reg("engine_start");
    public static final SoundEvent ENGINE_STOP = reg("engine_stop");
    public static final SoundEvent GEAR_CLUNK = reg("gear_clunk");
    public static final SoundEvent SUSPENSION_CLUNK = reg("suspension_clunk");
    public static final SoundEvent BRAKE_HISS = reg("brake_hiss");

    private static SoundEvent reg(String name) {
        Identifier id = Identifier.of(RoaringMachineMod.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        // Loading this class registers the sound events.
    }
}
