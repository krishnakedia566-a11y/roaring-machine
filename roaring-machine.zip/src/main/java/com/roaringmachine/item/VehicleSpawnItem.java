package com.roaringmachine.item;

import com.roaringmachine.ModEntities;
import com.roaringmachine.entity.RoaringMachineEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Right-click on a block to place the Roaring Machine Gun there. */
public class VehicleSpawnItem extends Item {
    public VehicleSpawnItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        if (!(world instanceof ServerWorld serverWorld)) {
            return ActionResult.SUCCESS;
        }

        BlockPos pos = context.getBlockPos().offset(context.getSide());
        Vec3d spawnPos = Vec3d.ofBottomCenter(pos);

        RoaringMachineEntity machine = ModEntities.ROARING_MACHINE.create(serverWorld);
        if (machine == null) {
            return ActionResult.FAIL;
        }
        machine.refreshPositionAndAngles(spawnPos.x, spawnPos.y, spawnPos.z, context.getPlayerYaw(), 0.0f);
        serverWorld.spawnEntity(machine);

        context.getStack().decrementUnlessCreative(1, context.getPlayer());
        return ActionResult.CONSUME;
    }
}
