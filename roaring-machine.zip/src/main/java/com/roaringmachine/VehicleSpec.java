package com.roaringmachine;

/** Shared size constants. The model is designed in "design blocks" and rendered at SCALE times that size. */
public final class VehicleSpec {
    /** Design block -> real block scale (the model uses 38 units per design block, rendered at 1/32 block per unit). */
    public static final float SCALE = 38.0f / 32.0f;

    private VehicleSpec() {
    }
}
