package com.roaringmachine.network;

import com.roaringmachine.RoaringMachineMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: the mounted player pressed the dedicated exit key. */
public record ExitPayload() implements CustomPayload {
    public static final CustomPayload.Id<ExitPayload> ID =
            new CustomPayload.Id<>(Identifier.of(RoaringMachineMod.MOD_ID, "exit"));

    public static final PacketCodec<RegistryByteBuf, ExitPayload> CODEC = PacketCodec.unit(new ExitPayload());

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
