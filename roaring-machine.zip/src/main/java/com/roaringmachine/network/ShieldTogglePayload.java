package com.roaringmachine.network;

import com.roaringmachine.RoaringMachineMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: the mounted player pressed the shield key. */
public record ShieldTogglePayload() implements CustomPayload {
    public static final CustomPayload.Id<ShieldTogglePayload> ID =
            new CustomPayload.Id<>(Identifier.of(RoaringMachineMod.MOD_ID, "shield_toggle"));

    public static final PacketCodec<RegistryByteBuf, ShieldTogglePayload> CODEC =
            PacketCodec.unit(new ShieldTogglePayload());

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
