package com.roaringmachine.network;

import com.roaringmachine.RoaringMachineMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Driving input sent every tick by the mounted player: forward (+1 W / -1 S), steer (+1 A = left / -1 D = right), fire (left mouse held). */
public record DriveInputPayload(float forward, float steer, boolean fire) implements CustomPayload {
    public static final CustomPayload.Id<DriveInputPayload> ID =
            new CustomPayload.Id<>(Identifier.of(RoaringMachineMod.MOD_ID, "drive_input"));

    public static final PacketCodec<RegistryByteBuf, DriveInputPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.FLOAT, DriveInputPayload::forward,
            PacketCodecs.FLOAT, DriveInputPayload::steer,
            PacketCodecs.BOOL, DriveInputPayload::fire,
            DriveInputPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
