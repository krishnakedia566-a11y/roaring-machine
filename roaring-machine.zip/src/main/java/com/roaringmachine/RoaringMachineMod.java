package com.roaringmachine;

import com.roaringmachine.entity.RoaringMachineEntity;
import com.roaringmachine.network.DriveInputPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

public class RoaringMachineMod implements ModInitializer {
    public static final String MOD_ID = "roaringmachine";

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();

        // Client -> server: driving input (W/S/A/D) while mounted.
        PayloadTypeRegistry.playC2S().register(DriveInputPayload.ID, DriveInputPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(DriveInputPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.getVehicle() instanceof RoaringMachineEntity machine
                    && machine.getFirstPassenger() == player) {
                machine.setDriveInput(payload.forward(), payload.steer());
            }
        });
    }
}
