package com.roaringmachine;

import com.roaringmachine.entity.RoaringMachineEntity;
import com.roaringmachine.network.DriveInputPayload;
import com.roaringmachine.network.ExitPayload;
import com.roaringmachine.network.ShieldTogglePayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;

public class RoaringMachineMod implements ModInitializer {
    public static final String MOD_ID = "roaringmachine";

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
        ModSounds.register();

        // Client -> server: driving input (W/S/A/D) while mounted.
        PayloadTypeRegistry.playC2S().register(DriveInputPayload.ID, DriveInputPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(DriveInputPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.getVehicle() instanceof RoaringMachineEntity machine
                    && machine.getFirstPassenger() == player) {
                machine.setDriveInput(payload.forward(), payload.steer(), payload.fire());
            }
        });

        // Client -> server: toggle the protective shield.
        PayloadTypeRegistry.playC2S().register(ShieldTogglePayload.ID, ShieldTogglePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ShieldTogglePayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.getVehicle() instanceof RoaringMachineEntity machine
                    && machine.getFirstPassenger() == player) {
                machine.toggleShield();
            }
        });

        // Client -> server: dedicated exit key.
        PayloadTypeRegistry.playC2S().register(ExitPayload.ID, ExitPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ExitPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.getVehicle() instanceof RoaringMachineEntity) {
                player.stopRiding();
            }
        });

        // While mounted, vanilla left/right click actions must not fire on their own (left click = the guns).
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) ->
                player.getVehicle() instanceof RoaringMachineEntity ? ActionResult.FAIL : ActionResult.PASS);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) ->
                player.getVehicle() instanceof RoaringMachineEntity ? ActionResult.FAIL : ActionResult.PASS);
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) ->
                player.getVehicle() instanceof RoaringMachineEntity ? ActionResult.FAIL : ActionResult.PASS);

        // Shield protection: while the shield is up, the rider takes NO damage from any direction or any source
        // (mobs, arrows, explosions, fire, lava, fall, magic, drowning...). Only void and /kill still work so nobody gets stuck.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity player
                    && player.getVehicle() instanceof RoaringMachineEntity machine
                    && machine.isShieldUp()
                    && !source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                machine.onShieldBlocked(player);
                return false;
            }
            return true;
        });
    }
}
