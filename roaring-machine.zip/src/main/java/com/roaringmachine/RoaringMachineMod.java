package com.roaringmachine;

import com.roaringmachine.entity.RoaringMachineEntity;
import com.roaringmachine.network.DriveInputPayload;
import com.roaringmachine.network.ShieldTogglePayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.MathHelper;

public class RoaringMachineMod implements ModInitializer {
    public static final String MOD_ID = "roaringmachine";

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();

        // Client -> server: driving input (W/S/A/D) while mounted.
        PayloadTypeRegistry.playC2S().register(DriveInputPayload.ID, DriveInputPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(DriveInputPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.getVehicle() instanceof RoaringMachineEntity machine
                    && machine.getFirstPassenger() == player) {
                machine.setDriveInput(payload.forward(), payload.steer());
            }
        });

        // Client -> server: toggle the protective shield.
        PayloadTypeRegistry.playC2S().register(ShieldTogglePayload.ID, ShieldTogglePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ShieldTogglePayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.getVehicle() instanceof RoaringMachineEntity machine
                    && machine.getFirstPassenger() == player) {
                machine.toggleShield();
            }
        });

        // Shield protection: attacks and projectiles coming from the front never reach the rider.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity player
                    && player.getVehicle() instanceof RoaringMachineEntity machine
                    && machine.isShieldUp()) {
                Entity from = source.getSource() != null ? source.getSource() : source.getAttacker();
                if (from != null) {
                    float yawRad = machine.getYaw() * MathHelper.RADIANS_PER_DEGREE;
                    double fx = -MathHelper.sin(yawRad);
                    double fz = MathHelper.cos(yawRad);
                    double dx = from.getX() - machine.getX();
                    double dz = from.getZ() - machine.getZ();
                    if (dx * fx + dz * fz > 0.0) {
                        return false;
                    }
                }
            }
            return true;
        });
    }
}
