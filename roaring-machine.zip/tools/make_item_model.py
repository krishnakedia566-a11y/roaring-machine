"""Builds a small 3D item model (JSON elements) of the machine from the generator's boxes, for the inventory/hand item."""
import json, math, shutil
import numpy as np
from PIL import Image
import mm_core
from mm_core import U

OUT = '/home/claude/proj/src/main/resources/assets/roaringmachine'
LEN_PX = 30.0                       # model length in item pixels (16 px = 1 block)
K = LEN_PX / (5.1 * U)               # item pixels per model unit
MAX_ELEMENTS = 330


def walk(roots):
    boxes = []
    def rec(node, M, t):
        px, ph, pz = node.pivot
        p = np.array([px * U, -ph * U, pz * U])
        t2 = t + M @ p
        R = mm_core.rot_zyx(*node.rot)
        M2 = M @ R
        skip = node.translucent or node.flash or node.name == 'fp_arms' or not np.allclose(R, np.eye(3), atol=1e-6)
        if not skip:
            for b in node.boxes:
                lo = M2 @ np.array([b['x0'], -b['h1'], b['z0']]) + t2
                hi = M2 @ np.array([b['x1'], -b['h0'], b['z1']]) + t2
                boxes.append((b, lo, hi))
        for k in node.kids:
            if not np.allclose(mm_core.rot_zyx(*k.rot), np.eye(3), atol=1e-6) and k.name in ('tread', 'link', 'chevron', 'fender_fr', 'fender_rr', 'fender_f', 'fender_b', 'bank', 'seatback'):
                continue
            rec(k, M2, t2)
    for r in roots:
        rec(r, np.eye(3), np.zeros(3))
    return boxes


def face_uv(b):
    dx, dy, dz = b['dx'], b['dy'], b['dz']
    u, v = b['u'], b['v']
    return {
        'up': (u + dz, v, dx, dz),
        'down': (u + dz + dx, v, dx, dz),
        'east': (u, v + dz, dz, dy),          # JSON east (+x, vehicle right) <- cuboid west
        'north': (u + dz, v + dz, dx, dy),
        'west': (u + dz + dx, v + dz, dz, dy),
        'south': (u + 2 * dz + dx, v + dz, dx, dy),
    }


def element(b, lo, hi, tex_w, tex_h):
    # model frame: x left+, y down+, z back+  ->  item frame: x right+, y up+, z back+
    x0 = 8.0 - max(lo[0], hi[0]) * K
    x1 = 8.0 - min(lo[0], hi[0]) * K
    y0 = 2.0 - max(lo[1], hi[1]) * K
    y1 = 2.0 - min(lo[1], hi[1]) * K
    z0 = 8.0 + min(lo[2], hi[2]) * K
    z1 = 8.0 + max(lo[2], hi[2]) * K
    faces = {}
    for name, (fu, fv, fw, fh) in face_uv(b).items():
        faces[name] = {"uv": [fu, fv, fu + fw, fv + fh], "texture": "#t"}
    return {"from": [round(x0, 3), round(y0, 3), round(z0, 3)], "to": [round(x1, 3), round(y1, 3), round(z1, 3)], "faces": faces}


def build(roots, atlas_img_path, tex_w, tex_h):
    boxes = walk(roots)
    # sort by volume (big first) and keep the most visible ones
    def vol(t):
        b, lo, hi = t
        d = np.abs(hi - lo)
        return d[0] * d[1] * d[2]
    boxes.sort(key=vol, reverse=True)
    boxes = [t for t in boxes if vol(t) * (K ** 3) > 0.9][:MAX_ELEMENTS]
    elements = [element(b, lo, hi, tex_w, tex_h) for (b, lo, hi) in boxes]

    # reference texture regions for the synthetic parts
    def region_of(style):
        for (b, lo, hi) in boxes:
            if b['style'] == style:
                return b
        return boxes[0][0]
    chrome = region_of('chrome'); rubber = region_of('rubber'); red = region_of('red'); steel2 = region_of('steel2')

    def solid(x0, x1, y0, y1, z0, z1, ref, rot=None):
        faces = {}
        for name, (fu, fv, fw, fh) in face_uv(ref).items():
            faces[name] = {"uv": [fu, fv, fu + max(2, min(fw, 8)), fv + max(2, min(fh, 8))], "texture": "#t"}
        e = {"from": [x0, y0, z0], "to": [x1, y1, z1], "faces": faces}
        if rot:
            e["rotation"] = rot
        return e

    # main rotor drum + two side cannons (chrome cylinders as boxes)
    def px(xd):   # design x (left +) -> item x
        return 8.0 - xd * 5.9
    def py(hd):
        return 2.0 + hd * 5.9
    def pz(zd):
        return 8.0 + zd * 5.9
    elements.append(solid(px(0.43), px(-0.43), py(1.78 - 0.43), py(1.78 + 0.43), pz(-2.70), pz(-1.0), chrome))
    for sx in (1, -1):
        elements.append(solid(px(0.66 * sx + 0.17), px(0.66 * sx - 0.17), py(1.38 - 0.17), py(1.38 + 0.17), pz(-2.35), pz(-0.55), chrome))
    # wheels: octagon built from rotated slabs (22.5 degree steps are allowed by the format)
    for (cx, cz, r, hw) in ((1.10, 1.62, 0.45, 0.17), (-1.10, 1.62, 0.45, 0.17), (0.0, -1.40, 0.45, 0.17)):
        for ang in (0, 22.5, 45, 67.5):
            e = solid(px(cx + hw), px(cx - hw), py(0.45 - r * 0.9), py(0.45 + r * 0.9), pz(cz - r * 0.9), pz(cz + r * 0.9), rubber,
                      {"origin": [px(cx), py(0.45), pz(cz)], "axis": "x", "angle": ang})
            elements.append(e)
        elements.append(solid(px(cx + hw + 0.01), px(cx - hw - 0.01), py(0.45 - 0.22), py(0.45 + 0.22), pz(cz - 0.22), pz(cz + 0.22), steel2))
    # red fenders
    for cx in (1.10, -1.10):
        elements.append(solid(px(cx + 0.2), px(cx - 0.2), py(0.98), py(1.06), pz(1.62 - 0.45), pz(1.62 + 0.45), red))
    elements.append(solid(px(0.27), px(-0.27), py(0.93), py(1.0), pz(-1.40 - 0.45), pz(-1.40 + 0.45), red))

    model = {
        "texture_size": [tex_w, tex_h],
        "textures": {"particle": "roaringmachine:item/roaring_machine_model", "t": "roaringmachine:item/roaring_machine_model"},
        "elements": elements,
        "display": {
            "gui": {"rotation": [28, 35, 0], "translation": [0, -0.5, 0], "scale": [0.46, 0.46, 0.46]},
            "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.30, 0.30, 0.30]},
            "fixed": {"rotation": [0, 90, 0], "translation": [0, 0, 0], "scale": [0.38, 0.38, 0.38]},
            "thirdperson_righthand": {"rotation": [10, 90, 0], "translation": [0, 3, 0], "scale": [0.24, 0.24, 0.24]},
            "thirdperson_lefthand": {"rotation": [10, 90, 0], "translation": [0, 3, 0], "scale": [0.24, 0.24, 0.24]},
            "firstperson_righthand": {"rotation": [0, 100, 0], "translation": [2, 2, 0], "scale": [0.28, 0.28, 0.28]},
            "firstperson_lefthand": {"rotation": [0, 100, 0], "translation": [2, 2, 0], "scale": [0.28, 0.28, 0.28]},
        },
    }
    # vanilla block-model UVs are in 0..16 space, NOT pixels -> rescale (pixel UVs made the model fail to render)
    for e in model['elements']:
        for f in e['faces'].values():
            u0, v0, u1, v1 = f['uv']
            f['uv'] = [round(u0 * 16.0 / tex_w, 4), round(v0 * 16.0 / tex_h, 4), round(u1 * 16.0 / tex_w, 4), round(v1 * 16.0 / tex_h, 4)]
    model.pop('texture_size', None)
    json.dump(model, open(OUT + '/models/item/roaring_machine_spawner.json', 'w'))
    shutil.copy(atlas_img_path, OUT + '/textures/item/roaring_machine_model.png')
    return len(elements)
