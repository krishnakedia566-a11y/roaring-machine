import sys, importlib, math
import numpy as np
from PIL import Image
import mm_core, mm_model
importlib.reload(mm_core); importlib.reload(mm_model)
from mm_core import Atlas, Codegen, render_preview

roots = mm_model.build()
for _r in roots: mm_core.fix_zfight(_r)
boxes = []
for r in roots:
    boxes.extend(list(r.all_boxes()))
print('boxes:', len(boxes), 'quads ~', len(boxes)*6)
atlas = Atlas(1024)
H = atlas.pack(boxes)
print('atlas', atlas.width, H)
img = atlas.paint(boxes)
Image.fromarray(img, 'RGBA').save('/home/claude/atlas.png')

cg = Codegen()
src = cg.generate(roots, atlas.width, H)
open('/home/claude/ModelGen.java', 'w').write(src)
print('java chars', len(src), 'methods', len(cg.methods))

views = {
    'closeseat': (150, 20), 'closefront': (25, 10),
    'side': (90, 5), 'three': (35, 18), 'front': (0, 6), 'rear': (180, 14), 'top': (60, 70),
}
sel = sys.argv[1:] or ['side', 'three']
for k in sel:
    yaw, pit = views[k]
    tgt=(0.0,1.0,0.0); dist=8.5
    if k=='closeseat': tgt=(0.0,1.6,1.0); dist=4.2
    if k=='closefront': tgt=(0.0,1.2,-1.6); dist=4.8
    render_preview([x for x in roots if not x.flash], img, f'/home/claude/prev_{k}.png', cam_yaw=yaw, cam_pitch=pit, dist=dist, size=(1100, 640), target=tgt)
    print('rendered', k)
