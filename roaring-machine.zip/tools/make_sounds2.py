import numpy as np, subprocess, os, wave
from scipy import signal

SR = 44100
OUT = '/home/claude/proj/src/main/resources/assets/roaringmachine/sounds'
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(11)


def T(d):
    return np.arange(int(SR * d)) / SR


def lp(x, fc, o=4):
    return signal.sosfilt(signal.butter(o, fc, 'low', fs=SR, output='sos'), x)


def hp(x, fc, o=4):
    return signal.sosfilt(signal.butter(o, fc, 'high', fs=SR, output='sos'), x)


def bp(x, f0, f1, o=3):
    return signal.sosfilt(signal.butter(o, [f0, f1], 'band', fs=SR, output='sos'), x)


def noise(n):
    return rng.standard_normal(n)


def add(dst, src, at):
    i = int(at * SR)
    n = min(len(src), len(dst) - i)
    if n > 0 and i >= 0:
        dst[i:i + n] += src[:n]


def burst_sine(f, d, decay, f_drop=0.0):
    t = T(d)
    ff = f * (1 + f_drop * np.exp(-t / 0.02))
    ph = 2 * np.pi * np.cumsum(ff) / SR
    return np.sin(ph) * np.exp(-t / decay)


def burst_noise(d, decay, lo, hi):
    n = int(SR * d)
    x = bp(noise(n), lo, hi)
    return x * np.exp(-np.arange(n) / SR / decay)


def plus(a, b):
    n = max(len(a), len(b))
    out = np.zeros(n)
    out[:len(a)] += a
    out[:len(b)] += b
    return out


def norm(x, peak=0.85):
    m = np.max(np.abs(x)) + 1e-9
    return x / m * peak


def fade(x, a=0.005, b=0.02):
    n = len(x)
    na, nb = int(a * SR), int(b * SR)
    x = x.copy()
    x[:na] *= np.linspace(0, 1, na)
    x[-nb:] *= np.linspace(1, 0, nb)
    return x


def loopify(x, xf=0.25):
    """Make a seamless loop by cross-fading the tail into the head."""
    n = int(xf * SR)
    body = x[:-n].copy()
    tail = x[-n:]
    w = np.linspace(0, 1, n)
    body[:n] = body[:n] * w + tail * (1 - w)
    return body


def save(name, x):
    x = np.clip(x, -1, 1)
    wav = f'/tmp/{name}.wav'
    with wave.open(wav, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', wav, '-c:a', 'libvorbis', '-q:a', '4', f'{OUT}/{name}.ogg'], check=True)



import scipy.io.wavfile as wf

def sweep_phase(f0, f1, d, n):
    t = np.arange(n) / SR
    r = f1 / f0
    return 2 * np.pi * f0 * d / np.log(r) * (r ** (t / d) - 1)



def load(path):
    sr, x = wf.read(path)
    return x.astype(np.float64) / 32768.0

ENG = load('/tmp/eng.wav')
MG = load('/tmp/mg.wav')
SHOT_T = [0.049, 0.140, 0.227, 0.312, 0.404, 0.493, 0.580, 0.667, 0.754, 0.847, 0.932, 1.018, 1.104, 1.193, 1.282, 1.367]


def pnoise(n, f0, f1):
    """Exactly periodic band-limited noise (random phases in the FFT band) so loops are seamless."""
    spec = np.zeros(n // 2 + 1, dtype=complex)
    freqs = np.fft.rfftfreq(n, 1 / SR)
    band = (freqs >= f0) & (freqs <= f1)
    spec[band] = np.exp(1j * rng.uniform(0, 2 * np.pi, band.sum()))
    x = np.fft.irfft(spec, n)
    return x / (np.std(x) + 1e-9)


def wrap_add(dst, src, at):
    n = len(dst)
    i0 = int(at * SR) % n
    k = min(len(src), n - i0)
    dst[i0:i0 + k] += src[:k]
    if k < len(src):
        rest = src[k:]
        m = min(len(rest), n)
        dst[:m] += rest[:m]


def seg(x, a, b):
    return x[int(a * SR):int(b * SR)].copy()


def drive(x, amt=2.0):
    return np.tanh(x * amt) / np.tanh(amt)


def resample(x, factor):
    """factor > 1 = faster/higher pitch."""
    n = int(len(x) / factor)
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x)


def clank(scale=1.0, d=0.06, amp=1.0):
    """Metallic impact: a few inharmonic decaying modes plus a noise tick."""
    t = T(d)
    x = np.zeros(len(t))
    for f, a, dec in ((820, 1.0, 0.030), (1370, 0.7, 0.022), (2210, 0.5, 0.016), (3150, 0.35, 0.012), (4400, 0.2, 0.008)):
        f2 = f * scale * (1 + rng.uniform(-0.03, 0.03))
        x += a * np.sin(2 * np.pi * f2 * t + rng.uniform(0, 6.28)) * np.exp(-t / dec)
    x += 0.6 * hp(noise(len(t)), 1800) * np.exp(-t / 0.004)
    return x * amp


# ------------------------------------------------------------------ engine (from the provided roar) ----
def engine_loop():
    x = seg(ENG, 0.72, 1.78)
    x = drive(hp(x, 60), 1.8)
    x = loopify(x, 0.28)
    return norm(x, 0.85)

def engine_start():
    d = 2.2
    n = int(SR * d)
    x = np.zeros(n)
    ph = sweep_phase(95, 300, 0.55, int(0.55 * SR))
    st = (np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)) * np.sin(np.linspace(0, np.pi, len(ph))) ** 0.6
    add(x, lp(st, 2400) * 0.40, 0.0)
    add(x, bp(noise(int(0.5 * SR)), 300, 2200) * 0.20, 0.0)
    add(x, clank(0.7, 0.08, 0.7), 0.0)
    roar = seg(ENG, 0.0, 1.9)
    roar = roar * np.concatenate([np.linspace(0, 1, int(0.1 * SR)), np.ones(len(roar) - int(0.1 * SR))])
    add(x, roar * 1.0, 0.45)
    return norm(fade(drive(x, 1.6), 0.003, 0.15), 0.85)


def engine_stop():
    tail = resample(seg(ENG, 2.1, 4.0), 0.88)
    x = np.zeros(len(tail) + int(0.3 * SR))
    add(x, tail, 0.0)
    add(x, plus(burst_sine(70, 0.3, 0.1, 0.4) * 0.6, clank(0.6, 0.1, 0.5)), len(tail) / SR - 0.25)
    return norm(fade(drive(x, 1.4), 0.003, 0.12), 0.8)


# ------------------------------------------------------------------ rolling / steering ----
def move_loop():
    d = 2.0
    n = int(SR * d)
    t = T(d)
    base = pnoise(n, 110, 1800) * 0.9 + pnoise(n, 30, 400) * 0.6
    x = base * (0.8 + 0.2 * np.sin(2 * np.pi * 5 * t))
    for i in range(int(d * 9)):                      # metallic track / chain taps (wrapped = seamless)
        wrap_add(x, clank(1.0 + 0.05 * ((i * 5) % 3), 0.045, 0.30), i / 9.0 + rng.uniform(-0.01, 0.01))
    body = loopify(lp(seg(ENG, 0.8, 3.05), 500), 0.25)
    m = min(len(body), n)
    x[:m] += 0.35 * body[:m]
    return norm(drive(x, 1.6), 0.8)

def steer_loop():
    d = 1.0
    n = int(SR * d)
    t = T(d)
    x = 0.55 * np.sin(2 * np.pi * 520 * t) * (0.7 + 0.3 * np.sin(2 * np.pi * 6 * t))
    x += 0.30 * np.sin(2 * np.pi * 1040 * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t))
    x += 0.30 * np.sin(2 * np.pi * 260 * t) * (0.7 + 0.3 * np.sin(2 * np.pi * 3 * t))
    x += 0.30 * pnoise(n, 700, 3000)
    return norm(drive(x, 1.4), 0.55)

def rotor_loop():
    d = 1.0
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    am = 0.65 + 0.35 * np.sin(2 * np.pi * 24 * t)
    x += 0.32 * np.sin(2 * np.pi * 640 * t) * am + 0.20 * np.sin(2 * np.pi * 1280 * t) * am + 0.12 * np.sin(2 * np.pi * 1920 * t) * am
    x += 0.30 * np.sin(2 * np.pi * 96 * t) + 0.22 * np.sin(2 * np.pi * 192 * t) + 0.12 * np.sin(2 * np.pi * 288 * t)
    for i in range(36):                              # fast metallic movement
        wrap_add(x, clank(1.0 + 0.04 * ((i * 7) % 5), 0.04, 0.22), i / 36.0)
    for i in range(6):                               # restrained accents
        wrap_add(x, plus(burst_sine(90, 0.16, 0.05, 0.3) * 0.5, burst_sine(180, 0.1, 0.03) * 0.25), i / 6.0)
    return norm(drive(x, 1.5), 0.8)

def rotor_startup():
    d = 1.45
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    add(x, plus(burst_sine(70, 0.3, 0.1, 0.5) * 0.9, clank(0.8, 0.14, 1.0)), 0.0)    # activation: heavy metal clack
    ph = sweep_phase(240, 560, 0.3, int(0.3 * SR))
    add(x, np.sin(ph) * np.exp(-np.arange(len(ph)) / SR / 0.2) * 0.4, 0.02)
    ph = sweep_phase(150, 2600, 1.35, n)             # rising rotary whine (audible on phone speakers)
    amp = (t / 1.35) ** 1.5
    w = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)
    x += 0.34 * w * amp
    body = resample(seg(ENG, 0.0, 1.2), 0.8)
    add(x, body[:n] * 0.55 * np.linspace(0.2, 1.0, min(n, len(body))), 0.05)
    rate = 5 + 36 * (t / 1.35) ** 2
    cum = np.cumsum(rate) / SR
    last = 0
    for i in range(1, n):
        if int(cum[i]) > last:
            last = int(cum[i])
            add(x, clank(1.0 + 0.1 * (t[i] / 1.35), 0.04, 0.12 + 0.4 * (t[i] / 1.35)), t[i])
    add(x, plus(burst_sine(75, 0.25, 0.07, 0.3) * 0.8, clank(1.2, 0.1, 0.6)), 1.30)  # final lock-in accent
    return norm(fade(drive(lp(x, 9000), 1.5), 0.003, 0.03), 0.88)


def rotor_spindown():
    d = 2.4
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    ph = sweep_phase(2400, 90, 2.2, n)
    amp = np.clip(1 - t / 2.2, 0, 1) ** 1.1
    w = np.sin(ph) + 0.45 * np.sin(2 * ph) + 0.2 * np.sin(3 * ph)
    x += 0.32 * w * amp
    tail = resample(seg(ENG, 1.9, 4.0), 0.85)
    add(x, tail[:n] * 0.5 * np.clip(1 - t[:min(n, len(tail))] / 2.2, 0, 1), 0.0)
    rate = 36 * np.clip(1 - t / 2.2, 0.02, 1) ** 1.3 + 2.5
    cum = np.cumsum(rate) / SR
    last = 0
    for i in range(1, n):
        if int(cum[i]) > last and t[i] < 2.25:
            last = int(cum[i])
            add(x, clank(0.9 + 0.2 * amp[i], 0.04, 0.10 + 0.35 * amp[i]), t[i])
    add(x, plus(burst_sine(65, 0.35, 0.12, 0.3) * 0.7, clank(0.7, 0.12, 0.5)), 2.05)
    return norm(fade(drive(lp(x, 8500), 1.4), 0.005, 0.1), 0.85)


def fire_loop():
    a = SHOT_T[1] - 0.030
    b = SHOT_T[13] - 0.030
    x = seg(MG, a, b)
    n = len(x)
    # extra boom under every shot
    for tt in SHOT_T[1:13]:
        add(x, plus(burst_sine(85, 0.14, 0.05, 0.4) * 0.55, burst_sine(170, 0.08, 0.03) * 0.25), tt - a - 0.004)
    x = loopify(np.concatenate([x, x[:int(0.04 * SR)]]), 0.04)
    return norm(drive(x, 1.5), 0.92)


# ------------------------------------------------------------------ shield and vehicle accents (mid-heavy) ----
def shield_deploy():
    d = 1.1
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    ph = sweep_phase(500, 1500, 0.2, int(0.2 * SR))
    add(x, np.sin(ph) * np.exp(-np.arange(len(ph)) / SR / 0.12) * 0.35, 0.0)      # electronic start
    ph = sweep_phase(180, 430, 0.9, int(0.9 * SR))                                   # servo rising
    serv = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.3 * np.sin(3 * ph)
    env = np.sin(np.linspace(0, np.pi, len(ph))) ** 0.7
    add(x, lp(serv, 1800) * env * 0.32, 0.08)
    sl = bp(noise(int(0.8 * SR)), 600, 2600) * np.sin(np.linspace(0, np.pi, int(0.8 * SR))) ** 1.5
    add(x, sl * 0.30, 0.15)                                                         # metallic slide
    add(x, burst_sine(75, 0.2, 0.06, 0.3) * 0.5, 0.95)                              # settle
    return norm(fade(x, 0.003, 0.05), 0.8)


def shield_lock():
    d = 0.3
    x = np.zeros(int(SR * d))
    add(x, burst_noise(0.1, 0.02, 1000, 4500) * 0.9, 0.0)
    add(x, burst_sine(92, 0.22, 0.07, 0.4) * 0.85, 0.0)
    add(x, burst_noise(0.05, 0.012, 1500, 5000) * 0.45, 0.07)
    return norm(fade(x, 0.001, 0.04), 0.8)


def shield_retract():
    d = 1.0
    n = int(SR * d)
    x = np.zeros(n)
    ph = sweep_phase(1200, 400, 0.22, int(0.22 * SR))
    add(x, np.sin(ph) * np.exp(-np.arange(len(ph)) / SR / 0.12) * 0.3, 0.0)         # electronic down-chirp
    ph = sweep_phase(430, 150, 0.8, int(0.8 * SR))
    serv = np.sin(ph) + 0.5 * np.sin(2 * ph)
    env = np.sin(np.linspace(0, np.pi, len(ph))) ** 0.6
    add(x, lp(serv, 1500) * env * 0.34, 0.05)
    sl = bp(noise(int(0.7 * SR)), 400, 2000) * np.sin(np.linspace(0, np.pi, int(0.7 * SR))) ** 1.2
    add(x, sl * 0.26, 0.12)
    add(x, burst_sine(60, 0.25, 0.08, 0.3) * 0.65, 0.78)
    add(x, burst_noise(0.04, 0.01, 500, 2200) * 0.3, 0.78)
    return norm(fade(x, 0.003, 0.05), 0.8)


# ------------------------------------------------------------------ vehicle transitions ----
def gear_clunk():
    x = np.zeros(int(SR * 0.35))
    add(x, burst_sine(82, 0.25, 0.08, 0.35) * 0.9, 0.0)
    add(x, burst_noise(0.07, 0.015, 900, 3500) * 0.55, 0.0)
    add(x, burst_sine(1200, 0.08, 0.02) * 0.2, 0.01)
    return norm(fade(x, 0.001, 0.05), 0.75)


def suspension_clunk():
    d = 0.5
    x = np.zeros(int(SR * d))
    add(x, burst_sine(70, 0.3, 0.09, 0.5) * 0.85, 0.0)
    ph = sweep_phase(320, 170, 0.28, int(0.28 * SR))
    add(x, np.sin(ph) * np.exp(-np.arange(len(ph)) / SR / 0.12) * 0.16, 0.03)
    add(x, burst_noise(0.1, 0.03, 300, 2200) * 0.35, 0.0)
    return norm(fade(lp(x, 4000), 0.002, 0.08), 0.7)


def brake_hiss():
    d = 0.8
    n = int(SR * d)
    x = bp(noise(n), 2500, 8000) * np.exp(-np.arange(n) / SR / 0.25)
    x += 0.5 * bp(noise(n), 400, 1500) * np.exp(-np.arange(n) / SR / 0.12)
    add(x, burst_sine(60, 0.2, 0.07, 0.3) * 0.5, 0.0)
    return norm(fade(x, 0.003, 0.1), 0.6)


sounds = {
    'engine_loop': engine_loop, 'move_loop': move_loop, 'steer_loop': steer_loop, 'fire_loop': fire_loop,
    'rotor_loop': rotor_loop, 'rotor_startup': rotor_startup, 'rotor_spindown': rotor_spindown,
    'shield_deploy': shield_deploy, 'shield_lock': shield_lock, 'shield_retract': shield_retract,
    'engine_start': engine_start, 'engine_stop': engine_stop, 'gear_clunk': gear_clunk,
    'suspension_clunk': suspension_clunk, 'brake_hiss': brake_hiss,
}
for name, fn in sounds.items():
    x = fn()
    save(name, x)
    print(name, '%.2fs' % (len(x) / SR), 'peak %.2f' % np.max(np.abs(x)), os.path.getsize(f'{OUT}/{name}.ogg') // 1024, 'KB')
