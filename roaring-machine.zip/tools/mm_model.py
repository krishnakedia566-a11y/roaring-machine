import math
from mm_core import Node

PI = math.pi

# ---- key layout constants (blocks) ----
WR = 0.45            # wheel radius
RW_X = 1.10          # rear wheel x offset
RW_Z = 1.62          # rear axle z
FW_Z = -1.40         # front wheel z
GUN_H = 1.78         # main gun axis height
GUN_Z0, GUN_Z1 = -2.70, -1.00  # main rotor extents
SHIELD_Z = 0.64
SHIELD_H = 2.32
RH = 0.44            # receiver half size
SEAT_TOP = 1.60


# ---------------- helpers ----------------
def tz(n, style, x, h, z0, z1, r, **kw):
    n.box(style, x - r, x + r, h - r, h + r, z0, z1, axis='z', **kw)


def tx(n, style, x0, x1, h, z, r, **kw):
    n.box(style, x0, x1, h - r, h + r, z - r, z + r, axis='x', **kw)


def ty(n, style, x, h0, h1, z, r, **kw):
    n.box(style, x - r, x + r, h0, h1, z - r, z + r, axis='y', **kw)


def pipe(n, style, pts, r, **kw):
    """Polyline of axis-aligned segments through pts [(x,h,z),...]."""
    for (a, b) in zip(pts[:-1], pts[1:]):
        dx, dh, dz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
        if abs(dx) > 1e-6:
            tx(n, style, min(a[0], b[0]) - r, max(a[0], b[0]) + r, a[1], a[2], r, **kw)
        elif abs(dh) > 1e-6:
            ty(n, style, a[0], min(a[1], b[1]) - r, max(a[1], b[1]) + r, a[2], r, **kw)
        else:
            tz(n, style, a[0], a[1], min(a[2], b[2]) - r, max(a[2], b[2]) + r, r, **kw)


def ring_z(n, style, x, h, z, r, rad_th, thick, seg_n=12, name='ringseg', **kw):
    """Polygon ring around a z-axis (e.g. barrel band). r = mid radius."""
    seg = 2 * PI * r / seg_n * 1.08
    for k in range(seg_n):
        a = 2 * PI * k / seg_n
        g = n.group(name, pivot=(x + r * math.cos(a), h - r * math.sin(a), z), rot=(0, 0, a - PI / 2))
        g.box(style, -seg / 2, seg / 2, -rad_th / 2, rad_th / 2, -thick / 2, thick / 2, **kw)


def circle_pts(r, count, phase=0.0):
    return [(r * math.cos(phase + 2 * PI * k / count), r * math.sin(phase + 2 * PI * k / count)) for k in range(count)]


def catmull(points, samples_per_seg=24):
    pts = [points[0]] + points + [points[-1]]
    out = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        for s in range(samples_per_seg):
            t = s / samples_per_seg
            t2, t3 = t * t, t * t * t
            out.append(tuple(0.5 * ((2 * p1[j]) + (-p0[j] + p2[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2
                                    + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * t3) for j in range(2)))
    out.append(points[-1])
    return out


def belt(n, xc, path_zh, width=0.30, spacing=0.100, side=1):
    """Cartridge belt hanging in the y-z plane (broad face toward the side, like the real prop).
    Local link frame: z = along the path, h = across the ribbon (width), x = thickness."""
    pts = catmull(path_zh)
    acc = 0.0
    res = [pts[0]]
    last = pts[0]
    for p in pts[1:]:
        acc += math.hypot(p[0] - last[0], p[1] - last[1])
        if acc >= spacing:
            res.append(p); acc = 0.0
        last = p
    hw = width / 2
    for i in range(len(res) - 1):
        a, b = res[i], res[i + 1]
        mz, mh = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        ang = math.atan2(b[1] - a[1], b[0] - a[0])
        g = n.group('link', pivot=(xc, mh, mz), rot=(ang, 0, 0))
        g.box('belt', -0.04, 0.04, -hw, hw, -0.036, 0.036)                              # cartridge case + painted steel clips
        g.box('copper', -0.026, 0.026, hw, hw + 0.055, -0.026, 0.026, axis='y')         # bullet tip


def wheel(w, R, hw, sides, spokes=8, lugs=False):
    """Wheel in node w (pivot at wheel centre). Spin axis = x. `sides` = which faces are detailed (+1 left, -1 right)."""
    n_t = 16
    chord = 2 * R * math.sin(PI / n_t)
    for k in range(n_t):
        a = 2 * PI * k / n_t
        g = w.group('tread', pivot=(0, -(R - 0.04) * math.cos(a), (R - 0.04) * math.sin(a)), rot=(a, 0, 0))
        g.box('rubber', -hw, hw, -0.04, 0.04, -chord / 2 * 1.08, chord / 2 * 1.08, tread=True)
    for s in sides:
        x0, x1 = (hw - 0.03, hw) if s > 0 else (-hw, -hw + 0.03)
        w.box('rubber', x0, x1, -R + 0.03, R - 0.03, -R + 0.03, R - 0.03, mask=('ring', 0.52), disc_axis='x')
        xr0, xr1 = (hw - 0.07, hw - 0.04) if s > 0 else (-hw + 0.04, -hw + 0.07)
        w.box('steel2', xr0, xr1, -R * 0.56, R * 0.56, -R * 0.56, R * 0.56, mask='disc', disc_axis='x', bolts=10, bolt_r=0.82)
        for k in range(spokes):
            a = 2 * PI * k / spokes
            g = w.group('spoke', pivot=(s * (hw - 0.035), 0, 0), rot=(a, 0, 0))
            g.box('chrome', -0.016, 0.016, 0.04, R * 0.58, -0.032, 0.032, axis='y', panel=False)
            g.box('gold', -0.016, 0.016, R * 0.46, R * 0.54, -0.04, 0.04, axis='y', panel=False)
        for k in range(8):
            a = 2 * PI * k / 8
            r = 0.062
            g = w.group('hub', pivot=(s * (hw - 0.02), -r * math.cos(a), r * math.sin(a)), rot=(a, 0, 0))
            g.box('chrome', -0.022, 0.022, -0.03, 0.03, -0.034, 0.034, panel=False)
        if lugs:
            for k in range(8):
                a = 2 * PI * k / 8 + PI / 8
                r = 0.21
                g = w.group('lug', pivot=(s * hw, -r * math.cos(a), r * math.sin(a)), rot=(a, 0, 0))
                g.box('white', -0.02 if s < 0 else 0, 0.02 if s > 0 else 0, -0.02, 0.02, -0.02, 0.02, panel=False)
    w.box('chrome', -hw, hw, -0.035, 0.035, -0.035, 0.035, axis='x')


def rotor(n, tubes_cfg, z0, z1, rings, plate_r, core_r, plate_z, bolts, hub_style='dark'):
    """Rotating barrel cluster in node n (pivot at cluster centre, local z0..z1)."""
    n.box('black', -core_r, core_r, -core_r, core_r, z0 + 0.12, z1 - 0.05, axis='z')
    for (count, rc, size, phase, extend_front) in tubes_cfg:
        for (cx, cy) in circle_pts(rc, count, phase):
            n.box('chrome', cx - size / 2, cx + size / 2, cy - size / 2, cy + size / 2,
                  z0 - extend_front, z1, axis='z')
    pz0, pz1 = plate_z
    n.box('dark', -plate_r, plate_r, -plate_r, plate_r, pz0, pz1, mask='disc', disc_axis='z', bolts=bolts, bolt_r=0.82)
    for (zc, r_mid, rad_th, th, st) in rings:
        ring_z(n, st, 0, 0, zc, r_mid, rad_th, th, seg_n=16, name='band')


# ---------------- the machine ----------------
def build():
    base = Node('base')
    b = base
    EZ0, EZ1 = -0.95, 0.25      # engine block z extents
    EC = (EZ0 + EZ1) / 2

    # ---------- chassis / frame ----------
    b.sym('dark', 0.27, 0.33, 0.40, 0.47, -1.45, 2.10, axis='z')
    for z in (-1.3, -0.7, -0.1, 0.5, 1.1, 1.6):
        b.box('dark', -0.33, 0.33, 0.40, 0.46, z, z + 0.07, axis='x')
    b.box('dark', -0.40, 0.40, 0.28, 0.36, -1.40, 1.95, rivets=True)
    tx(b, 'steel2', -1.14, 1.14, WR, RW_Z, 0.06)
    b.sym('dark', 0.82, 0.90, 0.22, 1.00, RW_Z - 0.2, RW_Z + 0.22, rivets=True)

    # ---------- rear armoured box (silver riveted panels) ----------
    b.box('steel', -0.80, 0.80, 0.45, 1.12, 0.95, 2.30, inset=True)
    b.box('dark', -0.80, 0.80, 0.32, 0.45, 0.95, 2.30, rivets=True)
    b.box('dark', -0.78, 0.78, 1.12, 1.17, 1.00, 2.28)
    b.sym('steel2', 0.80, 0.84, 0.55, 1.02, 1.12, 2.15, inset=True)
    b.box('dark', -0.5, 0.5, 0.55, 1.0, 2.30, 2.335)
    for hh in (0.62, 0.72, 0.82, 0.92):
        b.box('chrome', -0.46, 0.46, hh, hh + 0.025, 2.335, 2.36, axis='x', panel=False)
    tx(b, 'chrome', -0.80, 0.80, 1.195, 1.03, 0.03)
    tx(b, 'chrome', -0.80, 0.80, 1.195, 2.27, 0.03)
    # rear face details (see the rear reference clip): MADE IN INDIA plate (decal drawn by the renderer), label boxes, muffler
    b.box('steel2', -0.50, 0.50, 0.52, 1.06, 2.30, 2.335, inset=True)
    b.sym('steel', 0.52, 0.80, 1.12, 1.46, 2.02, 2.30, inset=True)
    b.sym('dark', 0.52, 0.80, 1.46, 1.50, 2.02, 2.30, rivets=True)
    tx(b, 'chrome', -0.60, 0.60, 0.43, 2.40, 0.075, panel=False)
    for xx in (-0.52, -0.18, 0.18, 0.52):
        b.box('steel2', xx - 0.03, xx + 0.03, 0.34, 0.52, 2.325, 2.46, panel=False)
    b.sym('steel2', 0.56, 0.66, 0.34, 0.54, 2.30, 2.48, rivets=True)
    b.sym('dark', 0.84, 0.865, 0.70, 0.86, 1.45, 1.62)
    b.sym('chrome', 0.865, 0.89, 0.74, 0.82, 1.49, 1.58, panel=False)
    b.sym('gold', 0.84, 0.86, 0.60, 0.66, 1.2, 1.4)

    # ---------- ammo trays on the rear deck (rows of cartridges) ----------
    b.sym('dark', 0.40, 0.80, 1.17, 1.20, 1.04, 2.26)
    b.sym('steel2', 0.78, 0.81, 1.20, 1.32, 1.04, 2.26, rivets=False)
    b.sym('steel2', 0.40, 0.43, 1.20, 1.32, 1.04, 2.26, rivets=False)
    for k in range(9):
        zz = 1.09 + k * 0.125
        b.sym('ammo', 0.44, 0.77, 1.20, 1.31, zz, zz + 0.095)

    # rear red fenders (stepped arch) - scaled to the bigger wheel
    ft = 2 * WR + 0.04
    for s in (1, -1):
        xa, xb = (0.88, 1.32) if s > 0 else (-1.32, -0.88)
        xc = (xa + xb) / 2
        b.box('red', xa, xb, ft, ft + 0.06, RW_Z - 0.28, RW_Z + 0.28)
        g = b.group('fender_fr', pivot=(xc, ft + 0.03, RW_Z - 0.28), rot=(0.62, 0, 0))
        g.box('red', xa - xc, xb - xc, -0.03, 0.03, -0.26, 0.0)
        g = b.group('fender_rr', pivot=(xc, ft + 0.03, RW_Z + 0.28), rot=(-0.62, 0, 0))
        g.box('red', xa - xc, xb - xc, -0.03, 0.03, 0.0, 0.26)
        xf0, xf1 = (1.28, 1.32) if s > 0 else (-1.32, -1.28)
        b.box('red', xf0, xf1, ft - 0.20, ft + 0.06, RW_Z - 0.30, RW_Z + 0.30)
        b.box('red', xf0, xf1, ft - 0.30, ft - 0.18, RW_Z - 0.46, RW_Z - 0.30)
        b.box('red', xf0, xf1, ft - 0.30, ft - 0.18, RW_Z + 0.30, RW_Z + 0.46)
        b.box('chrome', xc - 0.08, xc + 0.08, ft + 0.06, ft + 0.12, RW_Z - 0.06, RW_Z + 0.10, panel=False)
        xi0, xi1 = (0.88, 0.92) if s > 0 else (-0.92, -0.88)
        b.box('chrome', xi0, xi1, 0.45, ft, RW_Z - 0.06, RW_Z + 0.06, panel=False)

    # ---------- red seat (raised, frame legs) ----------
    St = SEAT_TOP
    b.box('dark', -0.34, 0.34, St - 0.30, St - 0.25, 0.95, 1.72)
    b.box('leather', -0.33, 0.33, St - 0.25, St - 0.07, 0.95, 1.72)
    b.box('leather', -0.29, 0.29, St - 0.07, St, 0.99, 1.68, ribs=3)
    b.box('leather', -0.30, 0.30, St - 0.17, St - 0.03, 0.92, 0.97)
    for (xx, zz) in ((0.24, 1.02), (-0.24, 1.02), (0.24, 1.64), (-0.24, 1.64)):
        ty(b, 'chrome', xx, 1.17, St - 0.30, zz, 0.028)
    b.box('dark', -0.30, 0.30, 1.14, 1.17, 1.05, 1.62)
    sb = b.group('seatback', pivot=(0, St, 1.72), rot=(-0.22, 0, 0))
    sb.box('leather', -0.31, 0.31, 0.05, 0.62, 0.0, 0.14, ribs=4)
    sb.box('leather', -0.27, 0.27, 0.10, 0.57, -0.03, 0.0, ribs=3)
    sb.box('leather', -0.20, 0.20, 0.62, 0.70, 0.02, 0.12)
    sb.box('chrome', 0.31, 0.36, 0.0, 0.70, 0.0, 0.05, axis='y', panel=False)
    sb.box('chrome', -0.36, -0.31, 0.0, 0.70, 0.0, 0.05, axis='y', panel=False)
    sb.box('chrome', -0.36, 0.36, 0.64, 0.69, 0.0, 0.05, axis='x', panel=False)
    sb.box('chrome', -0.36, 0.36, 0.02, 0.07, 0.0, 0.05, axis='x', panel=False)
    sb.box('dark', -0.30, 0.30, 0.05, 0.60, 0.14, 0.18)
    for sx in (1, -1):
        ty(b, 'chrome', 0.30 * sx, 1.55, 2.30, 1.93, 0.028, panel=False)
        for rh in (1.62, 1.82, 2.02, 2.22):
            b.box('steel2', 0.30 * sx - 0.045, 0.30 * sx + 0.045, rh, rh + 0.035, 1.93 - 0.045, 1.93 + 0.045, panel=False)
    for vh in (1.70, 1.88, 2.06):
        for sgn in (1, -1):
            gv = b.group('chevron', pivot=(0.14 * sgn, vh, 1.93), rot=(0, 0, -0.5 * sgn))
            gv.box('chrome', -0.17, 0.17, -0.02, 0.02, -0.025, 0.025, panel=False)
    b.sym('chrome', 0.35, 0.39, St, St + 0.05, 1.05, 1.60, axis='z', panel=False)
    ty(b, 'chrome', 0.37, St - 0.22, St + 0.03, 1.12, 0.022)
    ty(b, 'chrome', -0.37, St - 0.22, St + 0.03, 1.12, 0.022)

    # steering column (static part) - handlebar is a separate animated group
    HB = St + 0.06
    ty(b, 'chrome', 0, 0.46, HB, 0.81, 0.04)
    b.box('dark', -0.08, 0.08, 1.20, 1.34, 0.74, 0.88)
    b.box('dark', -0.10, 0.10, 0.9, 1.0, 0.72, 0.9, rivets=True)

    # ---------- engine bay (V-twin, long exhaust headers) ----------
    b.box('dark', -0.28, 0.28, 0.48, 0.82, EZ0, EZ1, rivets=True)
    b.box('steel2', -0.24, 0.24, 0.44, 0.52, EZ0, EZ1)
    b.box('chrome', -0.18, 0.18, 0.82, 0.98, EZ0 + 0.03, EZ1 - 0.03, inset=True)
    for s in (1, -1):
        bank = b.group('bank', pivot=(0.17 * s, 0.84, EC), rot=(0, 0, 0.5 * s))
        for zc in (-0.40, -0.14, 0.14, 0.40):
            bank.box('chrome', -0.10, 0.10, 0.02, 0.32, zc - 0.09, zc + 0.09, panel=False)
            for fh in (0.07, 0.14, 0.21, 0.28):
                bank.box('steel2', -0.12, 0.12, fh, fh + 0.025, zc - 0.10, zc + 0.10, panel=False)
        bank.box('steel', -0.11, 0.11, 0.32, 0.38, -0.50, 0.50)
        bank.box('red', -0.08, 0.08, 0.38, 0.42, -0.46, 0.46)
    for s in (1, -1):
        for zi in (-0.80, -0.56, -0.32, -0.08):
            pipe(b, 'chrome', [(0.28 * s, 1.0, zi), (0.56 * s, 1.0, zi), (0.56 * s, 0.60, zi)], 0.04, panel=False)
        tz(b, 'chrome', 0.56 * s, 0.56, EZ0, 0.45, 0.06, panel=False)
        tz(b, 'steel', 0.56 * s, 0.56, 0.45, 0.88, 0.095, panel=False)
        tz(b, 'black', 0.56 * s, 0.56, 0.88, 0.92, 0.07, panel=False)
        for zc in (0.50, 0.65, 0.80):
            tz(b, 'steel2', 0.56 * s, 0.56, zc, zc + 0.035, 0.105, panel=False)
    for s in (1, -1):
        for zi in (-0.72, -0.40, -0.12):
            pipe(b, 'steel', [(0.30 * s, 0.70, zi), (0.46 * s, 0.70, zi), (0.46 * s, 0.50, zi), (0.46 * s, 0.50, zi + 0.2)], 0.034, panel=False)
    pipe(b, 'copper', [(0.0, 0.98, -0.60), (0.0, 1.16, -0.60), (0.0, 1.16, -0.2)], 0.055, panel=False)
    pipe(b, 'copper', [(0.0, 0.50, EZ0 - 0.02), (0.0, 0.36, EZ0 - 0.02), (0.0, 0.36, 0.5)], 0.05, panel=False)
    # blue indicator + gauges on the engine sides
    for s in (1, -1):
        x0, x1 = (0.28, 0.31) if s > 0 else (-0.31, -0.28)
        b.box('chrome', x0, x1, 0.60, 0.80, -0.62, -0.42, mask='disc', disc_axis='x', panel=False)
        xb0, xb1 = (0.31, 0.325) if s > 0 else (-0.325, -0.31)
        b.box('blue', xb0, xb1, 0.63, 0.77, -0.59, -0.45, mask='disc', disc_axis='x')
        b.box('white', x0, x1, 0.50, 0.58, -0.30, -0.18, mask='disc', disc_axis='x')
        b.box('purple', x0, x1, 0.50, 0.58, -0.10, 0.04)

    # ---------- gun support (receiver, feeder) ----------
    ghc = GUN_H
    b.box('steel', -RH, RH, ghc - RH, ghc + RH, GUN_Z1, -0.05, inset=True)
    b.box('dark', -RH - 0.02, RH + 0.02, ghc - RH - 0.08, ghc - RH, GUN_Z1 - 1.0, 0.55, rivets=True)
    b.sym('steel2', RH, RH + 0.035, ghc - 0.28, ghc + 0.28, GUN_Z1 + 0.05, -0.2, inset=True, vents=True)
    b.box('chrome', -0.34, 0.34, ghc + RH, ghc + RH + 0.04, GUN_Z1 + 0.05, -0.12, panel=False)
    for zc in (-0.88, -0.68, -0.48, -0.30):
        b.box('dark', -0.32, 0.32, ghc + RH + 0.04, ghc + RH + 0.06, zc, zc + 0.06)
    ring_z(b, 'black', 0, ghc, GUN_Z1 + 0.025, 0.46, 0.08, 0.05, seg_n=16, name='collar')
    # amber lamps and red slotted grille on top of the receiver front (lenses are emissive, see glow_static)
    for s in (1, -1):
        tz(b, 'gold', s * 0.38, ghc + RH + 0.11, GUN_Z1 - 0.01, GUN_Z1 + 0.26, 0.115, panel=False)
        tz(b, 'steel2', s * 0.38, ghc + RH + 0.11, GUN_Z1 + 0.24, GUN_Z1 + 0.30, 0.13, panel=False)
        tz(b, 'black', s * 0.38, ghc + RH + 0.11, GUN_Z1 - 0.045, GUN_Z1 - 0.01, 0.13, panel=False)
    b.box('grille', -0.20, 0.20, ghc + RH, ghc + RH + 0.15, GUN_Z1 - 0.02, GUN_Z1 + 0.22)
    b.box('steel2', -0.22, 0.22, ghc + RH, ghc + RH + 0.03, GUN_Z1 + 0.22, GUN_Z1 + 0.30, rivets=True)
    # feeder box behind the receiver
    b.box('steel', -0.38, 0.38, 1.52, 2.18, -0.05, 0.60, inset=True)
    b.box('dark', -0.38, 0.38, 2.18, 2.22, -0.03, 0.58, rivets=True)
    b.sym('dark', 0.38, 0.405, 1.56, 1.74, -0.02, 0.5)
    b.sym('gold', 0.405, 0.425, 1.60, 1.70, 0.0, 0.46, link=True)
    b.box('steel2', -0.32, 0.32, 1.52, 2.18, 0.60, 0.66, inset=True, rivets=True)
    for s in (1, -1):
        tz(b, 'chrome', 0.31 * s, 1.26, -0.66, 0.22, 0.14, panel=False)
        tz(b, 'steel2', 0.31 * s, 1.26, -0.70, -0.62, 0.155, panel=False)
        tz(b, 'steel2', 0.31 * s, 1.26, 0.20, 0.26, 0.15, panel=False)
        tz(b, 'steel2', 0.31 * s, 1.26, -0.22, -0.16, 0.152, panel=False)
        b.box('gold', 0.31 * s - 0.05, 0.31 * s + 0.05, 1.10, 1.16, -0.4, -0.1, panel=False)
    # struts down to the engine
    b.sym('steel2', 0.18, 0.36, 0.98, 1.26, -0.85, -0.25)
    b.box('dark', -0.20, 0.20, 0.98, 1.26, -0.85, -0.70)
    b.box('dark', -0.30, 0.30, 1.22, 1.30, GUN_Z1 - 1.0, GUN_Z1 + 0.02, rivets=True)   # beam under the rotor
    # side gun mounts
    b.sym('steel', RH, 0.88, 1.22, 1.54, -1.0, -0.55, inset=True)
    b.sym('dark', RH, 0.88, 1.16, 1.22, -1.0, -0.55)
    # top belts (three strands over the receiver)
    for xs in (-0.12, 0.0, 0.12):
        belt(b, xs, [(-0.80, ghc + RH + 0.10), (-0.4, ghc + RH + 0.14), (-0.05, ghc + RH + 0.17), (0.30, ghc + RH + 0.17), (0.62, ghc + RH + 0.08)], width=0.13, spacing=0.09, side=1)

    # ---------- hanging cartridge belts (both sides, down to near the ground) ----------
    path = [(-0.12, 1.60), (-0.34, 1.22), (-0.46, 0.78), (-0.44, 0.40), (-0.25, 0.17), (0.25, 0.12), (0.78, 0.20),
            (1.02, 0.50), (1.06, 0.88), (1.00, 1.12)]
    belt(b, 0.54, path, width=0.30, side=1)
    belt(b, -0.54, path, width=0.30, side=-1)
    path2 = [(z + 0.12, h - 0.03) for (z, h) in path]
    belt(b, 0.72, path2, width=0.24, side=1)
    belt(b, -0.72, path2, width=0.24, side=-1)

    # ---------- animated: front fork + wheel ----------
    fork = Node('front_fork', pivot=(0, WR, FW_Z))
    wf = fork.group('wheel_f')
    wheel(wf, WR, 0.17, sides=(1, -1), spokes=8)
    fh = WR + 0.04
    for s in (1, -1):
        ty(fork, 'chrome', 0.225 * s, 0.0, 0.82, 0.0, 0.032)
        fork.box('steel2', (0.17 if s > 0 else -0.30), (0.30 if s > 0 else -0.17), -0.045, 0.045, -0.045, 0.045, axis='x')
    fork.box('red', -0.27, 0.27, fh, fh + 0.06, -0.46, 0.46)
    g = fork.group('fender_f', pivot=(0, fh + 0.03, -0.46), rot=(0.78, 0, 0))
    g.box('red', -0.27, 0.27, -0.03, 0.03, -0.24, 0.0)
    g = fork.group('fender_b', pivot=(0, fh + 0.03, 0.46), rot=(-0.78, 0, 0))
    g.box('red', -0.27, 0.27, -0.03, 0.03, 0.0, 0.24)
    fork.sym('red', 0.26, 0.30, 0.24, fh + 0.06, -0.38, 0.38)
    fork.sym('red', 0.26, 0.30, 0.12, 0.26, -0.52, -0.36)
    for i in range(4):
        fork.box('red', -0.29, 0.29, 0.04 + 0.08 * i, 0.08 + 0.08 * i, -0.68 + 0.012 * i, -0.44)
    fork.sym('red', 0.28, 0.33, 0.50, 0.84, -0.32, -0.02)
    fork.box('dark', -0.33, 0.33, 0.82, 0.90, -0.36, 0.0, rivets=True)
    fork.box('chrome', -0.27, 0.27, 0.62, 0.66, -0.22, -0.16, axis='x', panel=False)
    for s in (1, -1):
        ty(fork, 'steel2', 0.15 * s, 0.50, 0.90, -0.28, 0.028)
        ty(fork, 'gold', 0.15 * s, 0.62, 0.76, -0.28, 0.045, panel=False)

    # ---------- rear wheels (outer faces detailed) ----------
    wrl = Node('wheel_rl', pivot=(RW_X, WR, RW_Z))
    wheel(wrl, WR, 0.17, sides=(1,), spokes=8, lugs=True)
    wrr = Node('wheel_rr', pivot=(-RW_X, WR, RW_Z))
    wheel(wrr, WR, 0.17, sides=(-1,), spokes=8, lugs=True)

    # ---------- rotor assemblies ----------
    rm = Node('rotor_main', pivot=(0, GUN_H, (GUN_Z0 + GUN_Z1) / 2))
    zc = (GUN_Z0 + GUN_Z1) / 2
    L0, L1 = GUN_Z0 - zc, GUN_Z1 - zc
    rotor(rm, [(20, 0.348, 0.082, 0.0, 0.03), (12, 0.23, 0.08, 0.2, 0.0), (6, 0.125, 0.075, 0.1, 0.0), (1, 0.0, 0.075, 0.0, 0.03)],
          L0, L1, [(L0 + 0.58, 0.428, 0.09, 0.12, 'black'), (L0 + 1.57, 0.428, 0.09, 0.12, 'black'), (L1 - 0.06, 0.43, 0.08, 0.11, 'steel')],
          0.46, 0.25, (L0 + 0.04, L0 + 0.08), 12)
    rl = Node('rotor_l', pivot=(0.66, 1.38, -1.45))
    rr = Node('rotor_r', pivot=(-0.66, 1.38, -1.45))
    for rn in (rl, rr):
        rotor(rn, [(8, 0.135, 0.075, 0.0, 0.0), (5, 0.06, 0.055, 0.3, 0.14)],
              -0.90, 0.90, [(-0.44, 0.175, 0.06, 0.09, 'black'), (0.22, 0.175, 0.06, 0.09, 'black'), (-0.05, 0.175, 0.06, 0.08, 'steel')],
              0.20, 0.10, (-0.85, -0.82), 8)
        ring_z(rn, 'sleeve', 0, 0, -0.74, 0.185, 0.04, 0.30, seg_n=12, name='sleeve')

    # ---------- handlebar (animated: steers with the machine) ----------
    hb = Node('handlebar', pivot=(0, HB, 0.81))
    hb.box('dark', -0.08, 0.08, -0.02, 0.10, -0.06, 0.06, rivets=True)
    hb.box('red', -0.48, 0.48, 0.08, 0.14, -0.035, 0.035, axis='x')
    hb.sym('black', 0.48, 0.62, 0.07, 0.15, -0.045, 0.045, axis='x')
    hb.sym('red', 0.30, 0.46, 0.10, 0.14, -0.16, -0.05)
    hb.sym('chrome', 0.30, 0.46, 0.14, 0.17, -0.16, -0.12, panel=False)
    hb.sym('red', 0.12, 0.16, 0.0, 0.22, -0.05, 0.05)
    hb.sym('gold', 0.48, 0.52, 0.14, 0.20, 0.0, 0.03)

    # ---------- shield (thick frame opaque + glass translucent). Local origin = shield centre. ----------
    sf = Node('shield_frame', pivot=(0, SHIELD_H, SHIELD_Z), rot=(-0.30, 0, 0))
    W2, H2 = 0.60, 0.46
    D = 0.05
    sf.box('steel2', -W2 - 0.07, W2 + 0.07, H2, H2 + 0.07, -D, D)
    sf.box('steel2', -W2 - 0.07, W2 + 0.07, -H2 - 0.07, -H2, -D, D)
    sf.sym('steel2', W2, W2 + 0.07, -H2, H2, -D, D)
    # inner raised lip (gives the glass a recessed, thick look)
    sf.box('chrome', -W2, W2, H2 - 0.03, H2, -D - 0.025, D + 0.025, panel=False)
    sf.box('chrome', -W2, W2, -H2, -H2 + 0.03, -D - 0.025, D + 0.025, panel=False)
    sf.sym('chrome', W2 - 0.03, W2, -H2, H2, -D - 0.025, D + 0.025, panel=False)
    for sx in (1, -1):
        for sh in (1, -1):
            sf.box('chrome', sx * (W2 + 0.035) - 0.04, sx * (W2 + 0.035) + 0.04, sh * (H2 + 0.035) - 0.04, sh * (H2 + 0.035) + 0.04, -D - 0.03, D + 0.04, panel=False)
    sf.box('red', -0.12, 0.12, H2 + 0.07, H2 + 0.12, -0.04, 0.04)
    # mid cross bar and hinge cylinders / support arms
    sf.box('steel2', -W2, W2, -0.02, 0.02, -0.03, 0.03, panel=False)
    for sx in (1, -1):
        tx(sf, 'chrome', sx * (W2 - 0.1) - 0.07, sx * (W2 - 0.1) + 0.07, -H2 - 0.10, 0.0, 0.05, panel=False)
        ty(sf, 'chrome', sx * 0.42, -0.80, -H2 - 0.05, 0.0, 0.035, panel=False)
    sf.box('dark', -0.34, 0.34, -0.86, -0.74, -0.07, 0.09, rivets=True)

    glass = Node('glass', pivot=(0, SHIELD_H, SHIELD_Z), rot=(-0.30, 0, 0), translucent=True)
    glass.box('glass', -W2, W2, -H2, H2, -0.018, 0.018)

    # ---------- muzzle flashes (full-bright, translucent; toggled while firing) ----------
    flashes = []
    for name, px, ph, pz, sz in (('flash_main', 0.0, GUN_H, GUN_Z0 - 0.30, 0.70), ('flash_l', 0.66, 1.38, -2.40, 0.38), ('flash_r', -0.66, 1.38, -2.40, 0.38)):
        fn = Node(name, pivot=(px, ph, pz), flash=True, translucent=True)
        fn.box('flash', -sz, sz, -0.02, 0.02, -sz * 1.0, sz * 0.2)
        fn.box('flash', -0.02, 0.02, -sz, sz, -sz * 1.0, sz * 0.2)
        fn.box('flash', -sz * 0.35, sz * 0.35, -sz * 0.35, sz * 0.35, -sz * 0.35, sz * 0.15)
        flashes.append(fn)

    # ---------- emissive parts (full-bright): lamp lenses, tail lights, shield edge glow, spinning-barrel glow ----------
    gs = Node('glow_static', flash=True, translucent=True)
    for s in (1, -1):
        gs.box('lamp', s * 0.38 - 0.10, s * 0.38 + 0.10, ghc + RH + 0.01, ghc + RH + 0.21, GUN_Z1 - 0.062, GUN_Z1 - 0.045, mask='disc', disc_axis='z')
        gs.box('louver', 0.56 if s > 0 else -0.78, 0.78 if s > 0 else -0.56, 0.58, 0.72, 2.36, 2.372)
    gsh = Node('glow_shield', pivot=(0, SHIELD_H, SHIELD_Z), rot=(-0.30, 0, 0), flash=True, translucent=True)
    for sx in (1, -1):
        gsh.box('redglow', sx * (W2 - 0.03) - 0.018, sx * (W2 - 0.03) + 0.018, -H2 + 0.04, H2 - 0.04, D + 0.03, D + 0.045, panel=False)
    blurs = []
    for name, px, ph, pz, rr_ in (('blur_main', 0.0, GUN_H, GUN_Z0 - 0.015, 0.46), ('blur_l', 0.66, 1.38, -2.36, 0.21), ('blur_r', -0.66, 1.38, -2.36, 0.21)):
        bn = Node(name, pivot=(px, ph, pz), flash=True, translucent=True)
        bn.box('blurdisc', -rr_, rr_, -rr_, rr_, -0.012, 0.012, mask='disc', disc_axis='z')
        blurs.append(bn)

    roots = [base, fork, wrl, wrr, rm, rl, rr, hb, sf, glass] + flashes + [gs, gsh] + blurs
    return roots
