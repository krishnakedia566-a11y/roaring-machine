import math
from mm_core import Node

PI = math.pi

# ---- key layout constants (blocks) ----
WR = 0.40            # wheel radius
RW_X = 1.07          # rear wheel x offset
RW_Z = 1.76          # rear axle z
FW_Z = -1.00         # front wheel z
GUN_H = 1.73         # main gun axis height
GUN_Z0, GUN_Z1 = -2.50, -0.95  # main rotor extents
SHIELD_Z = 0.64
SHIELD_H = 2.25


# ---------------- helpers ----------------
def tz(n, style, x, h, z0, z1, r, **kw):
    n.box(style, x - r, x + r, h - r, h + r, z0, z1, axis='z', **kw)


def tx(n, style, x0, x1, h, z, r, **kw):
    n.box(style, x0, x1, h - r, h + r, z - r, z + r, axis='x', **kw)


def ty(n, style, x, h0, h1, z, r, **kw):
    n.box(style, x - r, x + r, h0, h1, z - r, z + r, axis='y', **kw)


def pipe(n, style, pts, r, **kw):
    """Polyline of axis-aligned segments through pts [(x,h,z),...]."""
    for (a, b) in zip(pts[:-1], pts[1:]):
        dx, dh, dz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
        if abs(dx) > 1e-6:
            tx(n, style, min(a[0], b[0]) - r, max(a[0], b[0]) + r, a[1], a[2], r, **kw)
        elif abs(dh) > 1e-6:
            ty(n, style, a[0], min(a[1], b[1]) - r, max(a[1], b[1]) + r, a[2], r, **kw)
        else:
            tz(n, style, a[0], a[1], min(a[2], b[2]) - r, max(a[2], b[2]) + r, r, **kw)


def ring_z(n, style, x, h, z, r, rad_th, thick, seg_n=12, name='ringseg', **kw):
    """Polygon ring around a z-axis (e.g. barrel band). r = mid radius."""
    seg = 2 * PI * r / seg_n * 1.08
    for k in range(seg_n):
        a = 2 * PI * k / seg_n
        g = n.group(name, pivot=(x + r * math.cos(a), h - r * math.sin(a), z), rot=(0, 0, a - PI / 2))
        g.box(style, -seg / 2, seg / 2, -rad_th / 2, rad_th / 2, -thick / 2, thick / 2, **kw)


def circle_pts(r, count, phase=0.0):
    return [(r * math.cos(phase + 2 * PI * k / count), r * math.sin(phase + 2 * PI * k / count)) for k in range(count)]


def catmull(points, samples_per_seg=24):
    pts = [points[0]] + points + [points[-1]]
    out = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        for s in range(samples_per_seg):
            t = s / samples_per_seg
            t2, t3 = t * t, t * t * t
            out.append(tuple(0.5 * ((2 * p1[j]) + (-p0[j] + p2[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2
                                    + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * t3) for j in range(2)))
    out.append(points[-1])
    return out


def belt(n, xc, path_zh, link_len=0.072, width=0.17, spacing=0.078):
    """Curved ammo-style belt of individual 3D links (decorative). path_zh: list of (z, h)."""
    pts = catmull(path_zh)
    # resample by arc length
    acc = 0.0
    res = [pts[0]]
    last = pts[0]
    for p in pts[1:]:
        d = math.hypot(p[0] - last[0], p[1] - last[1])
        acc += d
        if acc >= spacing:
            res.append(p); acc = 0.0
        last = p
    for i in range(len(res) - 1):
        a, b = res[i], res[i + 1]
        mz, mh = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        ang = math.atan2(b[1] - a[1], b[0] - a[0])
        g = n.group('link', pivot=(xc, mh, mz), rot=(ang, 0, 0))
        hw = width / 2
        g.box('chrome', -hw, hw, -0.014, 0.014, -link_len / 2, link_len / 2, panel=False)
        g.box('gold', -hw + 0.012, hw - 0.012, 0.014, 0.036, -0.014, 0.014, link=True)
        g.box('brass', -hw - 0.012, -hw + 0.02, -0.018, 0.04, -link_len / 2 + 0.006, link_len / 2 - 0.006)
        g.box('brass', hw - 0.02, hw + 0.012, -0.018, 0.04, -link_len / 2 + 0.006, link_len / 2 - 0.006)
        g.box('gold', -0.012, 0.012, 0.036, 0.062, -0.012, 0.012, axis='y')


def wheel(w, R, hw, rear):
    """Wheel in node w (pivot at wheel centre). Spin axis = x."""
    n_t = 20
    chord = 2 * R * math.sin(PI / n_t)
    for k in range(n_t):
        a = 2 * PI * k / n_t
        g = w.group('tread', pivot=(0, -(R - 0.035) * math.cos(a), (R - 0.035) * math.sin(a)), rot=(a, 0, 0))
        g.box('rubber', -hw, hw, -0.035, 0.035, -chord / 2 * 1.06, chord / 2 * 1.06, tread=True)
    # sidewalls (ring discs) and recessed rim discs
    for s in (-1, 1):
        x0, x1 = (hw - 0.025, hw) if s > 0 else (-hw, -hw + 0.025)
        w.box('rubber', x0, x1, -R + 0.02, R - 0.02, -R + 0.02, R - 0.02, mask=('ring', 0.52), disc_axis='x')
        xr0, xr1 = (hw - 0.06, hw - 0.035) if s > 0 else (-hw + 0.035, -hw + 0.06)
        w.box('steel2', xr0, xr1, -R * 0.56, R * 0.56, -R * 0.56, R * 0.56, mask='disc', disc_axis='x',
              bolts=10 if rear else 8, bolt_r=0.82)
        # spokes
        n_s = 10 if rear else 8
        for k in range(n_s):
            a = 2 * PI * k / n_s
            g = w.group('spoke', pivot=(s * (hw - 0.03), 0, 0), rot=(a, 0, 0))
            g.box('chrome', -0.012, 0.012, 0.03, R * 0.56, -0.026, 0.026, axis='y', panel=False)
            g.box('gold', -0.012, 0.012, R * 0.45, R * 0.52, -0.034, 0.034, axis='y', panel=False)
        # hub cap
        ring = 8
        for k in range(ring):
            a = 2 * PI * k / ring
            r = 0.055
            g = w.group('hub', pivot=(s * (hw - 0.02), -r * math.cos(a), r * math.sin(a)), rot=(a, 0, 0))
            g.box('chrome', -0.018, 0.018, -0.026, 0.026, -0.03, 0.03, panel=False)
    w.box('chrome', -hw - 0.0, hw, -0.03, 0.03, -0.03, 0.03, axis='x')
    # lug bolts on outer sides
    if rear:
        for s in (-1, 1):
            for k in range(8):
                a = 2 * PI * k / 8 + PI / 8
                r = 0.19
                g = w.group('lug', pivot=(s * (hw - 0.0), -r * math.cos(a), r * math.sin(a)), rot=(a, 0, 0))
                g.box('white', -0.02 if s < 0 else 0, 0.02 if s > 0 else 0, -0.016, 0.016, -0.016, 0.016, panel=False)


def rotor(n, tubes_cfg, z0, z1, rings, plate_r, core_r, plate_z, bolts, hub_style='dark'):
    """Rotating barrel cluster in node n (pivot at cluster centre, local z0..z1)."""
    n.box('black', -core_r, core_r, -core_r, core_r, z0 + 0.12, z1 - 0.05, axis='z')
    for (count, rc, size, phase, extend_front) in tubes_cfg:
        for (cx, cy) in circle_pts(rc, count, phase):
            n.box('chrome', cx - size / 2, cx + size / 2, cy - size / 2, cy + size / 2,
                  z0 - extend_front, z1, axis='z')
    pz0, pz1 = plate_z
    n.box('dark', -plate_r, plate_r, -plate_r, plate_r, pz0, pz1, mask='disc', disc_axis='z', bolts=bolts, bolt_r=0.82)
    for (zc, r_mid, rad_th, th, st) in rings:
        ring_z(n, st, 0, 0, zc, r_mid, rad_th, th, seg_n=16, name='band')


# ---------------- the machine ----------------
def build():
    base = Node('base')
    b = base

    # ---------- chassis / frame ----------
    b.sym('dark', 0.27, 0.33, 0.40, 0.47, -1.25, 2.10, axis='z')
    for z in (-1.1, -0.5, 0.1, 0.7, 1.3):
        b.box('dark', -0.33, 0.33, 0.40, 0.46, z, z + 0.07, axis='x')
    b.box('dark', -0.40, 0.40, 0.28, 0.36, -1.25, 1.95, rivets=True)
    tx(b, 'steel2', -1.12, 1.12, 0.40, RW_Z, 0.055)
    b.sym('dark', 0.82, 0.90, 0.22, 0.95, 1.55, 1.98, rivets=True)
    b.box('dark', -0.30, 0.30, 0.30, 0.46, 0.35, 0.95)         # centre tunnel

    # ---------- rear armoured box (silver riveted panels) ----------
    b.box('steel', -0.80, 0.80, 0.45, 1.12, 0.95, 2.30, inset=True)
    b.box('dark', -0.80, 0.80, 0.32, 0.45, 0.95, 2.30, rivets=True)
    b.box('dark', -0.78, 0.78, 1.12, 1.17, 1.00, 2.28)
    b.sym('steel2', 0.80, 0.84, 0.55, 1.02, 1.12, 2.15, inset=True)
    b.box('dark', -0.5, 0.5, 0.55, 1.0, 2.30, 2.335)
    for hh in (0.62, 0.72, 0.82, 0.92):
        b.box('chrome', -0.46, 0.46, hh, hh + 0.025, 2.335, 2.36, axis='x', panel=False)
    tx(b, 'chrome', -0.80, 0.80, 1.195, 1.03, 0.028)
    tx(b, 'chrome', -0.80, 0.80, 1.195, 2.27, 0.028)
    b.sym('chrome', 0.76, 0.81, 1.17, 1.22, 1.00, 2.28, axis='z')
    for (xx, zz) in ((0.72, 1.18), (-0.72, 1.18), (0.72, 2.05), (-0.72, 2.05)):
        b.box('black', xx - 0.05, xx + 0.05, 1.17, 1.20, zz - 0.05, zz + 0.05)
    # latch / hinge details on the side panel
    b.sym('dark', 0.84, 0.865, 0.70, 0.86, 1.45, 1.62)
    b.sym('chrome', 0.865, 0.89, 0.74, 0.82, 1.49, 1.58, panel=False)
    b.sym('gold', 0.84, 0.86, 0.60, 0.66, 1.2, 1.4)

    # rear red fenders (stepped arch)
    for s in (1, -1):
        xa, xb = (0.88, 1.28) if s > 0 else (-1.28, -0.88)
        b.box('red', xa, xb, 0.86, 0.92, 1.52, 2.00)
        g = b.group('fender_fr', pivot=((xa + xb) / 2, 0.89, 1.52), rot=(0.62, 0, 0))
        g.box('red', xa - (xa + xb) / 2, xb - (xa + xb) / 2, -0.03, 0.03, -0.20, 0.0)
        g = b.group('fender_rr', pivot=((xa + xb) / 2, 0.89, 2.00), rot=(-0.62, 0, 0))
        g.box('red', xa - (xa + xb) / 2, xb - (xa + xb) / 2, -0.03, 0.03, 0.0, 0.20)
        # outer flange of the fender
        xf0, xf1 = (1.25, 1.29) if s > 0 else (-1.29, -1.25)
        b.box('red', xf0, xf1, 0.70, 0.92, 1.50, 2.02)
        b.box('red', xf0, xf1, 0.62, 0.74, 1.36, 1.50)
        b.box('red', xf0, xf1, 0.62, 0.74, 2.02, 2.16)
        # bracket and bolts
        b.box('chrome', (xa + xb) / 2 - 0.08, (xa + xb) / 2 + 0.08, 0.92, 0.98, 1.65, 1.8, panel=False)
        # inner bracket arm to the frame
        xi0, xi1 = (0.88, 0.92) if s > 0 else (-0.92, -0.88)
        b.box('chrome', xi0, xi1, 0.40, 0.90, 1.70, 1.82, panel=False)

    # ---------- red seat ----------
    b.box('leather', -0.33, 0.33, 1.22, 1.40, 0.95, 1.72)
    b.box('leather', -0.29, 0.29, 1.40, 1.47, 0.99, 1.68, ribs=3)
    b.box('leather', -0.30, 0.30, 1.30, 1.44, 0.92, 0.97)
    for (xx, zz) in ((0.24, 1.02), (-0.24, 1.02), (0.24, 1.64), (-0.24, 1.64)):
        ty(b, 'chrome', xx, 1.17, 1.23, zz, 0.025)
    b.box('dark', -0.34, 0.34, 1.17, 1.22, 0.95, 1.72)
    sb = b.group('seatback', pivot=(0, 1.47, 1.72), rot=(-0.22, 0, 0))
    sb.box('leather', -0.31, 0.31, 0.05, 0.62, 0.0, 0.14, ribs=4)
    sb.box('leather', -0.27, 0.27, 0.10, 0.57, -0.03, 0.0, ribs=3)
    sb.box('leather', -0.20, 0.20, 0.62, 0.70, 0.02, 0.12)
    for s in (1, -1):
        sb.box('chrome', 0.31 * s if s > 0 else -0.36, 0.36 if s > 0 else -0.31, 0.0, 0.70, 0.0, 0.05, axis='y', panel=False)
    sb.box('chrome', -0.36, 0.36, 0.64, 0.69, 0.0, 0.05, axis='x', panel=False)
    sb.box('chrome', -0.36, 0.36, 0.02, 0.07, 0.0, 0.05, axis='x', panel=False)
    sb.box('dark', -0.30, 0.30, 0.05, 0.60, 0.14, 0.18)
    # armrest side rails
    b.sym('chrome', 0.35, 0.39, 1.47, 1.52, 1.05, 1.60, axis='z', panel=False)
    ty(b, 'chrome', 0.37, 1.22, 1.50, 1.12, 0.02)
    ty(b, 'chrome', -0.37, 1.22, 1.50, 1.12, 0.02)

    # steering column (static part) - handlebar itself is a separate animated group
    ty(b, 'chrome', 0, 0.46, 1.52, 0.81, 0.035)
    b.box('dark', -0.07, 0.07, 1.20, 1.32, 0.74, 0.88)
    b.box('dark', -0.09, 0.09, 0.9, 1.0, 0.72, 0.9, rivets=True)

    # ---------- engine bay ----------
    b.box('dark', -0.28, 0.28, 0.48, 0.80, -1.32, -0.52, rivets=True)
    b.box('steel2', -0.24, 0.24, 0.44, 0.52, -1.32, -0.52)
    b.box('chrome', -0.18, 0.18, 0.80, 0.96, -1.30, -0.55, inset=True)
    for s in (1, -1):
        bank = b.group('bank', pivot=(0.17 * s, 0.82, -0.92), rot=(0, 0, 0.5 * s))
        for zc in (-0.30, -0.10, 0.10, 0.30):
            bank.box('chrome', -0.09, 0.09, 0.02, 0.30, zc - 0.075, zc + 0.075, panel=False)
            for fh in (0.07, 0.13, 0.19, 0.25):
                bank.box('steel2', -0.11, 0.11, fh, fh + 0.02, zc - 0.085, zc + 0.085, panel=False)
        bank.box('steel', -0.10, 0.10, 0.30, 0.36, -0.40, 0.40)
        bank.box('red', -0.07, 0.07, 0.36, 0.40, -0.36, 0.36)
    # exhaust headers + collectors
    for s in (1, -1):
        for zi in (-1.15, -0.95, -0.77, -0.60):
            pipe(b, 'chrome', [(0.28 * s, 0.98, zi), (0.54 * s, 0.98, zi), (0.54 * s, 0.56, zi)], 0.032, panel=False)
        tz(b, 'chrome', 0.54 * s, 0.52, -1.2, 0.50, 0.05, panel=False)
        tz(b, 'steel', 0.54 * s, 0.52, 0.50, 0.92, 0.085, panel=False)
        tz(b, 'black', 0.54 * s, 0.52, 0.92, 0.96, 0.06, panel=False)
        for zc in (0.55, 0.70, 0.85):
            tz(b, 'steel2', 0.54 * s, 0.52, zc, zc + 0.03, 0.095, panel=False)
    # intake pipes (copper) + bottom exhaust
    pipe(b, 'copper', [(0.0, 0.96, -1.0), (0.0, 1.14, -1.0), (0.0, 1.14, -0.7)], 0.05, panel=False)
    pipe(b, 'copper', [(0.0, 0.62, -1.34), (0.0, 0.42, -1.34), (0.0, 0.42, -0.2)], 0.045, panel=False)
    # blue indicator + gauges
    b.box('chrome', -0.115, 0.115, 0.585, 0.815, -1.36, -1.32, mask='disc', disc_axis='z', panel=False)
    b.box('blue', -0.085, 0.085, 0.615, 0.785, -1.375, -1.36, mask='disc', disc_axis='z')
    b.box('white', 0.10, 0.19, 0.48, 0.57, -1.35, -1.32, mask='disc', disc_axis='z')
    b.box('purple', -0.30, -0.22, 0.46, 0.54, -1.35, -1.32)
    b.box('purple', 0.22, 0.30, 0.46, 0.54, -1.35, -1.32)

    # ---------- gun support (receiver, feeder) ----------
    b.box('steel', -0.40, 0.40, 1.33, 2.13, GUN_Z1, -0.05, inset=True)
    b.box('dark', -0.40, 0.40, 1.25, 1.33, -1.0, 0.55, rivets=True)
    b.sym('steel2', 0.40, 0.435, 1.45, 2.02, -0.9, -0.2, inset=True, vents=True)
    b.box('chrome', -0.32, 0.32, 2.13, 2.17, -0.9, -0.12, panel=False)
    for zc in (-0.8, -0.6, -0.4, -0.22):
        b.box('dark', -0.30, 0.30, 2.17, 2.19, zc, zc + 0.05)
    ring_z(b, 'black', 0, GUN_H, GUN_Z1 + 0.025, 0.395, 0.07, 0.05, seg_n=16, name='collar')
    b.box('steel', -0.36, 0.36, 1.48, 2.12, -0.05, 0.60, inset=True)
    b.box('dark', -0.36, 0.36, 2.12, 2.16, -0.03, 0.58, rivets=True)
    b.sym('dark', 0.36, 0.385, 1.52, 1.70, -0.02, 0.5)
    b.sym('gold', 0.385, 0.405, 1.56, 1.66, 0.0, 0.46, link=True)
    b.box('steel2', -0.30, 0.30, 1.48, 2.12, 0.60, 0.66, inset=True, rivets=True)
    # yellow lamps and a red grille on top of the receiver front
    for s in (1, -1):
        b.box('black', s * 0.45 - 0.09, s * 0.45 + 0.09, 2.08, 2.26, GUN_Z1 - 0.01, GUN_Z1 + 0.10, mask=None, panel=False)
        b.box('yellow', s * 0.45 - 0.07, s * 0.45 + 0.07, 2.10, 2.24, GUN_Z1 - 0.03, GUN_Z1 - 0.01, mask='disc', disc_axis='z')
    b.box('dark', -0.17, 0.17, 2.14, 2.26, GUN_Z1 - 0.01, GUN_Z1 + 0.05, vents=True)
    for k in range(5):
        b.box('red', -0.15, 0.15, 2.16 + 0.02 * k, 2.175 + 0.02 * k, GUN_Z1 - 0.03, GUN_Z1 - 0.01, panel=False)
    # struts down to engine
    b.sym('steel2', 0.18, 0.34, 0.96, 1.25, -1.22, -0.62)
    b.box('dark', -0.20, 0.20, 0.96, 1.25, -0.62, -0.50)
    # side gun mounts
    b.sym('steel', 0.40, 0.80, 1.20, 1.50, -0.95, -0.50, inset=True)
    b.sym('dark', 0.40, 0.80, 1.14, 1.20, -0.95, -0.50)
    # top belts (three strands over the receiver)
    for xs in (-0.11, 0.0, 0.11):
        belt(b, xs, [(-0.75, 2.20), (-0.4, 2.24), (-0.05, 2.28), (0.30, 2.28), (0.62, 2.22)], width=0.085, spacing=0.07)

    # ---------- belts (two big loops) ----------
    path = [(-0.06, 1.58), (-0.26, 1.28), (-0.34, 0.90), (-0.32, 0.50), (-0.12, 0.30), (0.30, 0.25), (0.78, 0.32),
            (1.04, 0.55), (1.08, 0.92), (1.02, 1.10)]
    belt(b, 0.46, path)
    belt(b, -0.46, path)

    # ---------- animated: front fork + wheel ----------
    fork = Node('front_fork', pivot=(0, WR, FW_Z))
    wf = fork.group('wheel_f')
    wheel(wf, WR, 0.17, rear=False)
    for s in (1, -1):
        ty(fork, 'chrome', 0.215 * s, 0.0, 0.78, 0.0, 0.03)
        fork.box('steel2', (0.17 if s > 0 else -0.28), (0.28 if s > 0 else -0.17), -0.04, 0.04, -0.04, 0.04, axis='x')
    fork.box('red', -0.25, 0.25, 0.44, 0.50, -0.42, 0.42)
    g = fork.group('fender_f', pivot=(0, 0.47, -0.42), rot=(0.78, 0, 0))
    g.box('red', -0.25, 0.25, -0.03, 0.03, -0.22, 0.0)
    g = fork.group('fender_b', pivot=(0, 0.47, 0.42), rot=(-0.78, 0, 0))
    g.box('red', -0.25, 0.25, -0.03, 0.03, 0.0, 0.22)
    fork.sym('red', 0.24, 0.28, 0.22, 0.50, -0.34, 0.34)
    fork.sym('red', 0.24, 0.28, 0.12, 0.24, -0.46, -0.30)
    for i in range(4):
        fork.box('red', -0.27, 0.27, 0.04 + 0.075 * i, 0.075 + 0.075 * i, -0.62 + 0.012 * i, -0.40)
    fork.sym('red', 0.26, 0.31, 0.50, 0.94, -0.30, -0.02)
    fork.box('dark', -0.31, 0.31, 0.90, 0.98, -0.34, 0.0, rivets=True)
    fork.box('chrome', -0.25, 0.25, 0.60, 0.64, -0.20, -0.14, axis='x', panel=False)
    # shock absorbers
    for s in (1, -1):
        ty(fork, 'steel2', 0.14 * s, 0.50, 0.92, -0.26, 0.025)
        ty(fork, 'gold', 0.14 * s, 0.62, 0.76, -0.26, 0.04, panel=False)

    # ---------- rear wheels ----------
    wrl = Node('wheel_rl', pivot=(RW_X, WR, RW_Z))
    wheel(wrl, WR, 0.17, rear=True)
    wrr = Node('wheel_rr', pivot=(-RW_X, WR, RW_Z))
    wheel(wrr, WR, 0.17, rear=True)

    # ---------- rotor assemblies ----------
    rm = Node('rotor_main', pivot=(0, GUN_H, (GUN_Z0 + GUN_Z1) / 2))
    zc = (GUN_Z0 + GUN_Z1) / 2
    L0, L1 = GUN_Z0 - zc, GUN_Z1 - zc
    rotor(rm, [(18, 0.305, 0.075, 0.0, 0.03), (11, 0.195, 0.075, 0.3, 0.0), (6, 0.10, 0.07, 0.1, 0.0)],
          L0, L1, [(L0 + 0.30, 0.375, 0.07, 0.09, 'black'), (L0 + 0.75, 0.375, 0.07, 0.09, 'black'), (L1 - 0.06, 0.38, 0.07, 0.10, 'steel')],
          0.40, 0.22, (L0 + 0.04, L0 + 0.075), 12)
    # cage (static look): extra inner dark body between tubes
    rl = Node('rotor_l', pivot=(0.62, 1.35, -1.35))
    rr = Node('rotor_r', pivot=(-0.62, 1.35, -1.35))
    for rn in (rl, rr):
        rotor(rn, [(8, 0.118, 0.06, 0.0, 0.0), (5, 0.05, 0.045, 0.3, 0.12)],
              -0.85, 0.85, [(-0.40, 0.15, 0.05, 0.08, 'black'), (0.20, 0.15, 0.05, 0.08, 'black'), (-0.05, 0.15, 0.05, 0.07, 'steel')],
              0.17, 0.08, (-0.80, -0.775), 8)

    # ---------- handlebar (animated: steers with the machine) ----------
    hb = Node('handlebar', pivot=(0, 1.52, 0.81))
    hb.box('dark', -0.07, 0.07, -0.02, 0.10, -0.06, 0.06, rivets=True)
    hb.box('red', -0.46, 0.46, 0.08, 0.14, -0.035, 0.035, axis='x')
    hb.sym('black', 0.46, 0.60, 0.07, 0.15, -0.045, 0.045, axis='x')
    hb.sym('red', 0.30, 0.44, 0.10, 0.14, -0.15, -0.05)
    hb.sym('chrome', 0.30, 0.44, 0.14, 0.17, -0.15, -0.12, panel=False)
    hb.sym('red', 0.12, 0.16, 0.0, 0.22, -0.05, 0.05)
    hb.sym('gold', 0.46, 0.50, 0.14, 0.20, 0.0, 0.03)

    # ---------- shield (frame opaque + glass translucent). Local origin = shield centre. ----------
    sf = Node('shield_frame', pivot=(0, SHIELD_H, SHIELD_Z), rot=(-0.30, 0, 0))
    W2, H2 = 0.56, 0.44
    sf.box('steel2', -W2 - 0.05, W2 + 0.05, H2, H2 + 0.05, -0.035, 0.035, panel=True)
    sf.box('steel2', -W2 - 0.05, W2 + 0.05, -H2 - 0.05, -H2, -0.035, 0.035)
    sf.sym('steel2', W2, W2 + 0.05, -H2, H2, -0.035, 0.035)
    for sx in (1, -1):
        for sh in (1, -1):
            sf.box('chrome', sx * (W2 + 0.025) - 0.018, sx * (W2 + 0.025) + 0.018, sh * (H2 + 0.025) - 0.018, sh * (H2 + 0.025) + 0.018, 0.035, 0.055, panel=False)
    sf.box('red', -0.10, 0.10, H2 + 0.05, H2 + 0.09, -0.03, 0.03)
    # support arms (down to the feeder housing)
    sf.sym('chrome', 0.40, 0.45, -0.75, -H2 - 0.05, -0.02, 0.03, panel=False, axis='y')
    sf.box('dark', -0.30, 0.30, -0.80, -0.70, -0.06, 0.08, rivets=True)

    glass = Node('glass', pivot=(0, SHIELD_H, SHIELD_Z), rot=(-0.30, 0, 0), translucent=True)
    glass.box('glass', -W2, W2, -H2, H2, -0.012, 0.012)

    roots = [base, fork, wrl, wrr, rm, rl, rr, hb, sf, glass]
    return roots
