import numpy as np, subprocess, os, wave
from scipy import signal

SR = 44100
OUT = '/home/claude/proj/src/main/resources/assets/roaringmachine/sounds'
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(11)


def T(d):
    return np.arange(int(SR * d)) / SR


def lp(x, fc, o=4):
    return signal.sosfilt(signal.butter(o, fc, 'low', fs=SR, output='sos'), x)


def hp(x, fc, o=4):
    return signal.sosfilt(signal.butter(o, fc, 'high', fs=SR, output='sos'), x)


def bp(x, f0, f1, o=3):
    return signal.sosfilt(signal.butter(o, [f0, f1], 'band', fs=SR, output='sos'), x)


def noise(n):
    return rng.standard_normal(n)


def add(dst, src, at):
    i = int(at * SR)
    n = min(len(src), len(dst) - i)
    if n > 0 and i >= 0:
        dst[i:i + n] += src[:n]


def burst_sine(f, d, decay, f_drop=0.0):
    t = T(d)
    ff = f * (1 + f_drop * np.exp(-t / 0.02))
    ph = 2 * np.pi * np.cumsum(ff) / SR
    return np.sin(ph) * np.exp(-t / decay)


def burst_noise(d, decay, lo, hi):
    n = int(SR * d)
    x = bp(noise(n), lo, hi)
    return x * np.exp(-np.arange(n) / SR / decay)


def plus(a, b):
    n = max(len(a), len(b))
    out = np.zeros(n)
    out[:len(a)] += a
    out[:len(b)] += b
    return out


def norm(x, peak=0.85):
    m = np.max(np.abs(x)) + 1e-9
    return x / m * peak


def fade(x, a=0.005, b=0.02):
    n = len(x)
    na, nb = int(a * SR), int(b * SR)
    x = x.copy()
    x[:na] *= np.linspace(0, 1, na)
    x[-nb:] *= np.linspace(1, 0, nb)
    return x


def loopify(x, xf=0.25):
    """Make a seamless loop by cross-fading the tail into the head."""
    n = int(xf * SR)
    body = x[:-n].copy()
    tail = x[-n:]
    w = np.linspace(0, 1, n)
    body[:n] = body[:n] * w + tail * (1 - w)
    return body


def save(name, x):
    x = np.clip(x, -1, 1)
    wav = f'/tmp/{name}.wav'
    with wave.open(wav, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', wav, '-c:a', 'libvorbis', '-q:a', '4', f'{OUT}/{name}.ogg'], check=True)


# ------------------------------------------------------------------ engine idle loop (2 s, seamless) ----
def engine_loop():
    d = 2.0
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    rate = 14
    jit = rng.uniform(-0.004, 0.004, rate * 2)
    for i in range(rate * 2):
        tt = (i / rate + jit[i]) % d
        p = burst_sine(52, 0.16, 0.055, 0.25) * (0.8 + 0.2 * (i % 2))
        nz = burst_noise(0.08, 0.02, 80, 500) * 0.35
        seg = np.zeros(int(0.16 * SR)); seg[:len(p)] += p; seg[:len(nz)] += nz
        # wrap-around add
        i0 = int(tt * SR)
        end = i0 + len(seg)
        if end <= n:
            x[i0:end] += seg
        else:
            k = n - i0
            x[i0:] += seg[:k]; x[:end - n] += seg[k:]
    for f, a in ((28, 0.35), (42, 0.28), (56, 0.22), (84, 0.12), (112, 0.06)):
        x += a * np.sin(2 * np.pi * f * t)
    x += 0.018 * np.sin(2 * np.pi * 310 * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 1.0 * t))   # metallic resonance
    x = lp(hp(x, 24), 650)
    return norm(x, 0.8)


# ------------------------------------------------------------------ rolling loop ----
def move_loop():
    d = 2.25
    n = int(SR * d)
    t = T(d)
    base = lp(noise(n), 210) * 1.0 + bp(noise(n), 400, 1400) * (0.35 + 0.15 * np.sin(2 * np.pi * 7 * t))
    base += 0.10 * np.sin(2 * np.pi * 36 * t)
    x = loopify(base, 0.25)
    return norm(lp(x, 2500), 0.7)


def steer_loop():
    d = 1.0
    t = T(d)
    x = 0.5 * np.sin(2 * np.pi * 520 * t) * (0.7 + 0.3 * np.sin(2 * np.pi * 6 * t))
    x += 0.25 * np.sin(2 * np.pi * 1040 * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t))
    x += 0.35 * bp(noise(len(t)), 900, 3000) * 0.5
    x += 0.2 * np.sin(2 * np.pi * 2 * t) * np.sin(2 * np.pi * 130 * t)
    return norm(lp(x, 4000), 0.5)


# ------------------------------------------------------------------ rotary guns ----
def rotor_loop():
    d = 1.0
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    x += 0.45 * np.sin(2 * np.pi * 38 * t) + 0.30 * np.sin(2 * np.pi * 76 * t) + 0.12 * np.sin(2 * np.pi * 114 * t)
    x += 0.10 * np.sin(2 * np.pi * 22 * t)                                   # restrained low resonance
    am = 0.65 + 0.35 * np.sin(2 * np.pi * 24 * t)
    x += 0.20 * np.sin(2 * np.pi * 760 * t) * am + 0.11 * np.sin(2 * np.pi * 1520 * t) * am   # whine
    for i in range(48):                                                          # rapid metallic movement
        c = hp(burst_noise(0.012, 0.0032, 1500, 7000), 1200) * (0.5 + 0.3 * ((i * 7) % 3) / 3)
        add(x, c * 0.85, i / 48.0 + 0.001)
    for i in range(8):                                                           # cinematic accents (controlled)
        p = plus(burst_sine(68, 0.14, 0.05, 0.3) * 0.55, burst_noise(0.04, 0.012, 200, 2500) * 0.25)
        add(x, p, i / 8.0)
    x = lp(hp(x, 20), 7000)
    return norm(x, 0.8)


def sweep_phase(f0, f1, d, n):
    t = np.arange(n) / SR
    r = f1 / f0
    return 2 * np.pi * f0 * d / np.log(r) * (r ** (t / d) - 1)


def rotor_startup():
    d = 1.35
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    # activation cue: thud + metal clack + servo chirp
    add(x, burst_sine(58, 0.25, 0.09, 0.4) * 0.9, 0.0)
    add(x, burst_noise(0.12, 0.03, 700, 3500) * 0.8, 0.0)
    ph = sweep_phase(220, 520, 0.28, int(0.28 * SR))
    add(x, np.sin(ph) * np.exp(-np.arange(len(ph)) / SR / 0.2) * 0.35, 0.02)
    # rising rotary whine with harmonics
    ph = sweep_phase(110, 1250, 1.3, n)
    amp = (t / 1.3) ** 1.6
    w = np.sin(ph) + 0.45 * np.sin(2 * ph) + 0.22 * np.sin(3 * ph)
    x += 0.30 * w * amp
    # building low rumble
    x += 0.55 * lp(noise(n), 130) * (0.15 + 0.85 * (t / 1.3) ** 1.2)
    x += 0.30 * np.sin(2 * np.pi * np.cumsum(30 + 45 * (t / 1.3)) / SR) * amp
    # accelerating mechanical ticks
    rate = 5 + 38 * (t / 1.3) ** 2
    cum = np.cumsum(rate) / SR
    last = 0
    for i in range(1, n):
        if int(cum[i]) > last:
            last = int(cum[i])
            add(x, burst_noise(0.01, 0.003, 1800, 7000) * (0.3 + 0.5 * (t[i] / 1.3)), t[i])
    # restrained final activation accent
    add(x, burst_sine(70, 0.2, 0.06, 0.3) * 0.7, 1.22)
    add(x, burst_sine(1800, 0.14, 0.04) * 0.25, 1.22)
    x = fade(lp(x, 9000), 0.003, 0.03)
    return norm(x, 0.85)


def rotor_spindown():
    d = 2.3
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    ph = sweep_phase(1150, 70, 2.1, n)
    amp = np.clip(1 - t / 2.1, 0, 1) ** 1.2
    w = np.sin(ph) + 0.4 * np.sin(2 * ph) + 0.2 * np.sin(3 * ph)
    x += 0.30 * w * amp
    x += 0.5 * lp(noise(n), 120) * np.clip(1 - t / 2.2, 0, 1) ** 0.8
    x += 0.28 * np.sin(2 * np.pi * np.cumsum(72 - 55 * np.clip(t / 2.1, 0, 1)) / SR) * amp
    rate = 36 * np.clip(1 - t / 2.1, 0.02, 1) ** 1.3 + 2.5
    cum = np.cumsum(rate) / SR
    last = 0
    for i in range(1, n):
        if int(cum[i]) > last and t[i] < 2.15:
            last = int(cum[i])
            add(x, burst_noise(0.01, 0.003, 1800, 6500) * (0.25 + 0.5 * amp[i]), t[i])
    add(x, burst_sine(62, 0.3, 0.1, 0.3) * 0.6, 2.0)
    add(x, burst_noise(0.06, 0.02, 600, 2500) * 0.3, 2.0)
    x = fade(lp(x, 8500), 0.005, 0.08)
    return norm(x, 0.8)


# ------------------------------------------------------------------ shield ----
def shield_deploy():
    d = 1.1
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    ph = sweep_phase(500, 1500, 0.2, int(0.2 * SR))
    add(x, np.sin(ph) * np.exp(-np.arange(len(ph)) / SR / 0.12) * 0.35, 0.0)      # electronic start
    ph = sweep_phase(180, 430, 0.9, int(0.9 * SR))                                   # servo rising
    serv = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.3 * np.sin(3 * ph)
    env = np.sin(np.linspace(0, np.pi, len(ph))) ** 0.7
    add(x, lp(serv, 1800) * env * 0.32, 0.08)
    sl = bp(noise(int(0.8 * SR)), 600, 2600) * np.sin(np.linspace(0, np.pi, int(0.8 * SR))) ** 1.5
    add(x, sl * 0.30, 0.15)                                                         # metallic slide
    add(x, burst_sine(75, 0.2, 0.06, 0.3) * 0.5, 0.95)                              # settle
    return norm(fade(x, 0.003, 0.05), 0.8)


def shield_lock():
    d = 0.3
    x = np.zeros(int(SR * d))
    add(x, burst_noise(0.1, 0.02, 1000, 4500) * 0.9, 0.0)
    add(x, burst_sine(92, 0.22, 0.07, 0.4) * 0.85, 0.0)
    add(x, burst_noise(0.05, 0.012, 1500, 5000) * 0.45, 0.07)
    return norm(fade(x, 0.001, 0.04), 0.8)


def shield_retract():
    d = 1.0
    n = int(SR * d)
    x = np.zeros(n)
    ph = sweep_phase(1200, 400, 0.22, int(0.22 * SR))
    add(x, np.sin(ph) * np.exp(-np.arange(len(ph)) / SR / 0.12) * 0.3, 0.0)         # electronic down-chirp
    ph = sweep_phase(430, 150, 0.8, int(0.8 * SR))
    serv = np.sin(ph) + 0.5 * np.sin(2 * ph)
    env = np.sin(np.linspace(0, np.pi, len(ph))) ** 0.6
    add(x, lp(serv, 1500) * env * 0.34, 0.05)
    sl = bp(noise(int(0.7 * SR)), 400, 2000) * np.sin(np.linspace(0, np.pi, int(0.7 * SR))) ** 1.2
    add(x, sl * 0.26, 0.12)
    add(x, burst_sine(60, 0.25, 0.08, 0.3) * 0.65, 0.78)
    add(x, burst_noise(0.04, 0.01, 500, 2200) * 0.3, 0.78)
    return norm(fade(x, 0.003, 0.05), 0.8)


# ------------------------------------------------------------------ vehicle transitions ----
def engine_start():
    d = 1.6
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    ph = sweep_phase(90, 270, 0.7, int(0.7 * SR))
    st = (np.sin(ph) + 0.4 * np.sin(2 * ph)) * np.sin(np.linspace(0, np.pi, len(ph))) ** 0.5
    add(x, lp(st, 1600) * 0.35, 0.0)
    add(x, bp(noise(int(0.7 * SR)), 200, 1200) * 0.18, 0.0)
    for tt, a in ((0.62, 0.9), (0.80, 0.8), (0.93, 0.7)):
        add(x, plus(burst_sine(48, 0.25, 0.09, 0.3) * a, burst_noise(0.1, 0.03, 60, 500) * 0.4 * a), tt)
    rate = np.where(t > 1.0, 6 + 8 * np.clip((t - 1.0) / 0.5, 0, 1), 0.0)
    cum = np.cumsum(rate) / SR
    last = 0
    for i in range(1, n):
        if int(cum[i]) > last:
            last = int(cum[i])
            add(x, burst_sine(52, 0.15, 0.05, 0.2) * 0.7, t[i])
    return norm(fade(lp(x, 3000), 0.003, 0.08), 0.8)


def engine_stop():
    d = 1.3
    n = int(SR * d)
    t = T(d)
    x = np.zeros(n)
    rate = 14 * np.clip(1 - t / 1.0, 0.05, 1) ** 1.4 + 1.5
    cum = np.cumsum(rate) / SR
    last = 0
    for i in range(1, n):
        if int(cum[i]) > last and t[i] < 1.1:
            last = int(cum[i])
            a = np.clip(1 - t[i] / 1.1, 0, 1) ** 0.8
            add(x, plus(burst_sine(50 - 12 * t[i], 0.16, 0.055, 0.2) * a, burst_noise(0.06, 0.02, 80, 400) * 0.25 * a), t[i])
    add(x, burst_sine(66, 0.3, 0.1, 0.3) * 0.55, 1.05)
    return norm(fade(lp(x, 2500), 0.003, 0.1), 0.75)


def gear_clunk():
    x = np.zeros(int(SR * 0.35))
    add(x, burst_sine(82, 0.25, 0.08, 0.35) * 0.9, 0.0)
    add(x, burst_noise(0.07, 0.015, 900, 3500) * 0.55, 0.0)
    add(x, burst_sine(1200, 0.08, 0.02) * 0.2, 0.01)
    return norm(fade(x, 0.001, 0.05), 0.75)


def suspension_clunk():
    d = 0.5
    x = np.zeros(int(SR * d))
    add(x, burst_sine(70, 0.3, 0.09, 0.5) * 0.85, 0.0)
    ph = sweep_phase(320, 170, 0.28, int(0.28 * SR))
    add(x, np.sin(ph) * np.exp(-np.arange(len(ph)) / SR / 0.12) * 0.16, 0.03)
    add(x, burst_noise(0.1, 0.03, 300, 2200) * 0.35, 0.0)
    return norm(fade(lp(x, 4000), 0.002, 0.08), 0.7)


def brake_hiss():
    d = 0.8
    n = int(SR * d)
    x = bp(noise(n), 2500, 8000) * np.exp(-np.arange(n) / SR / 0.25)
    x += 0.5 * bp(noise(n), 400, 1500) * np.exp(-np.arange(n) / SR / 0.12)
    add(x, burst_sine(60, 0.2, 0.07, 0.3) * 0.5, 0.0)
    return norm(fade(x, 0.003, 0.1), 0.6)


sounds = {
    'engine_loop': engine_loop, 'move_loop': move_loop, 'steer_loop': steer_loop,
    'rotor_loop': rotor_loop, 'rotor_startup': rotor_startup, 'rotor_spindown': rotor_spindown,
    'shield_deploy': shield_deploy, 'shield_lock': shield_lock, 'shield_retract': shield_retract,
    'engine_start': engine_start, 'engine_stop': engine_stop, 'gear_clunk': gear_clunk,
    'suspension_clunk': suspension_clunk, 'brake_hiss': brake_hiss,
}
for name, fn in sounds.items():
    x = fn()
    save(name, x)
    print(name, '%.2fs' % (len(x) / SR), 'peak %.2f' % np.max(np.abs(x)), os.path.getsize(f'{OUT}/{name}.ogg') // 1024, 'KB')
