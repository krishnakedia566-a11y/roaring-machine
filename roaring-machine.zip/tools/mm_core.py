"""Roaring Machine model generator core.

Design model in blocks (x: +left, h: up, z: +back, front = -z), emit:
  * packed texture atlas (PNG) with per-face painted surfaces
  * Java source (ModelGen.java) building the ModelData
  * software preview renders
Rotations are given in Minecraft model-frame radians (pitch about x, yaw about y, roll about z).
"""
import math, random
import numpy as np
from PIL import Image

U = 32  # units per block


# ----------------------------------------------------------------------------------------
# Scene graph
# ----------------------------------------------------------------------------------------
class Node:
    def __init__(self, name, pivot=(0, 0, 0), rot=(0, 0, 0), translucent=False, parent=None):
        self.name = name
        self.pivot = pivot      # blocks, relative to parent pivot: (x, h up, z)
        self.rot = rot          # radians (pitch, yaw, roll) model frame
        self.boxes = []
        self.kids = []
        self.translucent = translucent
        self.parent = parent

    def group(self, name, pivot=(0, 0, 0), rot=(0, 0, 0)):
        n = Node(name, pivot, rot, self.translucent, self)
        self.kids.append(n)
        return n

    def box(self, style, x0, x1, h0, h1, z0, z1, axis=None, mask=None, **opt):
        """Axis aligned box in this node's local frame (blocks)."""
        if x1 < x0: x0, x1 = x1, x0
        if h1 < h0: h0, h1 = h1, h0
        if z1 < z0: z0, z1 = z1, z0
        X0, X1 = round(x0 * U), round(x1 * U)
        H0, H1 = round(h0 * U), round(h1 * U)
        Z0, Z1 = round(z0 * U), round(z1 * U)
        if X1 <= X0: X1 = X0 + 1
        if H1 <= H0: H1 = H0 + 1
        if Z1 <= Z0: Z1 = Z0 + 1
        b = dict(style=style, x0=X0, x1=X1, h0=H0, h1=H1, z0=Z0, z1=Z1, axis=axis, mask=mask, opt=opt)
        self.boxes.append(b)
        return b

    def sym(self, style, xa, xb, h0, h1, z0, z1, **kw):
        """Mirror pair: left box at [xa, xb] (positive), right at [-xb, -xa]."""
        self.box(style, xa, xb, h0, h1, z0, z1, **kw)
        self.box(style, -xb, -xa, h0, h1, z0, z1, **kw)

    def all_boxes(self):
        for b in self.boxes:
            yield b
        for k in self.kids:
            yield from k.all_boxes()


# ----------------------------------------------------------------------------------------
# Painting
# ----------------------------------------------------------------------------------------
def _rng(seed):
    return np.random.default_rng(abs(hash(seed)) % (2 ** 32))


def _noise(h, w, amp, rng):
    return rng.normal(0, amp, (h, w))


def _profile(n, kind):
    """Brightness across a cylinder cross-section, n samples."""
    t = (np.arange(n) + 0.5) / n
    ang = (t - 0.5) * math.pi
    diffuse = np.clip(np.cos(ang - 0.45), 0, 1)
    spec = np.exp(-((ang + 0.35) / 0.20) ** 2)
    spec2 = np.exp(-((ang - 0.9) / 0.25) ** 2)
    if kind == 'chrome':
        v = 0.30 + 0.35 * diffuse + 0.95 * spec + 0.35 * spec2
        v *= 0.55 + 0.45 * np.cos(ang * 0.9)
        v = np.clip(v, 0.12, 1.25)
    elif kind == 'red':
        v = 0.45 + 0.55 * diffuse + 0.9 * spec
    elif kind == 'gold':
        v = 0.40 + 0.5 * diffuse + 0.8 * spec
    else:
        v = 0.35 + 0.65 * diffuse + 0.3 * spec
    return v


COL = {
    'chrome': (222, 227, 238),
    'steel': (184, 190, 202),
    'steel2': (130, 135, 146),
    'dark': (48, 50, 56),
    'black': (20, 20, 23),
    'red': (160, 8, 26),
    'gold': (205, 165, 62),
    'brass': (176, 128, 52),
    'copper': (196, 108, 70),
    'rubber': (24, 24, 27),
    'blue': (50, 110, 255),
    'leather': (150, 10, 28),
    'glass': (190, 222, 245),
    'purple': (150, 60, 200),
    'white': (225, 225, 230),
    'yellow': (255, 214, 70),
}


def _tint(col, mult):
    c = np.array(col, dtype=np.float32)
    return np.clip(c[None, None, :] * mult[..., None], 0, 255)


def _alpha(arr, a=255.0):
    h, w, _ = arr.shape
    out = np.zeros((h, w, 4), dtype=np.float32)
    out[..., :3] = arr
    out[..., 3] = a
    return out


def _border(out, col_mult, width=1):
    h, w, _ = out.shape
    if h < 2 * width + 2 or w < 2 * width + 2:
        return
    m = np.ones((h, w), dtype=np.float32)
    m[:width, :] = col_mult; m[-width:, :] = col_mult
    m[:, :width] = col_mult; m[:, -width:] = col_mult
    out[..., :3] *= m[..., None]


def _rivets(out, spacing, bright, dark, margin=3):
    h, w, _ = out.shape
    if w < 2 * margin + 4 or h < 2 * margin + 4:
        return
    xs = np.linspace(margin, w - 1 - margin, max(2, int((w - 2 * margin) // spacing) + 1)).round().astype(int)
    ys = np.linspace(margin, h - 1 - margin, max(2, int((h - 2 * margin) // spacing) + 1)).round().astype(int)
    pts = set()
    for x in xs:
        pts.add((x, margin)); pts.add((x, h - 1 - margin))
    for y in ys:
        pts.add((margin, y)); pts.add((w - 1 - margin, y))
    for (x, y) in pts:
        out[y, x, :3] = np.clip(out[y, x, :3] * bright, 0, 255)
        if x + 1 < w and y + 1 < h:
            out[y + 1, x + 1, :3] = out[y + 1, x + 1, :3] * dark


def paint(style, face, w, h, box, seed):
    """Return RGBA float array (h, w, 4) for one face."""
    rng = _rng(seed)
    axis = box['axis']
    base = COL.get(style, COL['steel'])
    opt = box['opt']
    cyl_kind = {'chrome': 'chrome', 'steel': 'chrome', 'red': 'red', 'gold': 'gold', 'brass': 'gold',
                'copper': 'gold', 'dark': 'dark', 'black': 'dark', 'steel2': 'chrome'}.get(style)

    # ---- cylinders (tubes) ----
    if axis is not None and style not in ('glass',):
        cross = None
        if axis == 'z':
            if face in ('top', 'bottom'): cross = 'u'
            elif face in ('east', 'west'): cross = 'v'
        elif axis == 'x':
            if face in ('top', 'bottom'): cross = 'v'
            elif face in ('north', 'south'): cross = 'v'
        elif axis == 'y':
            if face in ('north', 'south', 'east', 'west'): cross = 'u'
        if cross is not None:
            n = w if cross == 'u' else h
            prof = _profile(max(n, 2), cyl_kind)
            if cross == 'u':
                m = np.tile(prof[None, :w], (h, 1))
            else:
                m = np.tile(prof[:h, None], (1, w))
            m = m * (1 + _noise(h, w, 0.03, rng))
            out = _alpha(_tint(base, m))
            return out
        # caps
        m = np.ones((h, w)) * 0.75 + _noise(h, w, 0.03, rng)
        out = _alpha(_tint(base, m))
        if w >= 3 and h >= 3:
            cy, cx = (h - 1) / 2, (w - 1) / 2
            yy, xx = np.mgrid[0:h, 0:w]
            r = np.hypot((yy - cy) / max(h / 2, 1), (xx - cx) / max(w / 2, 1))
            bore = r < 0.55
            out[bore, :3] = (15, 15, 18)
        return out

    # ---- surfaces ----
    if style == 'glass':
        a = np.full((h, w), 70.0)
        a[:1, :] = 210; a[-1:, :] = 210; a[:, :1] = 210; a[:, -1:] = 210
        yy, xx = np.mgrid[0:h, 0:w]
        stripe = ((xx + yy * 0.6) % 24) < 3
        a[stripe] = np.maximum(a[stripe], 120)
        rgb = np.ones((h, w, 3)) * np.array(COL['glass'])
        rgb[stripe] = (245, 250, 255)
        out = np.zeros((h, w, 4), dtype=np.float32)
        out[..., :3] = rgb
        out[..., 3] = a
        return out

    if style == 'red':
        yy = np.linspace(1.0, 0.55, h)[:, None] * np.ones((1, w))
        # soft vertical specular band
        xx = np.linspace(0, 1, w)[None, :] * np.ones((h, 1))
        spec = np.exp(-((xx - 0.3) / 0.12) ** 2) * 0.55
        m = yy * (0.75 + 0.25 * np.sin(xx * math.pi)) + spec
        m = m * (1 + _noise(h, w, 0.025, rng))
        out = _alpha(_tint(base, m))
        if w >= 3 and h >= 3:
            out[..., 0] = np.clip(out[..., 0] + spec * 120, 0, 255)
            out[..., 1] = np.clip(out[..., 1] + spec * 70, 0, 255)
            out[..., 2] = np.clip(out[..., 2] + spec * 70, 0, 255)
        _border(out, 0.72)
        return out

    if style == 'leather':
        yy, xx = np.mgrid[0:h, 0:w]
        cx, cy = (w - 1) / 2, (h - 1) / 2
        puff = 1.05 - 0.45 * (((xx - cx) / max(w / 2, 1)) ** 2 + ((yy - cy) / max(h / 2, 1)) ** 2) * 0.7
        m = puff * (1 + _noise(h, w, 0.04, rng))
        out = _alpha(_tint(base, m))
        if w > 14 and h > 8:
            ins = 3
            out[ins, ins:w - ins, :3] *= 1.55
            out[h - 1 - ins, ins:w - ins, :3] *= 0.6
            out[ins:h - ins, ins, :3] *= 1.55
            out[ins:h - ins, w - 1 - ins, :3] *= 0.6
            for k in range(ins, w - ins, 2):
                out[ins, k, :3] = (235, 225, 225)
                out[h - 1 - ins, k, :3] = (235, 225, 225)
            for k in range(ins, h - ins, 2):
                out[k, ins, :3] = (235, 225, 225)
                out[k, w - 1 - ins, :3] = (235, 225, 225)
            if opt.get('ribs'):
                for ry in range(h // opt['ribs'], h, h // opt['ribs']):
                    out[ry, :, :3] *= 0.55
        return out

    if style in ('steel', 'steel2', 'chrome'):
        yy = np.linspace(1.02, 0.78, h)[:, None] * np.ones((1, w))
        brushed = 1 + _noise(1, w, 0.04, rng) + _noise(h, 1, 0.015, rng)
        m = yy * brushed
        if style == 'chrome':
            xx = np.linspace(0, 1, w)[None, :]
            m = m * (0.85 + 0.35 * np.exp(-((xx - 0.3) / 0.2) ** 2))
        out = _alpha(_tint(base, m))
        if opt.get('panel', True) and w > 10 and h > 10:
            _border(out, 0.62)
            if opt.get('rivets', True):
                _rivets(out, 14, 1.35, 0.55)
            if opt.get('inset', False) and w > 20 and h > 20:
                out[4, 4:w - 4, :3] *= 0.7; out[h - 5, 4:w - 4, :3] *= 1.25
                out[4:h - 4, 4, :3] *= 0.7; out[4:h - 4, w - 5, :3] *= 1.25
        if opt.get('vents') and w > 16 and h > 16:
            for vy in range(5, h - 5, 4):
                out[vy, 5:w - 5, :3] = (25, 25, 28)
        return out

    if style in ('dark', 'black'):
        m = 1 + _noise(h, w, 0.06, rng)
        out = _alpha(_tint(base, m))
        if w > 10 and h > 10 and opt.get('rivets', False):
            _rivets(out, 12, 2.0, 0.7)
        _border(out, 0.7)
        return out

    if style == 'rubber':
        yy, xx = np.mgrid[0:h, 0:w]
        tread = (((xx // 3 + yy // 3) % 2) == 0) if opt.get('tread') else np.zeros((h, w), bool)
        m = (1 + _noise(h, w, 0.08, rng)) * np.where(tread, 1.5, 1.0)
        return _alpha(_tint(base, m))

    if style in ('gold', 'brass', 'copper'):
        xx = np.linspace(0, 1, w)[None, :] * np.ones((h, 1))
        m = 0.75 + 0.5 * np.exp(-((xx - 0.3) / 0.25) ** 2)
        m = m * (1 + _noise(h, w, 0.04, rng))
        out = _alpha(_tint(base, m))
        if opt.get('link') and w > 4 and h > 4:
            out[h // 2, :, :3] *= 0.45
        return out

    if style == 'blue':
        yy, xx = np.mgrid[0:h, 0:w]
        cx, cy = (w - 1) / 2, (h - 1) / 2
        r = np.hypot((xx - cx) / max(w / 2, 1), (yy - cy) / max(h / 2, 1))
        m = 1.2 - 0.6 * r
        out = _alpha(_tint(base, m))
        return out

    m = 1 + _noise(h, w, 0.04, rng)
    return _alpha(_tint(base, m))


def apply_mask(arr, mask, face):
    h, w, _ = arr.shape
    yy, xx = np.mgrid[0:h, 0:w]
    cx, cy = (w - 1) / 2, (h - 1) / 2
    r = np.hypot((xx - cx) / max(w / 2, 0.5), (yy - cy) / max(h / 2, 0.5))
    if mask == 'disc':
        arr[..., 3] = np.where(r <= 1.0, arr[..., 3], 0)
    elif isinstance(mask, tuple) and mask[0] == 'ring':
        arr[..., 3] = np.where((r <= 1.0) & (r >= mask[1]), arr[..., 3], 0)
    return arr


def paint_disc_detail(arr, box, face, rng):
    """Bolt circle + concentric rings on the visible face of a disc plate."""
    h, w, _ = arr.shape
    opt = box['opt']
    if not opt.get('bolts'):
        return arr
    yy, xx = np.mgrid[0:h, 0:w]
    cx, cy = (w - 1) / 2, (h - 1) / 2
    r = np.hypot((xx - cx) / max(w / 2, 0.5), (yy - cy) / max(h / 2, 0.5))
    n = opt['bolts']
    ang = np.arctan2(yy - cy, xx - cx)
    ring = np.abs(r - opt.get('bolt_r', 0.8)) < 0.07
    bolt = ring & (np.cos(ang * n) > 0.93)
    arr[bolt, :3] = (235, 235, 240)
    arr[ring & ~bolt, :3] *= 0.7
    inner = np.abs(r - 0.45) < 0.03
    arr[inner, :3] *= 0.6
    return arr


# ----------------------------------------------------------------------------------------
# Atlas packing and painting
# ----------------------------------------------------------------------------------------
class Atlas:
    def __init__(self, width=1024):
        self.width = width

    def pack(self, boxes):
        items = []
        for b in boxes:
            dx = b['x1'] - b['x0']; dy = b['h1'] - b['h0']; dz = b['z1'] - b['z0']
            b['dx'], b['dy'], b['dz'] = dx, dy, dz
            W = 2 * (dx + dz); H = dy + dz
            items.append((H, W, b))
        items.sort(key=lambda t: (-t[0], -t[1]))
        x = y = 0
        shelf_h = 0
        pad = 1
        for H, W, b in items:
            if x + W + pad > self.width:
                x = 0; y += shelf_h + pad; shelf_h = 0
            b['u'] = x; b['v'] = y
            x += W + pad
            shelf_h = max(shelf_h, H)
        self.height = int(math.ceil((y + shelf_h + pad) / 16.0) * 16)
        return self.height

    def paint(self, boxes, seed_base='rm'):
        img = np.zeros((self.height, self.width, 4), dtype=np.float32)
        for i, b in enumerate(boxes):
            dx, dy, dz = b['dx'], b['dy'], b['dz']
            u, v = b['u'], b['v']
            seed = f"{seed_base}{i}{b['style']}"
            rng = _rng(seed)
            faces = {
                'top': (u + dz, v, dx, dz),
                'bottom': (u + dz + dx, v, dx, dz),
                'west': (u, v + dz, dz, dy),
                'north': (u + dz, v + dz, dx, dy),
                'east': (u + dz + dx, v + dz, dz, dy),
                'south': (u + 2 * dz + dx, v + dz, dx, dy),
            }
            for face, (fu, fv, fw, fh) in faces.items():
                if fw < 1 or fh < 1:
                    continue
                arr = paint(b['style'], face, fw, fh, b, seed + face)
                m = b['mask']
                if m is not None:
                    big = face in ('north', 'south') if b['opt'].get('disc_axis', 'z') == 'z' else face in ('east', 'west')
                    if b['opt'].get('disc_axis', 'z') == 'y':
                        big = face in ('top', 'bottom')
                    if big:
                        arr = paint_disc_detail(arr, b, face, rng)
                        arr = apply_mask(arr, m, face)
                    else:
                        if b['opt'].get('edges_clear', True):
                            arr[..., 3] = 0
                img[fv:fv + fh, fu:fu + fw] = arr
        return np.clip(img, 0, 255).astype(np.uint8)


# ----------------------------------------------------------------------------------------
# Java codegen
# ----------------------------------------------------------------------------------------
def fmt(v):
    if abs(v - round(v)) < 1e-6:
        return f"{int(round(v))}f"
    return f"{v:.4f}f"


def builder_expr(node):
    parts = ["ModelPartBuilder.create()"]
    for b in node.boxes:
        parts.append(f".uv({b['u']}, {b['v']}).cuboid({fmt(b['x0'])}, {fmt(-b['h1'])}, {fmt(b['z0'])}, "
                     f"{fmt(b['dx'])}, {fmt(b['dy'])}, {fmt(b['dz'])})")
    return "".join(parts)


def transform_expr(node):
    px, ph, pz = node.pivot
    rx, ry, rz = node.rot
    x, y, z = px * U, -ph * U, pz * U
    if rx == 0 and ry == 0 and rz == 0:
        return f"ModelTransform.pivot({fmt(x)}, {fmt(y)}, {fmt(z)})"
    return f"ModelTransform.of({fmt(x)}, {fmt(y)}, {fmt(z)}, {fmt(rx)}, {fmt(ry)}, {fmt(rz)})"


class Codegen:
    def __init__(self):
        self.methods = []
        self.count = 0

    def emit_node(self, node, parent_var, lines, name_registry):
        """Emit statements adding `node` under parent_var into `lines`."""
        nm = node.name
        i = name_registry.get(nm, 0)
        name_registry[nm] = i + 1
        if i:
            nm = f"{nm}_{i}"
        if not node.kids:
            lines.append(f'{parent_var}.addChild("{nm}", {builder_expr(node)}, {transform_expr(node)});')
            return
        self.count += 1
        mname = f"build{self.count}_{node.name.replace('-', '_')}"
        lines.append(f'{mname}({parent_var}.addChild("{nm}", {builder_expr(node)}, {transform_expr(node)}));')
        body = []
        reg = {}
        for k in node.kids:
            self.emit_node(k, "g", body, reg)
        # chunk body into methods of 120 statements
        chunks = [body[i:i + 120] for i in range(0, len(body), 120)] or [[]]
        out = [f"    private static void {mname}(ModelPartData g) {{"]
        if len(chunks) == 1:
            out += ["        " + l for l in chunks[0]]
        else:
            for ci, ch in enumerate(chunks):
                out.append(f"        {mname}_p{ci}(g);")
        out.append("    }")
        for ci, ch in enumerate(chunks):
            if len(chunks) > 1:
                out.append(f"    private static void {mname}_p{ci}(ModelPartData g) {{")
                out += ["        " + l for l in ch]
                out.append("    }")
        self.methods.append("\n".join(out))

    def _top(self, roots):
        top = []
        reg = {}
        for r in roots:
            self.emit_node(r, "root", top, reg)
        return top

    def generate(self, roots, tex_w, tex_h, class_name="ModelGen", package="com.roaringmachine.client"):
        solid = self._top([r for r in roots if not r.translucent])
        glass = self._top([r for r in roots if r.translucent])
        src = [f"package {package};", "",
               "import net.minecraft.client.model.ModelPartBuilder;",
               "import net.minecraft.client.model.ModelPartData;",
               "import net.minecraft.client.model.ModelTransform;", "",
               "/** GENERATED by the model generator. Do not edit by hand. */",
               f"final class {class_name} {{",
               f"    static final int TEX_W = {tex_w};",
               f"    static final int TEX_H = {tex_h};", "",
               f"    private {class_name}() {{}}", ""]
        for label, lines in (("Solid", solid), ("Glass", glass)):
            chunks = [lines[i:i + 100] for i in range(0, len(lines), 100)] or [[]]
            src.append(f"    static void build{label}(ModelPartData root) {{")
            for ci in range(len(chunks)):
                src.append(f"        top{label}{ci}(root);")
            src.append("    }")
            for ci, ch in enumerate(chunks):
                src.append(f"    private static void top{label}{ci}(ModelPartData root) {{")
                src += ["        " + l for l in ch]
                src.append("    }")
            src.append("")
        src += self.methods
        src.append("}")
        return "\n".join(src) + "\n"


# ----------------------------------------------------------------------------------------
# Software preview renderer
# ----------------------------------------------------------------------------------------
def rot_zyx(rx, ry, rz):
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def collect_quads(node, M, t, quads, only_translucent=None):
    """M: 3x3, t: translation (units, model frame, y down)."""
    px, ph, pz = node.pivot
    p = np.array([px * U, -ph * U, pz * U])
    t2 = t + M @ p
    M2 = M @ rot_zyx(*node.rot)
    for b in node.boxes:
        x0, x1 = b['x0'], b['x1']
        y0, y1 = -b['h1'], -b['h0']
        z0, z1 = b['z0'], b['z1']
        c = {}
        for ix, X in enumerate((x0, x1)):
            for iy, Y in enumerate((y0, y1)):
                for iz, Z in enumerate((z0, z1)):
                    c[(ix, iy, iz)] = M2 @ np.array([X, Y, Z]) + t2
        dx, dy, dz = b['dx'], b['dy'], b['dz']
        u, v = b['u'], b['v']
        # face: corner list in order mapping to (u2,v1),(u1,v1),(u1,v2),(u2,v2)
        def q(face, verts, u1, v1, u2, v2):
            quads.append((face, [c[k] for k in verts], (u1, v1, u2, v2), node.translucent))
        # vertex ids: vertex=(0,0,0) v2=(1,0,0) v3=(1,1,0) v4=(0,1,0) v5=(0,0,1) v6=(1,0,1) v7=(1,1,1) v8=(0,1,1)
        V = {1: (0, 0, 0), 2: (1, 0, 0), 3: (1, 1, 0), 4: (0, 1, 0), 5: (0, 0, 1), 6: (1, 0, 1), 7: (1, 1, 1), 8: (0, 1, 1)}
        j = u + dz; k = u + dz + dx; l = u + dz + dx + dx; m = u + dz + dx + dz; n = u + 2 * dz + 2 * dx
        o = v; pp = v + dz; qq = v + dz + dy
        q('bottom_minY', [V[6], V[5], V[1], V[2]], j, o, k, pp)       # at min y (visually up)
        q('top_maxY', [V[3], V[4], V[8], V[7]], k, pp, l, o)
        q('west', [V[1], V[5], V[8], V[4]], u, pp, j, qq)
        q('north', [V[2], V[1], V[4], V[3]], j, pp, k, qq)
        q('east', [V[6], V[2], V[3], V[7]], k, pp, m, qq)
        q('south', [V[5], V[6], V[7], V[8]], m, pp, n, qq)
    for kd in node.kids:
        collect_quads(kd, M2, t2, quads)


def render_preview(roots, atlas_img, out_path, cam_yaw=35, cam_pitch=15, dist=9.0, size=(1100, 650),
                   fov=1.0, bg=(150, 190, 235), extra_pitch=None, glass=True, tilt=(0, 0), target=(0.0, 1.0, 0.0)):
    quads = []
    for r in roots:
        collect_quads(r, np.eye(3), np.zeros(3), quads)
    W, H = size
    img = np.zeros((H, W, 3), dtype=np.float32)
    img[:] = np.array(bg, dtype=np.float32)
    # ground
    img[int(H * 0.62):, :] = (95, 130, 60)
    zbuf = np.full((H, W), 1e9, dtype=np.float32)
    tex = atlas_img.astype(np.float32)
    th, tw, _ = tex.shape

    # model frame (y down, z back) -> world (x left, y up, z forward): (mx, -my, -mz)
    yaw = math.radians(cam_yaw); pit = math.radians(cam_pitch)
    # camera orbit around the vehicle centre (0, 1.0 block, 0), in blocks
    target = np.array(target, dtype=float)
    cp = np.array([math.sin(yaw) * math.cos(pit), math.sin(pit), math.cos(yaw) * math.cos(pit)]) * dist + target
    fwd = target - cp; fwd /= np.linalg.norm(fwd)
    right = np.cross(fwd, np.array([0, 1, 0.0])); right /= np.linalg.norm(right)
    up = np.cross(right, fwd)
    focal = (W / 2) / math.tan(fov / 2)

    def to_cam(p_model):
        w = np.array([p_model[0], -p_model[1], -p_model[2]]) / U  # blocks, world
        d = w - cp
        return np.array([d @ right, d @ up, d @ fwd])

    shade = {'bottom_minY': 1.0, 'top_maxY': 0.5, 'west': 0.78, 'east': 0.78, 'north': 0.88, 'south': 0.88}
    order = []
    for qd in quads:
        cams = [to_cam(p) for p in qd[1]]
        zc = sum(c[2] for c in cams) / 4
        order.append((zc, qd, cams))
    order.sort(key=lambda t: -t[0])  # painter-ish back to front, plus zbuf
    translucent_q = []
    for zc, qd, cams in order:
        if qd[3]:
            translucent_q.append((zc, qd, cams)); continue
        draw_quad(img, zbuf, tex, qd, cams, focal, W, H, shade)
    if glass:
        for zc, qd, cams in translucent_q:
            draw_quad(img, zbuf, tex, qd, cams, focal, W, H, shade, blend=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).save(out_path)


def draw_quad(img, zbuf, tex, qd, cams, focal, W, H, shade, blend=False):
    face, verts, (u1, v1, u2, v2), _ = qd
    if any(c[2] < 0.2 for c in cams):
        return
    scr = [(W / 2 + focal * c[0] / c[2], H / 2 - focal * c[1] / c[2]) for c in cams]
    uvs = [(u2, v1), (u1, v1), (u1, v2), (u2, v2)]
    th, tw, _ = tex.shape
    for tri in ((0, 1, 2), (0, 2, 3)):
        pts = [scr[i] for i in tri]
        zs = [cams[i][2] for i in tri]
        uv = [uvs[i] for i in tri]
        minx = max(int(math.floor(min(p[0] for p in pts))), 0)
        maxx = min(int(math.ceil(max(p[0] for p in pts))), W - 1)
        miny = max(int(math.floor(min(p[1] for p in pts))), 0)
        maxy = min(int(math.ceil(max(p[1] for p in pts))), H - 1)
        if minx > maxx or miny > maxy:
            continue
        (x0, y0), (x1, y1), (x2, y2) = pts
        den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
        if abs(den) < 1e-9:
            continue
        xs = np.arange(minx, maxx + 1) + 0.5
        ys = np.arange(miny, maxy + 1) + 0.5
        X, Y = np.meshgrid(xs, ys)
        a = ((y1 - y2) * (X - x2) + (x2 - x1) * (Y - y2)) / den
        b = ((y2 - y0) * (X - x2) + (x0 - x2) * (Y - y2)) / den
        c = 1 - a - b
        inside = (a >= -0.001) & (b >= -0.001) & (c >= -0.001)
        if not inside.any():
            continue
        # perspective-correct
        iz = a / zs[0] + b / zs[1] + c / zs[2]
        z = 1.0 / np.maximum(iz, 1e-9)
        pa = (a / zs[0]) * z; pb = (b / zs[1]) * z; pc = (c / zs[2]) * z
        U_ = pa * uv[0][0] + pb * uv[1][0] + pc * uv[2][0]
        V_ = pa * uv[0][1] + pb * uv[1][1] + pc * uv[2][1]
        ti = np.clip(np.floor(U_).astype(int), 0, tw - 1)
        tj = np.clip(np.floor(V_).astype(int), 0, th - 1)
        px = tex[tj, ti]
        al = px[..., 3] / 255.0
        zb = zbuf[miny:maxy + 1, minx:maxx + 1]
        sh = shade[face]
        if blend:
            ok = inside & (z < zb) & (al > 0.02)
            sub = img[miny:maxy + 1, minx:maxx + 1]
            sub[ok] = sub[ok] * (1 - al[ok, None]) + px[ok, :3] * sh * al[ok, None]
        else:
            ok = inside & (z < zb) & (al > 0.4)
            sub = img[miny:maxy + 1, minx:maxx + 1]
            sub[ok] = px[ok, :3] * sh
            zb[ok] = z[ok]
