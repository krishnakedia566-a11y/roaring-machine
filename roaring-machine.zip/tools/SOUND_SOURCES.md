# Sound sources (all cut from the film clips, nothing synthesized)
Every clip is first cleaned (tonal drone notched, music/voices cut to 25 % by harmonic/percussive split, steady noise subtracted); see clean() in make_sounds_film.py.
Script: tools/make_sounds_film.py  (clips are the user's uploads, audio cut + fades + loop crossfade + loudness only)

| Mod sound | Source clip | Cut (s) |
|---|---|---|
| engine_loop | 226882 (rear view) | 0.00-1.26 |
| engine_start | 226881 | 0.0-1.8 |
| engine_stop | 226880 | 2.8-3.85 |
| move_loop | 226880 (rolling in) | 0.35-3.60 |
| steer_loop | 226880 (band-passed 500-4500 Hz) | 1.0-3.2 |
| fire_loop | 228679 (firing) | 0.35-3.95 |
| rotor_loop | 228680 (belts/barrels) | 0.05-1.55 |
| rotor_startup | 226887 | 0.6-2.7 |
| rotor_spindown | 228680 | 0.9-1.83 |
| cannon_deploy | 226881 | 3.0-4.3 |
| cannon_retract | 226881 reversed | 3.0-4.3 |
| shield_deploy / retract | 226887 / reversed | 4.9-6.1 |
| shield_lock | 226887 | 5.0-5.4 |
| gear_clunk | 228680 | 0.2-0.7 |
| suspension_clunk | 226883 | 0.70-1.15 |
| brake_hiss | 226883 (high-passed) | 3.4-4.6 |
| bullet_impact 1/2/3 | 226883, 226883, 228681 | see script |

If a sound feels wrong, tell which clip it should come from and the mapping is changed in this one file.
| casing_drop 1/2/3 (brass clink on ground) | 228680, single clinks found by onset detection | 0.587 / 0.91 / 1.097 (+0.22 s) |
| shield_hit 1/2/3 (bullet or hit on the shield) | 228679, three sharpest metallic hits | 0.63 / 1.94 / 2.355 (+0.38 s) |
| mob_hit 1/2 (bullet hits a mob) | 226883, two low thumps | 0.48 / 0.91 (+0.40 s) |

Vanilla Minecraft sounds are no longer used for the shield; every mod sound comes from the clips above.
