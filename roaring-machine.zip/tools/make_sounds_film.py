"""Builds the mod sounds ONLY from audio cut out of the user's film clips (no synthesis).
Every sound = a cut of a clip + fades / loop-crossfade / loudness. See SOUND_SOURCES.md for the clip map."""
import os, subprocess, wave, shutil
import numpy as np
from scipy import signal

U = '/mnt/user-data/uploads'
WAV = '/tmp/ref/wav'
OUT = '/home/claude/proj/src/main/resources/assets/roaringmachine/sounds'
SR = 44100
os.makedirs(WAV, exist_ok=True)
os.makedirs(OUT, exist_ok=True)


def raw_clip(name):
    w = f'{WAV}/{name}.wav'
    if not os.path.exists(w):
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', f'{U}/{name}.mp4', '-vn', '-ac', '1', '-ar', str(SR), w], check=True)
    wf = wave.open(w)
    x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float64) / 32768.0
    wf.close()
    return x


def clean(x):
    """Take the film music / voices / hum out of a clip and keep the effects (guns, metal, rolling):
    1) notch the stationary tonal lines (drone, whistle) that show up as narrow peaks in the long-term spectrum,
    2) harmonic/percussive split with soft masks: sustained tonal stuff (music, voices) is cut to 25 %,
    3) mild spectral subtraction of the steady background noise floor."""
    sr = SR
    f, t, Z = signal.stft(x, sr, nperseg=4096, noverlap=3072)
    avg = (np.abs(Z) ** 2).mean(axis=1)
    from scipy import ndimage
    ratio = avg / (ndimage.median_filter(avg, size=61) + 1e-12)
    y = x.copy()
    for i in np.argsort(ratio)[::-1][:8]:
        if 10 * np.log10(ratio[i]) > 7.0 and f[i] > 40:
            b, a = signal.iirnotch(f[i] / (sr / 2), 25.0)
            y = signal.filtfilt(b, a, y)
    f, t, Z = signal.stft(y, sr, nperseg=2048, noverlap=1536)
    S = np.abs(Z)
    Hm = ndimage.median_filter(S, size=(1, 17))
    Pm = ndimage.median_filter(S, size=(17, 1))
    mask_h = Hm ** 2 / (Hm ** 2 + Pm ** 2 + 1e-12)
    Z2 = Z * ((1.0 - mask_h) + 0.25 * mask_h)
    A = np.abs(Z2)
    noise = np.percentile(A, 20, axis=1, keepdims=True)
    gain = np.maximum(A - 0.8 * noise, 0.2 * A) / (A + 1e-12)
    _, out = signal.istft(Z2 * gain, sr, nperseg=2048, noverlap=1536)
    out = out[:len(x)]
    return np.pad(out, (0, max(0, len(x) - len(out))))


_cache = {}


def clip(name):
    if name not in _cache:
        _cache[name] = clean(raw_clip(name))
    return _cache[name]


def cut(name, t0, t1):
    x = clip(name)
    return x[int(t0 * SR):int(min(t1, len(x) / SR) * SR)].copy()


def hp(x, f=60):
    b, a = signal.butter(2, f / (SR / 2), 'high')
    return signal.lfilter(b, a, x)


def band(x, lo, hi):
    b, a = signal.butter(2, [lo / (SR / 2), hi / (SR / 2)], 'band')
    return signal.lfilter(b, a, x)


def loudify(x, rms_db=-15.0, peak=0.97):
    """Raise the level (these film cuts are quiet), soft-limit so peaks do not clip."""
    x = x - np.mean(x)
    r = np.sqrt(np.mean(x ** 2)) + 1e-9
    g = 10 ** (rms_db / 20) / r
    y = np.tanh(x * g * 1.2) / np.tanh(1.2)
    m = np.max(np.abs(y)) + 1e-9
    return y * min(1.0, peak / m)


def fade(x, fin=0.004, fout=0.02):
    n_in, n_out = int(fin * SR), int(fout * SR)
    x = x.copy()
    if n_in:
        x[:n_in] *= np.linspace(0, 1, n_in)
    if n_out:
        x[-n_out:] *= np.linspace(1, 0, n_out)
    return x


def make_loop(x, xf=0.25):
    n = int(xf * SR)
    if len(x) <= 2 * n:
        n = len(x) // 3
    body = x[:-n].copy()
    t = np.linspace(0, np.pi / 2, n)
    body[:n] = x[:n] * np.sin(t) + x[-n:] * np.cos(t)      # equal-power crossfade: tail into head
    return body


def save(name, x):
    x = np.clip(x, -1, 1)
    w = f'/tmp/_{name}.wav'
    with wave.open(w, 'wb') as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR)
        f.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', w, '-c:a', 'libvorbis', '-q:a', '5', f'{OUT}/{name}.ogg'], check=True)
    print(f'{name:18s} {len(x)/SR:5.2f}s  {os.path.getsize(f"{OUT}/{name}.ogg")//1024} KB')


S = {}
# ---- engine / rolling (machine rolling in on the carpet, rear idle shot) -------------------------
S['engine_loop'] = make_loop(loudify(hp(cut('226882', 0.0, 1.26)), -13), 0.30)
S['engine_start'] = fade(loudify(hp(cut('226881', 0.0, 1.8)), -13), 0.01, 0.25)
S['engine_stop'] = fade(loudify(hp(cut('226880', 2.8, 3.85)), -14), 0.01, 0.55)
S['move_loop'] = make_loop(loudify(hp(cut('226880', 0.35, 3.60), 80), -14), 0.45)
S['steer_loop'] = make_loop(loudify(band(cut('226880', 1.0, 3.2), 500, 4500), -17), 0.4)
# ---- rotary guns -------------------------------------------------------------------------------
S['fire_loop'] = make_loop(loudify(hp(cut('228679', 0.35, 3.95)), -10, 0.98), 0.35)
S['rotor_loop'] = make_loop(loudify(hp(cut('228680', 0.05, 1.55)), -14), 0.30)
S['rotor_startup'] = fade(loudify(hp(cut('226887', 0.6, 2.7)), -12), 0.01, 0.2)
S['rotor_spindown'] = fade(loudify(hp(cut('228680', 0.9, 1.83)), -14), 0.005, 0.30)
S['cannon_deploy'] = fade(loudify(hp(cut('226881', 3.0, 4.3)), -12), 0.005, 0.15)
S['cannon_retract'] = fade(loudify(hp(cut('226881', 3.0, 4.3))[::-1].copy(), -12), 0.005, 0.15)
# ---- shield --------------------------------------------------------------------------------------
sh = loudify(hp(cut('226887', 4.9, 6.1)), -12)
S['shield_deploy'] = fade(sh, 0.005, 0.2)
S['shield_retract'] = fade(sh[::-1].copy(), 0.005, 0.2)
S['shield_lock'] = fade(loudify(hp(cut('226887', 5.0, 5.4)), -9), 0.002, 0.08)
# ---- clunks / brake ------------------------------------------------------------------------------
S['gear_clunk'] = fade(loudify(hp(cut('228680', 0.2, 0.7), 120), -9), 0.002, 0.1)
S['suspension_clunk'] = fade(loudify(hp(cut('226883', 0.70, 1.15), 70), -9), 0.002, 0.15)
S['brake_hiss'] = fade(loudify(hp(cut('226883', 3.4, 4.6), 800), -17), 0.05, 0.4)
# ---- bullets hitting the ground (3 variants) -----------------------------------------------------
S['bullet_impact_1'] = fade(loudify(hp(cut('226883', 0.50, 0.80), 90), -10), 0.002, 0.08)
S['bullet_impact_2'] = fade(loudify(hp(cut('226883', 0.80, 1.10), 90), -10), 0.002, 0.08)
S['bullet_impact_3'] = fade(loudify(hp(cut('228681', 0.30, 0.55), 90), -10), 0.002, 0.07)

# ---- extra: casing clinks, shield hits, mob hits (individual transients found by onset detection in the clips) ----
for i, t in enumerate((0.587, 0.91, 1.097), 1):
    S[f'casing_drop_{i}'] = fade(loudify(hp(cut('228680', t, t + 0.22), 1200), -11), 0.001, 0.09)
for i, t in enumerate((0.63, 1.94, 2.355), 1):
    S[f'shield_hit_{i}'] = fade(loudify(hp(cut('228679', t, t + 0.38), 150), -8, 0.99), 0.001, 0.16)
for i, t in enumerate((0.48, 0.91), 1):
    S[f'mob_hit_{i}'] = fade(loudify(hp(cut('226883', t, t + 0.40), 60), -9, 0.99), 0.002, 0.16)

if __name__ == '__main__':
    bk = '/home/claude/sounds_synth_backup'
    if not os.path.exists(bk):
        shutil.copytree(OUT, bk)
    for k, v in S.items():
        save(k, v)
