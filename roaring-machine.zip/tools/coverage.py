import math, numpy as np, importlib, sys
import mm_core, mm_model
U = 38.0

def world_boxes(roots):
    """All solid boxes as (min,max corners) sample points in design blocks: x left+, h up, z back+."""
    pts = []
    def walk(node, M, t):
        px, ph, pz = node.pivot
        p = np.array([px * U, -ph * U, pz * U])
        t2 = t + M @ p
        M2 = M @ mm_core.rot_zyx(*node.rot)
        if not (node.translucent or node.flash):
            for b in node.boxes:
                xs = np.linspace(b['x0'], b['x1'], max(2, int((b['x1'] - b['x0']) / 5) + 1))
                ys = np.linspace(-b['h1'], -b['h0'], max(2, int((b['h1'] - b['h0']) / 5) + 1))
                zs = np.linspace(b['z0'], b['z1'], max(2, int((b['z1'] - b['z0']) / 5) + 1))
                for x in xs:
                    for y in ys:
                        for z in zs:
                            q = M2 @ np.array([x, y, z]) + t2
                            pts.append((q[0] / U, -q[1] / U, q[2] / U))
        for k in node.kids:
            walk(k, M2, t2)
    for r in roots:
        walk(r, np.eye(3), np.zeros(3))
    return np.array(pts)

def parts_cover(pts, parts, theta):
    c, s = math.cos(theta), math.sin(theta)
    # rotate model points about the vertical axis (x,z plane)
    x = pts[:, 0] * c + pts[:, 2] * s
    z = -pts[:, 0] * s + pts[:, 2] * c
    h = pts[:, 1]
    covered = np.zeros(len(pts), bool)
    for (pz, px, y0, w, hh) in parts:
        cx = px * c + pz * s
        cz = -px * s + pz * c
        m = (np.abs(x - cx) <= w / 2) & (np.abs(z - cz) <= w / 2) & (h >= y0 - 1e-6) & (h <= y0 + hh + 1e-6)
        covered |= m
    return covered, x, z, h

if __name__ == '__main__':
    roots = mm_model.build()
    pts = world_boxes(roots)
    print('sample points', len(pts))
    parts = eval(open('/home/claude/parts.txt').read())
    print('parts', len(parts))
    worst = 1.0
    for deg in (0, 20, 45, 70, 90, 135, 180):
        cov, x, z, h = parts_cover(pts, parts, math.radians(deg))
        frac = cov.mean()
        worst = min(worst, frac)
        print('yaw %3d: covered %.1f%%' % (deg, frac * 100))
    cov, x, z, h = parts_cover(pts, parts, 0.0)
    un = pts[~cov]
    if len(un):
        # cluster uncovered by 0.4 grid in (x,z) at yaw 0
        cells = {}
        for p in un:
            key = (round(p[0] / 0.4) * 0.4, round(p[2] / 0.4) * 0.4)
            cells.setdefault(key, []).append(p[1])
        items = sorted(cells.items(), key=lambda kv: -len(kv[1]))[:12]
        print('top uncovered cells (x, z): count, h range')
        for (k, v) in items:
            print('  x %.1f z %.1f : %d pts, h %.2f..%.2f' % (k[0], k[1], len(v), min(v), max(v)))
