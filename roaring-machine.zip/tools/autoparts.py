import math, numpy as np, mm_model
from coverage import world_boxes, parts_cover
roots = mm_model.build()
pts = world_boxes(roots)
print('points', len(pts))
x, h, z = pts[:,0], pts[:,1], pts[:,2]
covered = np.zeros(len(pts), bool)
parts = []
sizes = (0.5, 0.8, 1.1, 1.5)
xs = np.arange(-1.5, 1.51, 0.25)
zs = np.arange(-3.1, 2.71, 0.25)
while covered.mean() < 0.992 and len(parts) < 34:
    best = None
    for w in sizes:
        for cx in xs:
            for cz in zs:
                m = (np.abs(x-cx) <= w/2) & (np.abs(z-cz) <= w/2)
                if m.sum() < 8: continue
                hh = h[m]
                y0 = 0.0 if hh.min() < 0.9 else float(hh.min())
                top = float(hh.max())
                if top - y0 < 0.3: continue
                inside = m & (h >= y0 - 1e-6) & (h <= top + 1e-6)
                new = (inside & ~covered).sum()
                if new < 8: continue
                vol = w*w*(top-y0)
                score = new / (vol ** 0.7)
                if best is None or score > best[0]:
                    best = (score, w, cx, cz, y0, top, new)
    if best is None: break
    _, w, cx, cz, y0, top, new = best
    parts.append((round(cz,2), round(cx,2), round(y0,2), w, round(top-y0+0.02,2)))
    m = (np.abs(x-cx) <= w/2) & (np.abs(z-cz) <= w/2) & (h >= y0-1e-6) & (h <= top+0.02)
    covered |= m
    print(len(parts), 'part z %.2f x %.2f y0 %.2f w %.1f h %.2f -> coverage %.1f%%' % (cz, cx, y0, w, top-y0, covered.mean()*100))
open('/home/claude/parts_auto.txt','w').write(repr(parts))
print(len(parts), 'parts')
